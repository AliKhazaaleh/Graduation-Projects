package com.example.gymapp.Activites;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.bumptech.glide.Glide;
import com.example.gymapp.Others.App;
import com.example.gymapp.R;

import pl.droidsonroids.gif.GifImageView;

public class ShowTrainingGif extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_training_gif);

        boolean flagTrainer=this.getIntent().getExtras().getBoolean(App.FLAG_TRAINER);
        String trainingUrlGif=this.getIntent().getExtras().getString(App.TRAINING_URL_GIF);

        if (flagTrainer)
            getSupportActionBar().setTitle("TRAINER - TRAINING AS GIF");
        else
            getSupportActionBar().setTitle("TRAINEE - TRAINING AS GIF");

        // Declare Variables For UI AND CONNECT ELEMENT GIFIMAGE
        GifImageView imageViewPhoto=(GifImageView)findViewById(R.id.imageViewPhoto);
        Glide.with(this).load(Uri.parse(trainingUrlGif)).into(imageViewPhoto);

    }
}
