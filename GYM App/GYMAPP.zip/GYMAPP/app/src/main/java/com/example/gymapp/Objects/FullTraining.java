package com.example.gymapp.Objects;

import com.example.gymapp.Others.AppRefDB;

public class FullTraining {
    String id;
    String traineeId;
    String trainerId;
    long date;
    String trainingList;
    String status;

    public FullTraining(String id, String traineeId, String trainerId, long date, String trainingList, String status) {
        this.id = id;
        this.traineeId = traineeId;
        this.trainerId = trainerId;
        this.date = date;
        this.trainingList = trainingList;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTraineeId() {
        return traineeId;
    }

    public void setTraineeId(String traineeId) {
        this.traineeId = traineeId;
    }

    public String getTrainerId() {
        return trainerId;
    }

    public void setTrainerId(String trainerId) {
        this.trainerId = trainerId;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public String getTrainingList() {
        return trainingList;
    }

    public void setTrainingList(String trainingList) {
        this.trainingList = trainingList;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
        AppRefDB.RefFullTraining.child(this.id).child("status").setValue(status);
    }

    public static final String PENDING="Pending";
    public static final String VACATION="Vacation";
    public static final String DONE="Done";

}
