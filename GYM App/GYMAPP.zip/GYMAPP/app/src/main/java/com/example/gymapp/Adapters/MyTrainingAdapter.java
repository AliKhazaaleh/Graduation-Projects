package com.example.gymapp.Adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.DataSetObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gymapp.Activites.ShowTrainingGif;
import com.example.gymapp.Objects.Training;
import com.example.gymapp.Others.App;
import com.example.gymapp.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;
import es.dmoral.toasty.Toasty;

public class MyTrainingAdapter implements ListAdapter {


    ArrayList<Training> arrayList;
    HashMap<String , String> MAPSetMinOfTraining;
    Context context;

    public MyTrainingAdapter(Context context, ArrayList<Training> arrayList, HashMap<String , String> MAPSetMinOfTraining) {
        this.arrayList=arrayList;
        this.context=context;
        this.MAPSetMinOfTraining=MAPSetMinOfTraining;
    }
    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }
    @Override
    public boolean isEnabled(int position) {
        return true;
    }
    @Override
    public void registerDataSetObserver(DataSetObserver observer) {
    }
    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {
    }
    @Override
    public int getCount() {
        return arrayList.size();
    }
    @Override
    public Object getItem(int position) {
        return position;
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public boolean hasStableIds() {
        return false;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Training training=arrayList.get(position);
        if(convertView==null) {
            LayoutInflater layoutInflater = LayoutInflater.from(context);
            convertView=layoutInflater.inflate(R.layout.item_training, null);

            ((TextView)convertView.findViewById(R.id.textViewNameTraining)).setText(training.getName());
            ((TextView)convertView.findViewById(R.id.textViewTrainingSetsOrMin)).setText(MAPSetMinOfTraining.get(training.getId()));

            if (training.getPhotoLink() == null || training.getPhotoLink().equals("")) {
                ((CircleImageView)convertView.findViewById(R.id.imageViewPhotoTraining)).setImageResource(R.mipmap.logo_training);
            } else{
                Picasso.get().load(training.getPhotoLink()).into((CircleImageView)convertView.findViewById(R.id.imageViewPhotoTraining));

                ((CircleImageView)convertView.findViewById(R.id.imageViewPhotoTraining)).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(context , ShowTrainingGif.class);
                        intent.putExtra(App.TRAINING_URL_GIF,training.getPhotoLink());
                        intent.putExtra(App.FLAG_TRAINER,false);
                        context.startActivity(intent);
                    }
                });
            }

            ((CircleImageView)convertView.findViewById(R.id.imageViewTrainingInfo)).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (training.getInfo().isEmpty()){
                        Toasty.warning(context, "Not Exist Other Info For it", Toast.LENGTH_SHORT, true).show();
                    } else {
                        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
                        final TextView textViewTrainingInfo = new TextView(context);

                        textViewTrainingInfo.setText(training.getInfo());
                        dialogBuilder.setView(textViewTrainingInfo);
                        AlertDialog alertDialog = dialogBuilder.create();
                        alertDialog.show();
                    }
                }
            });
        }
        return convertView;
    }
    @Override
    public int getItemViewType(int position) {
        return position;
    }
    @Override
    public int getViewTypeCount() {
        return arrayList.size();
    }
    @Override
    public boolean isEmpty() {
        return false;
    }

}
