package com.example.gymapp.Others;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.View;
import android.widget.Toast;
import java.util.Calendar;
import java.util.Date;

import com.google.firebase.auth.FirebaseAuth;

import es.dmoral.toasty.Toasty;

public class App {

    public static final String TRAINEE_INFO_KEY ="TRAINEE_INFO_KEY" ;
    public static final String TRAINER_INFO_KEY = "TRAINER_INFO_KEY";
    public static final String TRAINEE_ADD_FULL_TRAINING_KEY = "TRAINEE_ADD_FULL_TRAINING_KEY";
    public static final String MODE_APP = "MODE_APP";
    public static final String MODE_TRAINER = "MODE_TRAINER";
    public static final String MODE_TRAINEE = "MODE_TRAINEE";
    public static final String MODE_ADMIN = "MODE_ADMIN";
    public static final String FLAG_TRAINER = "FLAG_TRAINER";
    public static final String TRAINING_URL_GIF = "TRAINING_URL_GIF";
    public static final String BLOCK_STATUS_KEY = "BLOCK_STATUS_KEY";


    private App(){}
    public static boolean isLoginUser(){
        try {
            FirebaseAuth.getInstance().getCurrentUser().reload();
            return FirebaseAuth.getInstance().getCurrentUser()!=null;
        } catch (Exception e) {}
        return false;
    }

    public static boolean isLoginAndVerifyUser(){
        try {
            FirebaseAuth.getInstance().getCurrentUser().reload();
            return FirebaseAuth.getInstance().getCurrentUser()!=null && FirebaseAuth.getInstance().getCurrentUser().isEmailVerified();
        } catch (Exception e) {}
        return false;
    }

    public static String getUserId(){
        return  FirebaseAuth.getInstance().getCurrentUser().getUid();
    }

    public static String ConvertTimeToFormat (long time){

        String time_format = String.valueOf( (time/3600000)%24 ) +":"+ String.valueOf((time%3600000)/60000 )+":"+ String.valueOf( (time%3600000)%60000/1000 );
        return time_format;

    }

    public static long ConvertTimeToMillis(String time){

        String[]parts = time.split(":");
        long timeMil = Long.parseLong( parts[0] ) * 3600000 + Long.parseLong( parts[1] ) * 60000 ;

        return timeMil;
    }

    public static long CurrentTimeMillis (){
        return Calendar.getInstance().getTimeInMillis();
    }

    public static Date CurrentTime(){
        Date currentTime = Calendar.getInstance().getTime();
        return currentTime;
    }
    public static boolean mIsNetworkAvailable(Activity context , View view) {

        ConnectivityManager connectivityManager
                = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();

        if (activeNetworkInfo != null && activeNetworkInfo.isConnected()){
            return true;
        }else {
            Toasty.warning(context, "لا يوجد اتصال بالشبكة", Toast.LENGTH_SHORT, true).show();
            return  false;
        }
    }

}
