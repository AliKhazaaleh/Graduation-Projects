package com.example.gymapp.Activites;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gymapp.Adapters.FullTrainingAdapter;
import com.example.gymapp.Adapters.MyTraineesAdapter;
import com.example.gymapp.Objects.Admin;
import com.example.gymapp.Objects.FullTraining;
import com.example.gymapp.Objects.RTT;
import com.example.gymapp.Objects.Trainee;
import com.example.gymapp.Objects.Training;
import com.example.gymapp.Others.App;
import com.example.gymapp.Others.AppRefDB;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;
import es.dmoral.toasty.Toasty;

public class AddFullTrainingActivity extends AppCompatActivity {


    // Declare Variables For UI
    Button buttonAddToList,buttonSubmitFullTraining,buttonSubmitVacation;
    Spinner spinnerTraining,spinnerSet1,spinnerSet2,spinnerSet3,spinnerMin;
    ListView listViewTrainings;
    TextView textViewDOT;
    Switch switchMin;
    Calendar calendarDOT;

    // Declare Variables For This Activity
    String traineeId="";
    ArrayList<String>arrayListSets;
    ArrayList<Trainee> arrayListMyTrainees;
    ArrayList<String> arrayListAllTraining;
    ArrayList<Training> arrayListTraining;
    HashMap<String , String> MAPSetMinOfTraining;
    FullTraining fullTraining;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_full_training);
        getSupportActionBar().setTitle("TRAINER - FULL TRAINING");

        traineeId=this.getIntent().getExtras().getString(App.TRAINEE_ADD_FULL_TRAINING_KEY);
        loadObjects();
        loadUI();
        loadAction();
        loadTrainingOfDay();
    }

    private void loadObjects() {

        // Assign Objects Of Activity
        arrayListMyTrainees=new ArrayList<>();
        arrayListAllTraining=new ArrayList<>();
        arrayListTraining= new ArrayList<>();
        MAPSetMinOfTraining = new HashMap<>();
        fullTraining=null;
        calendarDOT=Calendar.getInstance();

        // Get All Trainings From DB
        for (Map.Entry<String , Training> item : DBLayer.getInstance().getMAPTrainings().entrySet())
            arrayListAllTraining.add(item.getValue().getName());

        // Create Array Sets To Spinner
        arrayListSets=new ArrayList<>();
        for (int i=6;i<=25;i++)
            arrayListSets.add(""+i);

    }

    private void loadUI() {

        // START - LOAD USER CARD ELEMENTS (CONNECT LAYOUT ELEMENTS WITH ACTIVITY)
        ((TextView)findViewById(R.id.textViewNameTrainee)).setText(DBLayer.getInstance().getMAPTrainees().get(traineeId).getName());
        ((CircleImageView)findViewById(R.id.imageViewTraineeInfo)).setImageResource(R.mipmap.logo_info);

        /**
         * IF TRUE LOAD BASIC LOGO MEMBER (THE TRAINEE NOT HAVE IMAGE)
         * IF FALSE LOAD PHOTO OF TRAINEE (THE TRAINEE HAVE IMAGE)
         */
        if (DBLayer.getInstance().getMAPTrainees().get(traineeId).getPhotoLink() == null || DBLayer.getInstance().getMAPTrainees().get(traineeId).getPhotoLink().equals(""))
            ((CircleImageView)findViewById(R.id.imageViewPhotoTrainee)).setImageResource(R.mipmap.logo_member);
        else
            Picasso.get().load(DBLayer.getInstance().getMAPTrainees().get(traineeId).getPhotoLink()).into((CircleImageView) findViewById(R.id.imageViewPhotoTrainee));
        // END - LOAD USER CARD

        // CONNECT LAYOUT ELEMENTS WITH ACTIVITY (BUTTONS, TEXTVIEWS AND SPINNERS)
        buttonAddToList=(Button)findViewById(R.id.buttonAddToList);
        buttonSubmitFullTraining=(Button)findViewById(R.id.buttonSubmitFullTraining);
        buttonSubmitVacation=(Button)findViewById(R.id.buttonSubmitVacation);

        spinnerTraining=(Spinner)findViewById(R.id.spinnerTraining);
        spinnerSet1=(Spinner)findViewById(R.id.spinnerSet1);
        spinnerSet2=(Spinner)findViewById(R.id.spinnerSet2);
        spinnerSet3=(Spinner)findViewById(R.id.spinnerSet3);
        spinnerMin=(Spinner)findViewById(R.id.spinnerMin);
        spinnerMin.setEnabled(false);

        listViewTrainings=(ListView)findViewById(R.id.listViewTrainings);
        textViewDOT=(TextView)findViewById(R.id.textViewDOT);
        textViewDOT.setText(calendarDOT.get(Calendar.YEAR)+"-"+(calendarDOT.get(Calendar.MONTH)+1)+"-"+calendarDOT.get(Calendar.DAY_OF_MONTH));
        switchMin=(Switch)findViewById(R.id.switchMin);
        // END - LOAD ELEMENTS

        //START - ADD ITEMS TO SPINEERS
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item , arrayListAllTraining);
        spinnerTraining.setAdapter(adapter1);

        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item , arrayListSets);
        spinnerSet1.setAdapter(adapter2);

        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item , arrayListSets);
        spinnerSet2.setAdapter(adapter3);

        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item , arrayListSets);
        spinnerSet3.setAdapter(adapter4);

        ArrayAdapter<String> adapter5 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item , arrayListSets);
        spinnerMin.setAdapter(adapter5);
        //END - ADD ITEMS TO SPINEERS
    }

    // TO ADD ACTIONS ON ELEMENTS (BUTTONS, SWITCH)
    private void loadAction() {

        // ACTION - OPEN ACTIVITY TRAINEE INFO
        ((CircleImageView)findViewById(R.id.imageViewTraineeInfo)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext() , TraineeInfoActivity.class);
                intent.putExtra(App.TRAINEE_INFO_KEY, traineeId);
                startActivity(intent);
            }
        });

        // ACTION - CHANGE TO (SETS OR MIN)
        switchMin.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b){
                    spinnerSet1.setEnabled(false);
                    spinnerSet2.setEnabled(false);
                    spinnerSet3.setEnabled(false);
                    spinnerMin.setEnabled(true);
                } else {
                    spinnerSet1.setEnabled(true);
                    spinnerSet2.setEnabled(true);
                    spinnerSet3.setEnabled(true);
                    spinnerMin.setEnabled(false);
                }
            }
        });

        // ACTION - CHANGE DATE
        textViewDOT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear,
                                          int dayOfMonth) {
                        // TODO Auto-generated method stub
                        calendarDOT.set(Calendar.YEAR, year);
                        calendarDOT.set(Calendar.MONTH, monthOfYear);
                        calendarDOT.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        textViewDOT.setText(year+"-"+(monthOfYear+1)+"-"+dayOfMonth);

                        // LOAD DATA OF THIS DATE
                        loadTrainingOfDay();
                    }
                };
                new DatePickerDialog(getActivity(), date, calendarDOT
                        .get(Calendar.YEAR), calendarDOT.get(Calendar.MONTH),
                        calendarDOT.get(Calendar.DAY_OF_MONTH)).show();
            }
        });


        // ACTION -  ADD TRAINING TO LIST TRAININGS
        buttonAddToList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String nameTraining=spinnerTraining.getSelectedItem().toString();
                for (int i=0; i<arrayListTraining.size(); i++) {
                    if (arrayListTraining.get(i).getName().equals(nameTraining))
                    {
                        Toasty.warning(getBaseContext(), "Already Added it", Toast.LENGTH_SHORT, true).show();
                        return;
                    }
                }

                String trainingId="";
                for (Map.Entry<String , Training> item : DBLayer.getInstance().getMAPTrainings().entrySet())
                    if (item.getValue().getName().equals(nameTraining)){
                        trainingId=item.getValue().getId();
                        arrayListTraining.add(item.getValue());
                        break;
                    }

                if (trainingId.isEmpty())
                    return;

                if (switchMin.isChecked()){
                    MAPSetMinOfTraining.put(trainingId,spinnerMin.getSelectedItem().toString()+" Min");
                } else {
                    String setsTraining=spinnerSet1.getSelectedItem().toString()+" Set(1)"+ " - "
                                    +spinnerSet2.getSelectedItem().toString()+" Set(2)"+ " - "
                                    +spinnerSet3.getSelectedItem().toString()+" Set(3)";

                    MAPSetMinOfTraining.put(trainingId,setsTraining);
                }

                reloadListView();
            }
        });

        // ACTION - ADD TRAINING LIST FOR TRAINEE
        buttonSubmitFullTraining.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (arrayListTraining.size()<5)
                {
                    Toasty.warning(getBaseContext(), "at least must add 5 training", Toast.LENGTH_SHORT, true).show();
                    return;
                }

                String trainingList="";
                for (int i=0; i<arrayListTraining.size();i++){
                    trainingList+= arrayListTraining.get(i).getId()+" __ "+MAPSetMinOfTraining.get(arrayListTraining.get(i).getId());

                    if (i<arrayListTraining.size()-1)
                        trainingList+= " && ";
                }
                FullTraining fullTraining=new FullTraining(AppRefDB.RefFullTraining.push().getKey(),traineeId,App.getUserId(),calendarDOT.getTimeInMillis(), trainingList, FullTraining.PENDING);
                DBLayer.getInstance().getMAPTrainers().get(App.getUserId()).addFullTraining(fullTraining);

                Toasty.success(getBaseContext(), "Successfully", Toast.LENGTH_LONG, true).show();
                Intent intent = new Intent(AddFullTrainingActivity.this , MyTraineesActivity.class);
                startActivity(intent);
                finish();
            }
        });

        // ACTION - ADD VACATION FOR TRAINEE
        buttonSubmitVacation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FullTraining fullTraining=new FullTraining(AppRefDB.RefFullTraining.push().getKey(),traineeId,App.getUserId(),calendarDOT.getTimeInMillis(), "", FullTraining.VACATION);
                DBLayer.getInstance().getMAPTrainers().get(App.getUserId()).addFullTraining(fullTraining);

                Toasty.success(getBaseContext(), "Successfully", Toast.LENGTH_LONG, true).show();
                Intent intent = new Intent(AddFullTrainingActivity.this , MyTraineesActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }


    // CALL DB TO GET TRAININGS OF TRAINEE BY DEPEND ON DATE
    public  void loadTrainingOfDay(){

        if (calendarDOT.get(Calendar.YEAR) < Calendar.getInstance().get(Calendar.YEAR) ||
                (calendarDOT.get(Calendar.YEAR) == Calendar.getInstance().get(Calendar.YEAR) && calendarDOT.get(Calendar.MONTH) < Calendar.getInstance().get(Calendar.MONTH)) ||
                (calendarDOT.get(Calendar.YEAR) == Calendar.getInstance().get(Calendar.YEAR) && calendarDOT.get(Calendar.MONTH) == Calendar.getInstance().get(Calendar.MONTH) && calendarDOT.get(Calendar.DAY_OF_MONTH) < Calendar.getInstance().get(Calendar.DAY_OF_MONTH))) {

            buttonAddToList.setEnabled(false);
            buttonSubmitFullTraining.setEnabled(false);
            buttonSubmitVacation.setEnabled(false);
            spinnerSet1.setEnabled(false);
            spinnerSet2.setEnabled(false);
            spinnerSet3.setEnabled(false);
            spinnerMin.setEnabled(false);
            switchMin.setEnabled(false);
            spinnerTraining.setEnabled(false);

            buttonAddToList.setAlpha((float)0.5);
            buttonSubmitFullTraining.setAlpha((float)0.5);
            buttonSubmitVacation.setAlpha((float)0.5);
        } else {
            buttonAddToList.setEnabled(true);
            buttonSubmitFullTraining.setEnabled(true);
            spinnerTraining.setEnabled(true);
            switchMin.setEnabled(true);
            buttonSubmitVacation.setEnabled(true);

            buttonAddToList.setAlpha((float)1.0);
            buttonSubmitFullTraining.setAlpha((float)1.0);
            buttonSubmitVacation.setAlpha((float)1.0);

            if (switchMin.isChecked()) {
                spinnerMin.setEnabled(true);
                spinnerSet1.setEnabled(false);
                spinnerSet2.setEnabled(false);
                spinnerSet3.setEnabled(false);
            } else {
                spinnerMin.setEnabled(false);
                spinnerSet1.setEnabled(true);
                spinnerSet2.setEnabled(true);
                spinnerSet3.setEnabled(true);
            }
        }

        fullTraining=null;
        for (Map.Entry<String , FullTraining> item : DBLayer.getInstance().getMAPFullTraining().entrySet())
        {
            Calendar calendarDateTraining=Calendar.getInstance();
            calendarDateTraining.setTimeInMillis(item.getValue().getDate());

            if (item.getValue().getTraineeId().equals(traineeId) &&
                    calendarDateTraining.get(Calendar.YEAR) == calendarDOT.get(Calendar.YEAR) &&
                    calendarDateTraining.get(Calendar.MONTH) == calendarDOT.get(Calendar.MONTH) &&
                    calendarDateTraining.get(Calendar.DAY_OF_MONTH) == calendarDOT.get(Calendar.DAY_OF_MONTH))
            {
                fullTraining=item.getValue();
                break;
            }
        }

        if (fullTraining==null){
            Toasty.warning(getBaseContext(), "Not Exist Any Training For This Day", Toast.LENGTH_SHORT, true).show();

            arrayListTraining.clear();
            MAPSetMinOfTraining.clear();
            reloadListView();
            ((TextView)findViewById(R.id.textViewStatusTraining)).setText("Status - No Training");

        } else {

            ((TextView)findViewById(R.id.textViewStatusTraining)).setText("Status - "+fullTraining.getStatus());

            arrayListTraining.clear();
            MAPSetMinOfTraining.clear();

            if (!fullTraining.getStatus().equals(FullTraining.VACATION))
            {
                String[] arTraining=fullTraining.getTrainingList().split(" && ");


                for (int i = 0;i<arTraining.length; i++) {

                    String[] detailsTraining = arTraining[i].split(" __ ");
                    arrayListTraining.add(DBLayer.getInstance().getMAPTrainings().get(detailsTraining[0]));
                    MAPSetMinOfTraining.put(detailsTraining[0],detailsTraining[1]);
                }
            }
            reloadListView();

            buttonAddToList.setEnabled(false);
            buttonSubmitFullTraining.setEnabled(false);
            spinnerSet1.setEnabled(false);
            spinnerSet2.setEnabled(false);
            spinnerSet3.setEnabled(false);
            spinnerMin.setEnabled(false);
            switchMin.setEnabled(false);
            spinnerTraining.setEnabled(false);
            buttonSubmitVacation.setEnabled(false);

            buttonAddToList.setAlpha((float)0.5);
            buttonSubmitFullTraining.setAlpha((float)0.5);
            buttonSubmitVacation.setAlpha((float)0.5);
        }
    }


    // FUNCTION FOR LOAD LISTVIEW OF TRAININGS
    public void reloadListView(){

        if (arrayListTraining.size()>0){
            FullTrainingAdapter customAdapter = new FullTrainingAdapter(this, arrayListTraining, MAPSetMinOfTraining);
            listViewTrainings.setAdapter(customAdapter);
        } else {
            listViewTrainings.setAdapter(null);
        }
    }
    public Activity getActivity(){
        return this;
    }

}
