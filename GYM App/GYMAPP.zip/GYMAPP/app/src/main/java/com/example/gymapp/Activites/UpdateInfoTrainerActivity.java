package com.example.gymapp.Activites;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gymapp.Objects.Trainee;
import com.example.gymapp.Objects.Trainer;
import com.example.gymapp.Objects.User;
import com.example.gymapp.Others.App;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import es.dmoral.toasty.Toasty;

public class UpdateInfoTrainerActivity extends AppCompatActivity {

    // Declare Variables For UI
    public TextView textViewDOB;
    private Spinner spinnerGender;
    Calendar calendarDOB;

    List<String> LSTSpinnerGender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_info_trainer);
        getSupportActionBar().setTitle("TRAINER - UPDATE INFO");

        loadObjects();
        loadUI();
        loadCurrentInfo();
        loadActions();
    }

    private void loadObjects() {
        LSTSpinnerGender = new ArrayList<>();
        LSTSpinnerGender.add(User.MALE);
        LSTSpinnerGender.add(User.FEMALE);

        calendarDOB = Calendar.getInstance();
    }

    // (CONNECT LAYOUT ELEMENTS WITH ACTIVITY)
    private void loadUI() {
        spinnerGender=(Spinner)findViewById(R.id.spinnerGender);
        textViewDOB=(TextView)findViewById(R.id.textViewDOB);

        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item , LSTSpinnerGender);
        spinnerGender.setAdapter(adapter1);
    }

    private void loadActions() {
        textViewDOB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear,
                                          int dayOfMonth) {
                        // TODO Auto-generated method stub
                        calendarDOB.set(Calendar.YEAR, year);
                        calendarDOB.set(Calendar.MONTH, monthOfYear);
                        calendarDOB.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        textViewDOB.setText(year+"-"+(monthOfYear+1)+"-"+dayOfMonth);
                    }
                };
                new DatePickerDialog(getActivity(), date, calendarDOB
                        .get(Calendar.YEAR), calendarDOB.get(Calendar.MONTH),
                        calendarDOB.get(Calendar.DAY_OF_MONTH)).show();
            }
        });



        ((Button)findViewById(R.id.buttonCompleteRegister)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String validations="";

                String nameTrainee=((EditText)findViewById(R.id.editTextNameTrainee)).getText().toString();
                String phoneNumberTrainer=((EditText)findViewById(R.id.editTextPhoneNumber)).getText().toString();

                if (nameTrainee.isEmpty())
                    validations+="- Add User Name.\n";

                if (textViewDOB.getText().toString().equals("1900-1-1"))
                    validations+="- Set Date Of Birth.\n";

                if (phoneNumberTrainer.isEmpty())
                    validations+="- Set Phone Number.\n";

                if (Calendar.getInstance().compareTo(calendarDOB) == -1)
                    validations+="- Must be Date Of Birth less than Today Date.\n";

                if (!validations.isEmpty()){
                    Toasty.warning(getBaseContext(), validations, Toast.LENGTH_LONG, true).show();
                    return;
                }

                Trainer trainer=DBLayer.getInstance().getMAPTrainers().get(App.getUserId());
                trainer.setName(((EditText)findViewById(R.id.editTextNameTrainee)).getText().toString());
                trainer.setPhoneNumber(((EditText)findViewById(R.id.editTextPhoneNumber)).getText().toString());
                trainer.setDateOfBirth(textViewDOB.getText().toString());
                trainer.setGender(spinnerGender.getSelectedItem().toString());
                trainer.setInfo(((EditText)findViewById(R.id.editTextOtherInfo)).getText().toString());
                trainer.setStatus(Trainer.PENDING);
                trainer.setMyInfo(trainer);

                Toasty.success( getBaseContext(), "Successful Update", Toast.LENGTH_SHORT, true).show();
                Intent intent = new Intent(UpdateInfoTrainerActivity.this , HomeTrainerActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }


    private void loadCurrentInfo() {
        Trainer trainer= DBLayer.getInstance().getMAPTrainers().get(FirebaseAuth.getInstance().getCurrentUser().getUid());
        if (trainer == null)
            return;

        ((EditText)findViewById(R.id.editTextNameTrainee)).setText(trainer.getName().toString());
        ((EditText)findViewById(R.id.editTextPhoneNumber)).setText(trainer.getPhoneNumber().toString());
        ((EditText)findViewById(R.id.editTextOtherInfo)).setText(trainer.getInfo().toString());

        String[] DOB = trainer.getDateOfBirth().split("-");
        calendarDOB.set(Calendar.YEAR , Integer.parseInt(DOB[0]));
        calendarDOB.set(Calendar.MONTH , Integer.parseInt(DOB[1]));
        calendarDOB.set(Calendar.DAY_OF_MONTH , Integer.parseInt(DOB[2]));

        textViewDOB.setText(trainer.getDateOfBirth().toString());

        switch (trainer.getGender())
        {
            case Trainer.MALE:
                spinnerGender.setSelection(0);
                break;
            case Trainer.FEMALE:
                spinnerGender.setSelection(1);
                break;
        }
    }

    public Activity getActivity(){
        return this;
    }
}
