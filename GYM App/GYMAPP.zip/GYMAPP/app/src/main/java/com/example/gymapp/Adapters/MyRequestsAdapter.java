package com.example.gymapp.Adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.DataSetObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ListAdapter;

import com.example.gymapp.Activites.TraineeInfoActivity;
import com.example.gymapp.Objects.RTT;
import com.example.gymapp.Others.App;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class MyRequestsAdapter implements ListAdapter {

    ArrayList<RTT> arrayList;
    Context context;
    List<TextView> listTextViewCount=new ArrayList<>();

    public MyRequestsAdapter(Context context, ArrayList<RTT> arrayList, List<TextView> listTextViewCount) {
        this.arrayList=arrayList;
        this.context=context;
        this.listTextViewCount=listTextViewCount;
    }
    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }
    @Override
    public boolean isEnabled(int position) {
        return true;
    }
    @Override
    public void registerDataSetObserver(DataSetObserver observer) {
    }
    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {
    }
    @Override
    public int getCount() {
        return arrayList.size();
    }
    @Override
    public Object getItem(int position) {
        return position;
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public boolean hasStableIds() {
        return false;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        RTT rtt=arrayList.get(position);
        if(convertView==null) {
            LayoutInflater layoutInflater = LayoutInflater.from(context);
            convertView = layoutInflater.inflate(R.layout.item_request, null);
        }
        ((TextView)convertView.findViewById(R.id.textViewNameTraineeOfRequest)).setText(DBLayer.getInstance().getMAPTrainees().get(rtt.getTraineeId()).getName());
        CircleImageView imageViewStatusRequest = (CircleImageView)convertView.findViewById(R.id.imageViewStatusRequest);

        if (DBLayer.getInstance().getMAPTrainees().get(rtt.getTraineeId()).getPhotoLink() == null || DBLayer.getInstance().getMAPTrainees().get(rtt.getTraineeId()).getPhotoLink().equals("")) {
            ((CircleImageView)convertView.findViewById(R.id.imageViewPhotoTraineeOfRequest)).setImageResource(R.mipmap.logo_member);
        } else {
            Picasso.get().load(DBLayer.getInstance().getMAPTrainees().get(rtt.getTraineeId()).getPhotoLink()).into((CircleImageView) convertView.findViewById(R.id.imageViewPhotoTraineeOfRequest));

            ((CircleImageView) convertView.findViewById(R.id.imageViewPhotoTraineeOfRequest)).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
                    final ImageView imageViewPhoto = new ImageView(context);

                    Picasso.get().load(DBLayer.getInstance().getMAPTrainees().get(rtt.getTraineeId()).getPhotoLink()).into(imageViewPhoto);
                    dialogBuilder.setView(imageViewPhoto);

                    AlertDialog alertDialog = dialogBuilder.create();
                    alertDialog.show();
                }
            });
        }

         switch (rtt.getStatus()) {
            case RTT.ACCEPT:
               /* ((Button)convertView.findViewById(R.id.buttonAcceptRequest)).setEnabled(false);
                ((Button)convertView.findViewById(R.id.buttonRejectRequest)).setEnabled(false);
                ((Button)convertView.findViewById(R.id.buttonAcceptRequest)).setAlpha((float)0.5);
                ((Button)convertView.findViewById(R.id.buttonRejectRequest)).setAlpha((float)0.5);
*/
                ((CircleImageView)convertView.findViewById(R.id.imageViewStatusRequest)).setImageResource(R.mipmap.logo_accept);
                break;
            case RTT.REJECT:
                /*((Button)convertView.findViewById(R.id.buttonAcceptRequest)).setEnabled(false);
                ((Button)convertView.findViewById(R.id.buttonRejectRequest)).setEnabled(false);
                ((Button)convertView.findViewById(R.id.buttonAcceptRequest)).setAlpha((float)0.5);
                ((Button)convertView.findViewById(R.id.buttonRejectRequest)).setAlpha((float)0.5);
*/
                ((CircleImageView)convertView.findViewById(R.id.imageViewStatusRequest)).setImageResource(R.mipmap.logo_reject);
                break;
            case RTT.PENDING:
                ((CircleImageView)convertView.findViewById(R.id.imageViewStatusRequest)).setImageResource(R.mipmap.logo_pending);
                break;
        }

        ((Button)convertView.findViewById(R.id.buttonAcceptRequest)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBLayer.getInstance().getMAPRTT().get(rtt.getId()).setStatus(RTT.ACCEPT);
                imageViewStatusRequest.setImageResource(R.mipmap.logo_accept);
                updateTextViewCount();
            }
        });
        ((Button)convertView.findViewById(R.id.buttonRejectRequest)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBLayer.getInstance().getMAPRTT().get(rtt.getId()).setStatus(RTT.REJECT);
                imageViewStatusRequest.setImageResource(R.mipmap.logo_reject);
                updateTextViewCount();
            }
        });
        ((Button)convertView.findViewById(R.id.buttonInfo)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context , TraineeInfoActivity.class);
                intent.putExtra(App.TRAINEE_INFO_KEY, rtt.getTraineeId());
                context.startActivity(intent);
            }
        });

        return convertView;
    }

    private void updateTextViewCount() {
        int countAccept=0;
        int countReject=0;
        int countPending=0;

        for (Map.Entry<String , RTT> item : DBLayer.getInstance().getMAPRTT().entrySet()){
            if (item.getValue().getTrainerId().equals(App.getUserId()) && !item.getValue().getStatus().equals(RTT.TERMINATE)){
                switch (item.getValue().getStatus()){
                    case RTT.ACCEPT:
                        countAccept++;
                        break;
                    case RTT.REJECT:
                        countReject++;
                        break;
                    case RTT.PENDING:
                        countPending++;
                        break;
                }
            }
        }

        listTextViewCount.get(0).setText(countPending + " Pending");
        listTextViewCount.get(1).setText(countAccept + " Accept");
        listTextViewCount.get(2).setText(countReject + " Reject");

    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }
    @Override
    public int getViewTypeCount() {
            return arrayList.size();
    }
    @Override
    public boolean isEmpty() {
        return false;
    }

}
