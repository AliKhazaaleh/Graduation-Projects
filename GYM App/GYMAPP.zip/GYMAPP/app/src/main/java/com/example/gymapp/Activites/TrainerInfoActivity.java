package com.example.gymapp.Activites;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.gymapp.Objects.Trainer;
import com.example.gymapp.Others.App;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;

public class TrainerInfoActivity extends AppCompatActivity {

    // Declare Variables For UI
    TextView textViewNameTrainer,textViewPhoneNumber,textViewGender,textViewDOB,textViewOtherInfo;
    Trainer trainer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trainer_info);

        String modeApp=this.getIntent().getExtras().getString(App.MODE_APP);
        String trainerId=this.getIntent().getExtras().getString(App.TRAINER_INFO_KEY);
        trainer= DBLayer.getInstance().getMAPTrainers().get(trainerId);

        if (modeApp != null)
            if (modeApp.equals(App.MODE_TRAINER))
                getSupportActionBar().setTitle("TRAINER - MY INFO");
            else if (modeApp.equals(App.MODE_TRAINEE))
                getSupportActionBar().setTitle("TRAINEE - TRAINER INFO");
            else if (modeApp.equals(App.MODE_ADMIN))
                getSupportActionBar().setTitle("ADMIN - TRAINER INFO");

        loadUI();
    }

    // (CONNECT LAYOUT ELEMENTS WITH ACTIVITY)
    private void loadUI() {
        textViewNameTrainer=((TextView)findViewById(R.id.textViewNameTrainer));
        textViewPhoneNumber=((TextView)findViewById(R.id.textViewPhoneNumber));
        textViewGender=((TextView)findViewById(R.id.textViewGender));
        textViewDOB=((TextView)findViewById(R.id.textViewDOB));
        textViewOtherInfo=((TextView)findViewById(R.id.textViewOtherInfo));

        if (trainer!=null){
            textViewNameTrainer.setText(trainer.getName());
            textViewPhoneNumber.setText(trainer.getPhoneNumber());
            textViewDOB.setText("Date Of Birth - "+trainer.getDateOfBirth());
            textViewGender.setText("Gender - "+trainer.getGender());
            textViewOtherInfo.setText(trainer.getInfo());
        }
    }
}
