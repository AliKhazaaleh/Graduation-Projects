package com.example.gymapp.Others;

import com.example.gymapp.Jsons.AdminJson;
import com.example.gymapp.Jsons.FullTrainingJson;
import com.example.gymapp.Jsons.RTTJson;
import com.example.gymapp.Jsons.TraineeJson;
import com.example.gymapp.Jsons.TrainerJson;
import com.example.gymapp.Jsons.TrainingJson;
import com.example.gymapp.Jsons.WeightTraineeJson;
import com.example.gymapp.Objects.Admin;
import com.example.gymapp.Objects.FullTraining;
import com.example.gymapp.Objects.RTT;
import com.example.gymapp.Objects.Trainee;
import com.example.gymapp.Objects.Trainer;
import com.example.gymapp.Objects.Training;
import com.example.gymapp.Objects.WeightTrainee;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DBLayer {

    private static final DBLayer ourInstance = new DBLayer();

    private HashMap<String , Admin> MAPAdmins = new HashMap<>();
    private HashMap<String , Trainer> MAPTrainers = new HashMap<>();
    private HashMap<String , Trainee> MAPTrainees = new HashMap<>();
    private HashMap<String , RTT> MAPRTT = new HashMap<>();
    private HashMap<String , WeightTrainee> MAPWeightTrainees = new HashMap<>();
    private HashMap<String , Training> MAPTrainings = new HashMap<>();
    private HashMap<String , FullTraining> MAPFullTraining = new HashMap<>();

    public static DBLayer getInstance() {
        return ourInstance;
    }
    private DBLayer() {
    }

    private void mLoadTrainers(){
        AppRefDB.RefTrainers.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
               MAPTrainers.clear();
                for (DataSnapshot data : dataSnapshot.getChildren()){
                    Trainer trainer = data.getValue(TrainerJson.class).ConvertToObject();
                    MAPTrainers.put(trainer.getId(), trainer);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }


    private void mLoadTrainees(){
        AppRefDB.RefTrainees.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                MAPTrainees.clear();
                for (DataSnapshot data : dataSnapshot.getChildren()){
                    Trainee trainee = data.getValue(TraineeJson.class).ConvertToObject();
                    MAPTrainees.put(trainee.getId(), trainee);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    private void mLoadMAPRTT(){
        AppRefDB.RefRTT.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                MAPRTT.clear();
                for (DataSnapshot data : dataSnapshot.getChildren()){
                    RTT rtt = data.getValue(RTTJson.class).ConvertToObject();
                    MAPRTT.put(rtt.getId(), rtt);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    private void mLoadWeightTrainees(){
        AppRefDB.RefWeightTrainees.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                MAPWeightTrainees.clear();
                for (DataSnapshot data : dataSnapshot.getChildren()){
                    WeightTrainee weightTrainee = data.getValue(WeightTraineeJson.class).ConvertToObject();
                    MAPWeightTrainees.put(weightTrainee.getId(), weightTrainee);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    private void mLoadTrainings(){
        AppRefDB.RefTrainings.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                MAPTrainings.clear();
                for (DataSnapshot data : dataSnapshot.getChildren()){
                    Training training = data.getValue(TrainingJson.class).ConvertToObject();
                    MAPTrainings.put(training.getId(), training);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    private void mLoadFullTraining(){
        AppRefDB.RefFullTraining.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                MAPFullTraining.clear();
                for (DataSnapshot data : dataSnapshot.getChildren()){
                    FullTraining fullTraining = data.getValue(FullTrainingJson.class).ConvertToObject();
                    MAPFullTraining.put(fullTraining.getId(), fullTraining);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    private void mLoadAdmins(){
        AppRefDB.RefAdmins.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                MAPAdmins.clear();
                for (DataSnapshot data : dataSnapshot.getChildren()){
                    Admin admin = data.getValue(AdminJson.class).ConvertToObject();
                    MAPAdmins.put(admin.getId(), admin);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    public HashMap<String, Trainer> getMAPTrainers() {
        return MAPTrainers;
    }

    public HashMap<String, Trainee> getMAPTrainees() {
        return MAPTrainees;
    }

    public HashMap<String, RTT> getMAPRTT() {
        return MAPRTT;
    }

    public HashMap<String, WeightTrainee> getMAPWeightTrainees() {
        return MAPWeightTrainees;
    }

    public HashMap<String, Training> getMAPTrainings() {
        return MAPTrainings;
    }

    public HashMap<String, FullTraining> getMAPFullTraining() {
        return MAPFullTraining;
    }

    public HashMap<String, Admin> getMAPAdmins() {
        return MAPAdmins;
    }

    public void configAdminMode(){
        DBLayer.getInstance().mLoadAdmins();
        DBLayer.getInstance().mLoadTrainers();
        DBLayer.getInstance().mLoadTrainees();
    }

    public void configBasicMode(){
        DBLayer.getInstance().mLoadTrainers();
        DBLayer.getInstance().mLoadTrainees();
    }
    public void configTraineeMode(){
        DBLayer.getInstance().mLoadTrainees();
        DBLayer.getInstance().mLoadTrainers();
        DBLayer.getInstance().mLoadMAPRTT();
        DBLayer.getInstance().mLoadWeightTrainees();
        DBLayer.getInstance().mLoadTrainings();
        DBLayer.getInstance().mLoadFullTraining();
    }

    public void configTrainerMode() {
        DBLayer.getInstance().mLoadTrainees();
        DBLayer.getInstance().mLoadTrainers();
        DBLayer.getInstance().mLoadMAPRTT();
        DBLayer.getInstance().mLoadWeightTrainees();
        DBLayer.getInstance().mLoadTrainings();
        DBLayer.getInstance().mLoadFullTraining();
    }

}
