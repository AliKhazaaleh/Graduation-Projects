package com.example.gymapp.Activites;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.example.gymapp.Objects.Trainer;
import com.example.gymapp.Others.App;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;
import com.google.firebase.auth.FirebaseAuth;

import es.dmoral.toasty.Toasty;

public class SplashTrainerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_trainer);
        getSupportActionBar().setTitle("GYM APP - TRAINER");

        DBLayer.getInstance().configTrainerMode();

        Thread timer = new Thread() {
            public void run() {
                try {
                    sleep(5000);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (App.isLoginAndVerifyUser()){
                        if (DBLayer.getInstance().getMAPTrainers().containsKey(FirebaseAuth.getInstance().getCurrentUser().getUid())) {

                            if (DBLayer.getInstance().getMAPTrainers().get(FirebaseAuth.getInstance().getCurrentUser().getUid()).getStatus().equals(Trainer.BLOCK)) {
                                FirebaseAuth.getInstance().signOut();
                                Intent intent = new Intent(SplashTrainerActivity.this , AuthenticationTrainerActivity.class);
                                intent.putExtra(App.BLOCK_STATUS_KEY, true);
                                startActivity(intent);
                            } else {
                                Intent intent = new Intent(SplashTrainerActivity.this , HomeTrainerActivity.class);
                                startActivity(intent);
                            }
                        } else {
                            Intent intent = new Intent(SplashTrainerActivity.this , RegisterTrainerActivity.class);
                            startActivity(intent);
                        }
                    } else {
                        Intent intent = new Intent(SplashTrainerActivity.this , AuthenticationTrainerActivity.class);
                        intent.putExtra(App.BLOCK_STATUS_KEY, false);
                        startActivity(intent);
                    }
                }
            }
        };
        timer.start();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Intent intent = new Intent(SplashTrainerActivity.this , WelcomeActivity.class);
        startActivity(intent);
    }

    public Activity getActivity(){
        return this;
    }

}
