package com.example.gymapp.Activites;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.gymapp.Objects.Admin;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;

import es.dmoral.toasty.Toasty;

public class AuthenticationAdminActivity extends AppCompatActivity {

    // Declare Variables For UI
    private EditText editTextUserEmailAdmin;
    private EditText editTextUserPasswordAdmin;
    private Button buttonSignInAdmin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authentication_admin);
        getSupportActionBar().setTitle("ADMIN - AUTHENTICATION");

        DBLayer.getInstance().configAdminMode();
        loadUI();
        loadActions();

        try {
            Thread.sleep(2000);
            buttonSignInAdmin.setEnabled(true);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // CONNECT LAYOUT ELEMENTS WITH ACTIVITY (BUTTONS, TEXTVIEWS AND SPINNERS)
    private void loadUI() {
        editTextUserEmailAdmin=(EditText)findViewById(R.id.editTextUserEmailAdmin);
        editTextUserPasswordAdmin=(EditText)findViewById(R.id.editTextUserPasswordAdmin);
        buttonSignInAdmin=(Button)findViewById(R.id.buttonSignInAdmin);
    }

    // LOAD ACTIONS
    private void loadActions() {

        // ACTION - SIGN IN ADMIN
        buttonSignInAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String userName= editTextUserEmailAdmin.getText().toString();
                String password= editTextUserPasswordAdmin.getText().toString();
                if (userName.isEmpty() || password.isEmpty())
                {
                    Toasty.warning(getBaseContext(), "Empty User Name or Password", Toast.LENGTH_SHORT, true).show();
                    return;
                }

                Admin admin=new Admin(userName, password);
                if (admin.checkIsAdmin()) {
                    Toasty.success(getBaseContext(), "Successfully", Toast.LENGTH_SHORT, true).show();
                    Intent intent = new Intent(AuthenticationAdminActivity.this , AdminPanelActivity.class);
                    startActivity(intent);
                }
                else {
                    Toasty.error(getBaseContext(), "Issue in Validation", Toast.LENGTH_SHORT, true).show();
                }
            }
        });
    }

}
