package com.example.gymapp.Activites;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gymapp.Objects.Trainee;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;
import es.dmoral.toasty.Toasty;

public class MyProfileActivity extends AppCompatActivity {

    Trainee trainee;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_profile);
        getSupportActionBar().setTitle("TRAINEE - MY PROFILE");

        loadUI();
        loadActions();
    }

    // (CONNECT LAYOUT ELEMENTS WITH ACTIVITY)
    private void loadUI() {
       trainee = DBLayer.getInstance().getMAPTrainees().get(FirebaseAuth.getInstance().getCurrentUser().getUid());

       if (trainee != null)
       {
           ((TextView)findViewById(R.id.textViewName)).setText(trainee.getName());
           if (!trainee.getPhotoLink().isEmpty()){
               Picasso.get().load(trainee.getPhotoLink()).into((CircleImageView)findViewById(R.id.imageViewPhotoUser));
           }
       }
    }

    private void loadActions() {

        ((Button)findViewById(R.id.buttonUploadMyPhoto)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyProfileActivity.this , UploadPhotoTraineeActivity.class);
                startActivity(intent);
            }
        });

        ((Button)findViewById(R.id.buttonUpdateInfoTrainee)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyProfileActivity.this , UpdateInfoTraineeActivity.class);
                startActivity(intent);
            }
        });

        ((ImageView)findViewById(R.id.imageView1)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toasty.info(getBaseContext(), trainee.getDateOfBirth(), Toast.LENGTH_SHORT, true).show();
            }
        });
        ((ImageView)findViewById(R.id.imageView2)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toasty.info(getBaseContext(), trainee.getEndDate(), Toast.LENGTH_SHORT, true).show();
            }
        });
        ((ImageView)findViewById(R.id.imageView3)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toasty.info(getBaseContext(), (trainee.getPhoneNumber().isEmpty()?"Not Exist Phone Number":trainee.getPhoneNumber()), Toast.LENGTH_SHORT, true).show();
            }
        });


        ((CircleImageView)findViewById(R.id.imageViewPhotoUser)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (trainee != null && !trainee.getPhotoLink().isEmpty())
                {
                    AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
                    final ImageView imageViewPhoto = new ImageView(getActivity());

                    Picasso.get().load(trainee.getPhotoLink()).into(imageViewPhoto);
                    dialogBuilder.setView(imageViewPhoto);

                    AlertDialog alertDialog = dialogBuilder.create();
                    alertDialog.show();
                }
            }
        });

    }


    public Activity getActivity(){
        return this;
    }

}
