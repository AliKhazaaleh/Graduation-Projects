package com.example.gymapp.Activites;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gymapp.Objects.Trainer;
import com.example.gymapp.Objects.WeightTrainee;
import com.example.gymapp.Others.App;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Calendar;
import java.util.Map;

import es.dmoral.toasty.Toasty;

public class HomeTraineeActivity extends AppCompatActivity {

    // Declare Variables For UI
    Button buttonMyProfile,buttonMyTraining,buttonAddWeightMeasurement,buttonRateMyTrainer,buttonTrainersList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_trainee);
        getSupportActionBar().setTitle("TRAINEE - HOME");

        loadUI();
        loadActions();
    }

    // (CONNECT LAYOUT ELEMENTS WITH ACTIVITY)
    private void loadUI() {
        buttonMyProfile=(Button)findViewById(R.id.buttonMyProfile);
        buttonMyTraining=(Button)findViewById(R.id.buttonMyTraining);
        buttonAddWeightMeasurement=(Button)findViewById(R.id.buttonAddWeightMeasurement);
        buttonRateMyTrainer=(Button)findViewById(R.id.buttonRateMyTrainer);
        buttonTrainersList=(Button)findViewById(R.id.buttonTrainersList);
    }

    private void loadActions() {

        buttonMyProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeTraineeActivity.this , MyProfileActivity.class);
                startActivity(intent);
            }
        });

        buttonMyTraining.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeTraineeActivity.this , MyTrainingActivity.class);
                startActivity(intent);
            }
        });

        buttonAddWeightMeasurement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                for (Map.Entry<String , WeightTrainee> item : DBLayer.getInstance().getMAPWeightTrainees().entrySet())
                    if (item.getValue().getTraineeId().equals(App.getUserId())){
                        Calendar calendar=Calendar.getInstance();
                        calendar.setTimeInMillis(item.getValue().getDate());

                        if (calendar.get(Calendar.YEAR) == Calendar.getInstance().get(Calendar.YEAR) &&
                                calendar.get(Calendar.MONTH) == Calendar.getInstance().get(Calendar.MONTH) &&
                                calendar.get(Calendar.DAY_OF_MONTH) == Calendar.getInstance().get(Calendar.DAY_OF_MONTH))
                        {
                            Toasty.warning( getBaseContext(), "Already Add It Today", Toast.LENGTH_SHORT, true).show();
                            return;
                        }
                    }

                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
                LayoutInflater inflater = getLayoutInflater();
                View dialogView = inflater.inflate(R.layout.layout_add_weight , null);
                dialogBuilder.setView(dialogView);
                final SeekBar seekBarWeight=(SeekBar)dialogView.findViewById(R.id.seekBarWeight);
                final TextView textViewAddWeight = (TextView) dialogView.findViewById(R.id.textViewAddWeight);
                final Button buttonAddWeight = (Button) dialogView.findViewById(R.id.buttonAddWeight);

                seekBarWeight.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                        textViewAddWeight.setText("Weight - "+String.format("%.1f",i/1000.0) +" - KG");
                    }
                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) { }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) { }
                });

                buttonAddWeight.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {




                        Toasty.success( getBaseContext(), "Successful", Toast.LENGTH_SHORT, true).show();
                        DBLayer.getInstance().getMAPTrainees().get(App.getUserId()).addWeight(seekBarWeight.getProgress());
                        buttonAddWeight.setEnabled(false);
                        seekBarWeight.setEnabled(false);
                    }
                });

                AlertDialog alertDialog = dialogBuilder.create();
                alertDialog.show();
            }
        });

        buttonRateMyTrainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
                LayoutInflater inflater = getLayoutInflater();
                View dialogView = inflater.inflate(R.layout.layout_rating , null);
                dialogBuilder.setView(dialogView);
                final RatingBar ratingBarBook = (RatingBar)dialogView.findViewById(R.id.ratingBarBook);
                final TextView textViewRatingHeader = (TextView) dialogView.findViewById(R.id.textViewRatingHeader);

                String myRttId=DBLayer.getInstance().getMAPTrainees().get(App.getUserId()).getMyRttId();

                if (myRttId.isEmpty())
                {
                    Toasty.warning(getBaseContext(), "Not Have Any Trainer", Toast.LENGTH_SHORT, true).show();
                    return;
                }

                String trainerId=DBLayer.getInstance().getMAPRTT().get(myRttId).getTrainerId();
                Trainer trainer=DBLayer.getInstance().getMAPTrainers().get(trainerId);

                if (trainer != null)
                    textViewRatingHeader.setText("Rate The Trainer - "+trainer.getName());

                if (DBLayer.getInstance().getMAPRTT().get(myRttId).getRate()>0)
                    ratingBarBook.setRating((float) DBLayer.getInstance().getMAPRTT().get(myRttId).getRate());

                ratingBarBook.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                    @Override
                    public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                        DBLayer.getInstance().getMAPRTT().get(myRttId).setRate((double) ratingBarBook.getRating());
                        Toasty.success( getBaseContext(), "Successful", Toast.LENGTH_SHORT, true).show();
                    }
                });
                AlertDialog alertDialog = dialogBuilder.create();
                alertDialog.show();
            }
        });

        buttonTrainersList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeTraineeActivity.this , TrainersListActivity.class);
                startActivity(intent);
            }
        });

        ((Button)findViewById(R.id.buttonSignOut)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(HomeTraineeActivity.this , WelcomeActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    public Activity getActivity(){
        return this;
    }


}
