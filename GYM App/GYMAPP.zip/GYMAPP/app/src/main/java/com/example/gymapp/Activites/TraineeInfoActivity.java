package com.example.gymapp.Activites;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;

import com.example.gymapp.Objects.RTT;
import com.example.gymapp.Objects.Trainee;
import com.example.gymapp.Objects.WeightTrainee;
import com.example.gymapp.Others.App;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

public class TraineeInfoActivity extends AppCompatActivity {

    // Declare Variables For UI
    TextView textViewNameTrainee, textViewPhoneNumber, textViewGender, textViewDOB,
            textViewStartDate, textViewEndDate, textViewReasonRegister, textViewPatternTraining,
            textViewLength, textViewWeight, textViewOtherInfo;

    CheckBox checkBoxWeaknessShoulders, checkBoxWeaknessLegs, checkBoxWeaknessChest,
            checkBoxWeaknessArms, checkBoxDiseasesHeartRate, checkBoxDiseasesDiabetes,
            checkBoxDiseasesHighBloodPressure;

    ArrayList<String> arrayListWeight;
    String traineeId="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trainee_info);

        traineeId=this.getIntent().getExtras().getString(App.TRAINEE_INFO_KEY);

        String userId=null;
        try {
            userId=App.getUserId();
        } catch (Exception e){
            userId=null;
        }

        if (userId != null && traineeId.equals(userId))
            getSupportActionBar().setTitle("TRAINEE - MY INFO");
        else {
            getSupportActionBar().setTitle("TRAINEE INFO");
        }

        arrayListWeight=new ArrayList<>();
        for (Map.Entry<String , WeightTrainee> item : DBLayer.getInstance().getMAPWeightTrainees().entrySet())
            if (item.getValue().getTraineeId().equals(traineeId) ){
                Calendar calendar=Calendar.getInstance();
                calendar.setTimeInMillis(item.getValue().getDate());
                arrayListWeight.add(calendar.get(Calendar.YEAR)+"/"+calendar.get(Calendar.MONTH)+"/"+calendar.get(Calendar.DAY_OF_MONTH)+" - Weight - "+String.format("%.1f",item.getValue().getWeight()/1000.0) +" - KG");
            }

        loadUI();
    }

    // (CONNECT LAYOUT ELEMENTS WITH ACTIVITY)
    private void loadUI() {
        textViewNameTrainee=(TextView)findViewById(R.id.textViewNameTrainee);
        textViewPhoneNumber=(TextView)findViewById(R.id.textViewPhoneNumber);
        textViewGender=(TextView)findViewById(R.id.textViewGender);
        textViewDOB=(TextView)findViewById(R.id.textViewDOB);
        textViewStartDate=(TextView)findViewById(R.id.textViewStartDate);
        textViewEndDate=(TextView)findViewById(R.id.textViewEndDate);
        textViewReasonRegister=(TextView)findViewById(R.id.textViewReasonRegister);
        textViewPatternTraining=(TextView)findViewById(R.id.textViewPatternTraining);
        textViewLength=(TextView)findViewById(R.id.textViewLength);
        textViewWeight=(TextView)findViewById(R.id.textViewWeight);
        textViewOtherInfo=(TextView)findViewById(R.id.textViewOtherInfo);

        checkBoxWeaknessShoulders=(CheckBox)findViewById(R.id.checkBoxWeaknessShoulders);
        checkBoxWeaknessChest=(CheckBox)findViewById(R.id.checkBoxWeaknessChest);
        checkBoxWeaknessArms=(CheckBox)findViewById(R.id.checkBoxWeaknessArms);
        checkBoxWeaknessLegs=(CheckBox)findViewById(R.id.checkBoxWeaknessLegs);
        checkBoxDiseasesHeartRate=(CheckBox)findViewById(R.id.checkBoxDiseasesHeartRate);
        checkBoxDiseasesDiabetes=(CheckBox)findViewById(R.id.checkBoxDiseasesDiabetes);
        checkBoxDiseasesHighBloodPressure=(CheckBox)findViewById(R.id.checkBoxDiseasesHighBloodPressure);
        ListView listViewWeight=(ListView)findViewById(R.id.listViewWeight);


        ArrayAdapter adapter = new ArrayAdapter<String>(this,
                R.layout.item_weight, arrayListWeight);

        listViewWeight.setAdapter(adapter);

        Trainee trainee= DBLayer.getInstance().getMAPTrainees().get(traineeId);

        if (trainee != null){
            textViewNameTrainee.setText(trainee.getName());
            textViewPhoneNumber.setText("Phone Number - "+trainee.getPhoneNumber());
            textViewGender.setText("Gender - "+trainee.getGender());
            textViewDOB.setText("Date Of Birth - "+trainee.getDateOfBirth());
            textViewStartDate.setText("Start Date - "+trainee.getStartDate());
            textViewEndDate.setText("End Date - "+trainee.getEndDate());
            textViewReasonRegister.setText("Reason Register - "+trainee.getReasonRegister());
            textViewPatternTraining.setText("Pattern Training - "+trainee.getPatternTraining());
            textViewLength.setText("Length - "+trainee.getLength()+" - CM");
            textViewWeight.setText("Weight - "+String.format("%.1f",trainee.getWeight()/1000.0) +" - KG");
            textViewOtherInfo.setText(trainee.getOtherInfo());

            String[] diseases = trainee.getDiseases().split(" - ");
            String[] weakness = trainee.getWeakness().split(" - ");

            for (int i=0 ;i<diseases.length; i++)
                switch (diseases[i])
                {
                    case Trainee.HEART_RATE:
                        checkBoxDiseasesHeartRate.setChecked(true);
                        break;
                    case Trainee.HIGH_BLOOD_PRESSURE:
                        checkBoxDiseasesHighBloodPressure.setChecked(true);
                        break;
                    case Trainee.DIABETES:
                        checkBoxDiseasesDiabetes.setChecked(true);
                        break;
                }

            for (int i=0 ;i<weakness.length; i++)
                switch (weakness[i])
                {
                    case Trainee.SHOULDERS:
                        checkBoxWeaknessShoulders.setChecked(true);
                        break;
                    case Trainee.ARMS:
                        checkBoxWeaknessArms.setChecked(true);
                        break;
                    case Trainee.CHEST:
                        checkBoxWeaknessChest.setChecked(true);
                        break;
                    case Trainee.LEGS:
                        checkBoxWeaknessLegs.setChecked(true);
                        break;
                }
        }
    }
}
