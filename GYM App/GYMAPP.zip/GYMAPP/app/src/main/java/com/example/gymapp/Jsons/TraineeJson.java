package com.example.gymapp.Jsons;

import com.example.gymapp.Objects.Trainee;

public class TraineeJson {

    public String id;
    public String photoLink;
    public String dateOfBirth;
    public String name;
    public String phoneNumber;

    public int length;
    public int weight;
    public String startDate;
    public String endDate;
    public String weakness;
    public String diseases;
    public String otherInfo;
    public String reasonRegister;
    public String patternTraining;
    public String gender;

    public Trainee ConvertToObject(){
        Trainee object = new Trainee(id, photoLink, dateOfBirth, name, phoneNumber, gender, length, weight, startDate, endDate, weakness, diseases, otherInfo, reasonRegister, patternTraining);
        return object;
    }
}
