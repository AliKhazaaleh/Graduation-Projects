package com.example.gymapp.Activites;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.example.gymapp.Others.App;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;
import com.google.firebase.auth.FirebaseAuth;

import es.dmoral.toasty.Toasty;

public class SplashTraineeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_trainee);
        getSupportActionBar().setTitle("GYM APP - TRAINEE");
        DBLayer.getInstance().configTraineeMode();

        Thread timer = new Thread() {
            public void run() {
                try {
                    sleep(5000);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (App.isLoginAndVerifyUser()){
                        if (DBLayer.getInstance().getMAPTrainees().containsKey(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
                            Intent intent = new Intent(SplashTraineeActivity.this , HomeTraineeActivity.class);
                            startActivity(intent);
                        } else {
                            Intent intent = new Intent(SplashTraineeActivity.this , RegisterTraineeActivity.class);
                            startActivity(intent);
                        }
                    } else {
                        Intent intent = new Intent(SplashTraineeActivity.this , AuthenticationTraineeActivity.class);
                        startActivity(intent);
                    }
                }
            }
        };
        timer.start();
    }


    @Override
    protected void onRestart() {
        super.onRestart();
        Intent intent = new Intent(SplashTraineeActivity.this , WelcomeActivity.class);
        startActivity(intent);
    }
}
