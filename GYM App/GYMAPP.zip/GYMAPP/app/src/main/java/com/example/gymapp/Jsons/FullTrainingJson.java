package com.example.gymapp.Jsons;

import com.example.gymapp.Objects.FullTraining;

public class FullTrainingJson {

    public String id;
    public String traineeId;
    public String trainerId;
    public long date;
    public String trainingList;
    public String status;

    public FullTraining ConvertToObject(){
        FullTraining object = new FullTraining(id, traineeId, trainerId, date, trainingList, status);
        return object;
    }
}
