package com.example.gymapp.Activites;

import android.app.Activity;
import android.content.Intent;
import android.icu.text.DateFormat;
import android.icu.text.SimpleDateFormat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.DatePicker;

import com.example.gymapp.Objects.RTT;
import com.example.gymapp.Objects.Trainee;
import com.example.gymapp.Objects.Trainer;
import com.example.gymapp.Objects.User;
import com.example.gymapp.Others.App;
import com.example.gymapp.Others.AppRefDB;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;
import com.google.firebase.auth.FirebaseAuth;

import android.app.DatePickerDialog;
import android.widget.Toast;

import java.util.Calendar;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import es.dmoral.toasty.Toasty;

public class RegisterTraineeActivity extends AppCompatActivity {

    // Declare Variables For UI
    public TextView textViewDOB, textViewStartDate, textViewEndDate;
    private Spinner spinnerGender,spinnerReasonRegister,spinnerPatternTraining,spinnerTrainer;
    private SeekBar seekBarLength, seekBarWeight;
    // editTextNameTrainee, editTextPhoneNumber, editTextOtherInfo
    Calendar calendarStartDate,calendarEndDate,calendarDOB;

    List<String> LSTSpinnerGender, LSTSpinnerReasonRegister, LSTSpinnerPatternTraining, LSTSpinnerTrainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_trainee);
        getSupportActionBar().setTitle("TRAINEE - REGISTER");

        loadObjects();
        loadUI();
        loadActions();
    }

    private void loadObjects() {
        LSTSpinnerGender = new ArrayList<>();
        LSTSpinnerGender.add(User.MALE);
        LSTSpinnerGender.add(User.FEMALE);

        LSTSpinnerReasonRegister= new ArrayList<>();
        LSTSpinnerReasonRegister.add(Trainee.BUILDING);
        LSTSpinnerReasonRegister.add(Trainee.FITNESS);
        LSTSpinnerReasonRegister.add(Trainee.WEIGHT_LOSS);

        LSTSpinnerPatternTraining= new ArrayList<>();
        LSTSpinnerPatternTraining.add(Trainee.DAYS3);
        LSTSpinnerPatternTraining.add(Trainee.DAYS6);

        LSTSpinnerTrainer= new ArrayList<>();
        LSTSpinnerTrainer.add(Trainer.DEFAULT);

        for (Map.Entry<String , Trainer> item : DBLayer.getInstance().getMAPTrainers().entrySet()){
            if (item.getValue().getStatus().equals(Trainer.ACCEPT))
                LSTSpinnerTrainer.add(item.getValue().getName());
        }
        calendarStartDate = Calendar.getInstance();
        calendarEndDate = Calendar.getInstance();
        calendarDOB = Calendar.getInstance();
    }

    // (CONNECT LAYOUT ELEMENTS WITH ACTIVITY)
    private void loadUI() {

        spinnerGender=(Spinner)findViewById(R.id.spinnerGender);
        spinnerPatternTraining=(Spinner)findViewById(R.id.spinnerPatternTraining);
        spinnerReasonRegister=(Spinner)findViewById(R.id.spinnerReasonRegister);
        spinnerTrainer=(Spinner)findViewById(R.id.spinnerTrainer);

        seekBarLength=(SeekBar)findViewById(R.id.seekBarLength);
        seekBarWeight=(SeekBar)findViewById(R.id.seekBarWeight);

        textViewDOB=(TextView)findViewById(R.id.textViewDOB);
        textViewStartDate=(TextView)findViewById(R.id.textViewStartDate);
        textViewEndDate=(TextView)findViewById(R.id.textViewEndDate);

        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item , LSTSpinnerGender);
        spinnerGender.setAdapter(adapter1);

        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item , LSTSpinnerReasonRegister);
        spinnerReasonRegister.setAdapter(adapter2);

        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item , LSTSpinnerPatternTraining);
        spinnerPatternTraining.setAdapter(adapter3);

        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item , LSTSpinnerTrainer);
        spinnerTrainer.setAdapter(adapter4);

    }

    private void loadActions() {

        seekBarLength.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                ((TextView)findViewById(R.id.textView4)).setText("Length - "+i+" - CM");
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });


        seekBarWeight.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                ((TextView)findViewById(R.id.textView5)).setText("Weight - "+String.format("%.1f",i/1000.0) +" - KG");
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        textViewDOB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear,
                                          int dayOfMonth) {
                        // TODO Auto-generated method stub
                        calendarDOB.set(Calendar.YEAR, year);
                        calendarDOB.set(Calendar.MONTH, monthOfYear);
                        calendarDOB.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        textViewDOB.setText(year+"-"+(monthOfYear+1)+"-"+dayOfMonth);
                    }
                };
                new DatePickerDialog(getActivity(), date, calendarDOB
                        .get(Calendar.YEAR), calendarDOB.get(Calendar.MONTH),
                        calendarDOB.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        textViewStartDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear,
                                          int dayOfMonth) {
                        // TODO Auto-generated method stub
                        calendarStartDate.set(Calendar.YEAR, year);
                        calendarStartDate.set(Calendar.MONTH, monthOfYear);
                        calendarStartDate.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        textViewStartDate.setText(year+"-"+(monthOfYear+1)+"-"+dayOfMonth);
                    }
                };
                new DatePickerDialog(getActivity(), date, calendarStartDate
                        .get(Calendar.YEAR), calendarStartDate.get(Calendar.MONTH),
                        calendarStartDate.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        textViewEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear,
                                          int dayOfMonth) {
                        // TODO Auto-generated method stub
                        calendarEndDate.set(Calendar.YEAR, year);
                        calendarEndDate.set(Calendar.MONTH, monthOfYear);
                        calendarEndDate.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        textViewEndDate.setText(year+"-"+(monthOfYear+1)+"-"+dayOfMonth);
                    }
                };
                new DatePickerDialog(getActivity(), date, calendarEndDate
                        .get(Calendar.YEAR), calendarEndDate.get(Calendar.MONTH),
                        calendarEndDate.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        ((Button)findViewById(R.id.buttonCompleteRegister)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String validations="";

                String nameTrainee=((EditText)findViewById(R.id.editTextNameTrainee)).getText().toString();
                if (nameTrainee.isEmpty())
                    validations+="- Add User Name.\n";

                if (textViewDOB.getText().toString().equals("1900-1-1"))
                    validations+="- Set Date Of Birth.\n";

                if (textViewStartDate.getText().toString().equals("1900-1-1"))
                    validations+="- Set Start Date.\n";

                if (textViewEndDate.getText().toString().equals("1900-1-1"))
                    validations+="- Set End Date.\n";

                if (calendarEndDate.compareTo(calendarStartDate) == -1)
                    validations+="- Must be EndDate more than StartDate.\n";

                if (Calendar.getInstance().compareTo(calendarDOB) == -1)
                    validations+="- Must be Date Of Birth less than Today Date.\n";

                if (!validations.isEmpty()){
                    Toasty.warning(getBaseContext(), validations, Toast.LENGTH_LONG, true).show();
                    return;
                }

                Trainee trainee=new Trainee();
                trainee.setId(FirebaseAuth.getInstance().getCurrentUser().getUid());
                trainee.setPhotoLink("");

                trainee.setName(nameTrainee);

                trainee.setDateOfBirth(textViewDOB.getText().toString());
                trainee.setStartDate(textViewStartDate.getText().toString());
                trainee.setEndDate(textViewEndDate.getText().toString());

                trainee.setPhoneNumber(((EditText)findViewById(R.id.editTextPhoneNumber)).getText().toString());
                trainee.setOtherInfo(((EditText)findViewById(R.id.editTextOtherInfo)).getText().toString());

                trainee.setGender(spinnerGender.getSelectedItem().toString());
                trainee.setReasonRegister(spinnerReasonRegister.getSelectedItem().toString());
                trainee.setPatternTraining(spinnerPatternTraining.getSelectedItem().toString());

                trainee.setLength(seekBarLength.getProgress());
                trainee.setWeight(seekBarWeight.getProgress());

                List<String>LSTTemp=new ArrayList<>();
                if (((CheckBox)findViewById(R.id.checkBoxDiseasesHeartRate)).isChecked())
                    LSTTemp.add(Trainee.HEART_RATE);

                if (((CheckBox)findViewById(R.id.checkBoxDiseasesDiabetes)).isChecked())
                    LSTTemp.add(Trainee.DIABETES);

                if (((CheckBox)findViewById(R.id.checkBoxDiseasesHighBloodPressure)).isChecked())
                    LSTTemp.add(Trainee.HIGH_BLOOD_PRESSURE);

                String diseases="";
                for (int i=0 ; i<LSTTemp.size() ;i++)
                    if (i==0)
                        diseases=LSTTemp.get(i);
                    else
                        diseases+=" - "+LSTTemp.get(i);

                trainee.setDiseases(diseases);

                LSTTemp.clear();

                if (((CheckBox)findViewById(R.id.checkBoxWeaknessShoulders)).isChecked())
                    LSTTemp.add(Trainee.SHOULDERS);

                if (((CheckBox)findViewById(R.id.checkBoxWeaknessLegs)).isChecked())
                    LSTTemp.add(Trainee.LEGS);

                if (((CheckBox)findViewById(R.id.checkBoxWeaknessChest)).isChecked())
                    LSTTemp.add(Trainee.CHEST);

                if (((CheckBox)findViewById(R.id.checkBoxWeaknessArms)).isChecked())
                    LSTTemp.add(Trainee.ARMS);

                String weakness="";
                for (int i=0 ; i<LSTTemp.size() ;i++)
                    if (i==0)
                        weakness=LSTTemp.get(i);
                    else
                        weakness+=" - "+LSTTemp.get(i);

                trainee.setWeakness(weakness);
                trainee.setMyInfo(trainee);

                String trainerName=spinnerTrainer.getSelectedItem().toString();
                int i = (int)(Math.random() * DBLayer.getInstance().getMAPTrainers().size());

                String trainerIdRandom="";
                String trainerId="";

                for (Map.Entry<String , Trainer> item : DBLayer.getInstance().getMAPTrainers().entrySet()){
                    if (item.getValue().getName().equals(trainerName)){
                        trainerId=item.getValue().getId();
                        break;
                    }
                    i--;
                    if (i==0)
                        trainerIdRandom=item.getValue().getId();
                }

                if (trainerId.isEmpty())
                    trainerId=trainerIdRandom;

                RTT rtt = new RTT(AppRefDB.RefRTT.push().getKey(), trainee.getId(), trainerId, Calendar.getInstance().getTime().toString() , 0, RTT.PENDING);
                rtt.setMyInfo(rtt);

                Toasty.success( getBaseContext(), "Successful Register", Toast.LENGTH_SHORT, true).show();
                Intent intent = new Intent(RegisterTraineeActivity.this , HomeTraineeActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    public Activity getActivity(){
        return this;
    }

}
