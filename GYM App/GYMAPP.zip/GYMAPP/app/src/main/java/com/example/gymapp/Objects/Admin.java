package com.example.gymapp.Objects;

import com.example.gymapp.Others.DBLayer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Admin {
    String id;
    String userName;
    String password;

    public Admin(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }

    public Admin(String id, String userName, String password) {
        this.id = id;
        this.userName = userName;
        this.password = password;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean checkIsAdmin() {
       for (Map.Entry<String , Admin> item : DBLayer.getInstance().getMAPAdmins().entrySet() ){
           if (item.getValue().userName.equals(this.userName) && item.getValue().password.equals(this.password))
                return true;
        }
        return false;
    }

    public List<Trainer> getLSTTrainers(){
        List<Trainer> LST = new ArrayList<>();

        for (Map.Entry<String , Trainer> item : DBLayer.getInstance().getMAPTrainers().entrySet() ){
            LST.add(item.getValue());
        }
        return LST;
    }

    public List<Trainee> getLSTTrainees(){
        List<Trainee> LST = new ArrayList<>();
        for (Map.Entry<String , Trainee> item : DBLayer.getInstance().getMAPTrainees().entrySet() ){
            LST.add(item.getValue());
        }
        return LST;
    }
}
