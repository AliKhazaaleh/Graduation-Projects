package com.example.gymapp.Activites;

import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.gymapp.Others.App;
import com.example.gymapp.Others.AppRefDB;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import java.io.FileNotFoundException;
import java.io.InputStream;

import es.dmoral.toasty.Toasty;

public class UploadPhotoTrainerActivity extends AppCompatActivity {

    // Declare Variables For UI
    private static final int PICK_IMAGE_REQUEST = 1;
    private ImageView imageViewPhoto;
    private ProgressBar progressBar;
    private Button buttonUploadImage;
    private Uri mImageUri;
    private StorageTask mUploadTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_photo_trainer);
        getSupportActionBar().setTitle("TRAINER - UPLOAD PHOTO");

        mLoadUI();
        mLoadActions();
    }

    // (CONNECT LAYOUT ELEMENTS WITH ACTIVITY)
    private void mLoadUI() {
        imageViewPhoto = (ImageView) findViewById(R.id.imageViewPhoto);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        buttonUploadImage = (Button) findViewById(R.id.buttonUploadImage);
    }


    private void mLoadActions() {

        imageViewPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFileChooser();
            }
        });

        buttonUploadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!App.mIsNetworkAvailable(UploadPhotoTrainerActivity.this , view)){
                    return;
                }

                if (mUploadTask != null && mUploadTask.isInProgress()) {
                    Toasty.warning( getBaseContext(), "Upload in progress", Toast.LENGTH_SHORT, true).show();
                } else {
                    uploadFile();
                }
            }
        });
    }

    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {
            if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                    && data != null && data.getData() != null) {
                mImageUri = data.getData();
                final Uri imageUri = data.getData();
                final InputStream imageStream;
                imageStream = getContentResolver().openInputStream(imageUri);

                final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                imageViewPhoto.setImageBitmap(selectedImage);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    private void uploadFile() {

        if (mImageUri != null) {
            final StorageReference ref = AppRefDB.mStorageRef.child(System.currentTimeMillis()
                    + "." + getFileExtension(mImageUri));
            mUploadTask = ref.putFile(mImageUri);

            Task<Uri> urlTask = mUploadTask.addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                    double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                    progressBar.setProgress((int) progress);
                }
            }).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                    if (!task.isSuccessful()) {
                        throw task.getException();
                    }
                    // Continue with the task to get the download URL
                    return ref.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    if (task.isSuccessful()) {
                        Uri downloadUri = task.getResult();

                        DBLayer.getInstance().getMAPTrainers().get(App.getUserId()).setPhotoLink(downloadUri != null ? downloadUri.toString() : "" );
                        Toasty.success( getBaseContext(), "Upload successful", Toast.LENGTH_SHORT, true).show();
                        buttonUploadImage.setEnabled(false);
                        Intent intent = new Intent(UploadPhotoTrainerActivity.this , HomeTrainerActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toasty.error( getBaseContext(), "Not Upload", Toast.LENGTH_SHORT, true).show();
                    }
                }
            });
        } else {
            Toasty.warning( getBaseContext(), "No file selected", Toast.LENGTH_SHORT, true).show();
        }
    }

}
