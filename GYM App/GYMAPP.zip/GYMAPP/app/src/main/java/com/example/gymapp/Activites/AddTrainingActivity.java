package com.example.gymapp.Activites;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.gymapp.Objects.Training;
import com.example.gymapp.Others.App;
import com.example.gymapp.Others.AppRefDB;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import es.dmoral.toasty.Toasty;
import pl.droidsonroids.gif.GifImageView;

public class AddTrainingActivity extends AppCompatActivity {

    // Declare Variables For UI
    private static final int PICK_IMAGE_REQUEST = 1;
    private ProgressBar progressBar;
    private Button buttonUploadTraining;
    private Uri mImageUri;
    private StorageTask mUploadTask;
    private EditText editTextOtherInfoAboutTraining,editTextNameTraining;
    GifImageView imageViewPhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_training);
        getSupportActionBar().setTitle("TRAINER - ADD TRAINING");

        mLoadUI();
        mLoadActions();
    }

    // (CONNECT LAYOUT ELEMENTS WITH ACTIVITY)
    private void mLoadUI() {
        imageViewPhoto = (GifImageView) findViewById(R.id.imageViewPhoto);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        buttonUploadTraining = (Button) findViewById(R.id.buttonUploadTraining);
        editTextOtherInfoAboutTraining=(EditText)findViewById(R.id.editTextOtherInfoAboutTraining);
        editTextNameTraining=(EditText)findViewById(R.id.editTextNameTraining);
    }

    // LOAD ACTIONS
    private void mLoadActions() {

        // ACTION - OPEN GALLERY TO CHOOSE IMAGE
        imageViewPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFileChooser();
            }
        });


        // ACTION - UPLOAD TRAINING TO FIREBASE STORAGE
        buttonUploadTraining.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!App.mIsNetworkAvailable(AddTrainingActivity.this , view)){
                    return;
                }

                if (mUploadTask != null && mUploadTask.isInProgress()) {
                    Toasty.warning( getBaseContext(), "Upload in progress", Toast.LENGTH_SHORT, true).show();
                } else {
                    uploadFile();
                }
            }
        });
    }

    // GALLERY TO CHOOSE IMAGE
    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            mImageUri = data.getData();
            final Uri imageUri = data.getData();
            imageViewPhoto.setImageURI(imageUri);
        }
    }

    // GET TYPE OF PHOTO
    private String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    // UPLOAD TRAINING TO FIREBASE STORAGE
    private void uploadFile() {

        String nameTraining=editTextNameTraining.getText().toString();
        if (nameTraining.isEmpty()) {
            Toasty.warning( getBaseContext(), "Fill Name Of Training", Toast.LENGTH_SHORT, true).show();
            return;
        }

        if (mImageUri != null) {
            final StorageReference ref = AppRefDB.mStorageRef.child(System.currentTimeMillis()
                    + "." + getFileExtension(mImageUri));
            mUploadTask = ref.putFile(mImageUri);

            Task<Uri> urlTask = mUploadTask.addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                    double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                    progressBar.setProgress((int) progress);
                }
            }).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                    if (!task.isSuccessful()) {
                        throw task.getException();
                    }
                    // Continue with the task to get the download URL
                    return ref.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    if (task.isSuccessful()) {
                        Uri downloadUri = task.getResult();

                        Training training=new Training(AppRefDB.RefTrainings.push().getKey(), nameTraining, downloadUri != null ? downloadUri.toString() : "",editTextOtherInfoAboutTraining.getText().toString());
                        DBLayer.getInstance().getMAPTrainers().get(App.getUserId()).addTraining(training);

                        Toasty.success( getBaseContext(), "Upload successful", Toast.LENGTH_SHORT, true).show();
                        buttonUploadTraining.setEnabled(false);
                        Intent intent = new Intent(AddTrainingActivity.this , HomeTrainerActivity.class);
                        startActivity(intent);
                        finish();

                    } else {
                        Toasty.error( getBaseContext(), "Not Upload", Toast.LENGTH_SHORT, true).show();
                    }
                }
            });
        } else {
            Toasty.warning( getBaseContext(), "No file selected", Toast.LENGTH_SHORT, true).show();
        }
    }

}
