package com.example.gymapp.Activites;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.example.gymapp.Adapters.TrainersAdapter;
import com.example.gymapp.Adapters.TrainersAdminAdapter;
import com.example.gymapp.Objects.Trainer;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;

import java.util.ArrayList;
import java.util.Map;

public class TrainersListActivity extends AppCompatActivity {

    // Declare Variables For UI
    ListView listViewTrainers;
    ArrayList<Trainer> arrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trainers_list);
        getSupportActionBar().setTitle("TRAINEE - TRAINERS LIST");

        LoadObjects();
        LoadUI();
    }


    private void LoadObjects() {
        arrayList = new ArrayList<Trainer>();
    }

    // (CONNECT LAYOUT ELEMENTS WITH ACTIVITY)
    private void LoadUI() {
        listViewTrainers=(ListView)findViewById(R.id.listViewTrainers);

        for (Map.Entry<String , Trainer> item : DBLayer.getInstance().getMAPTrainers().entrySet())
            if (item.getValue().getStatus().equals(Trainer.ACCEPT))
                arrayList.add(item.getValue());

        if (arrayList.size()>0) {
            TrainersAdapter customAdapter = new TrainersAdapter(this, arrayList);
            listViewTrainers.setAdapter(customAdapter);
        }
    }
}
