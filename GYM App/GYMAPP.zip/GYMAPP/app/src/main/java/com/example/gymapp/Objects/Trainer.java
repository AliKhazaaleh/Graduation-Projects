package com.example.gymapp.Objects;

import com.example.gymapp.Others.App;
import com.example.gymapp.Others.AppRefDB;
import com.example.gymapp.Others.DBLayer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Trainer extends User{
    String info;
    String status;

    public Trainer(String id, String photoLink, String dateOfBirth, String name, String phoneNumber, String gender, String info, String status) {
        super(id, photoLink, dateOfBirth, name, phoneNumber, gender);
        this.info = info;
        this.status = status;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        AppRefDB.RefTrainers.child(this.getId()).child("status").setValue(status);
        this.status = status;
    }

    public void setMyInfo(Trainer trainer) {
        AppRefDB.RefTrainers.child(trainer.getId()).setValue(trainer);
        DBLayer.getInstance().getMAPTrainers().put(trainer.getId() , trainer);
    }

    public void setPhotoLink(String photoLink) {
        this.photoLink = photoLink;
        AppRefDB.RefTrainers.child(this.getId()).child("photoLink").setValue(photoLink);
    }

    public static final String  PENDING = "Pending";
    public static final String  ACCEPT = "Accept";
    public static final String  REJECT = "Reject";
    public static final String  BLOCK = "Block";
    public static final String  DEFAULT = "Default";

    public void addTraining(Training training) {
        AppRefDB.RefTrainings.child(training.id).setValue(training);
        DBLayer.getInstance().getMAPTrainings().put(training.getId(),training);
    }

    public void addFullTraining(FullTraining fullTraining) {
        AppRefDB.RefFullTraining.child(fullTraining.getId()).setValue(fullTraining);
        DBLayer.getInstance().getMAPFullTraining().put(fullTraining.getId(), fullTraining);
    }
}
