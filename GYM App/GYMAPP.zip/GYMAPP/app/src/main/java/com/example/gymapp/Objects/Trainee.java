package com.example.gymapp.Objects;

import com.example.gymapp.Others.App;
import com.example.gymapp.Others.AppRefDB;
import com.example.gymapp.Others.DBLayer;

import java.util.Map;

public class Trainee extends User {
    int length;
    int weight;
    String startDate;
    String endDate;
    String weakness;
    String diseases;
    String otherInfo;
    String reasonRegister;
    String patternTraining;

    public Trainee(){
        super();
    }
    public Trainee(String id, String photoLink, String dateOfBirth, String name, String phoneNumber, String gender, int length, int weight, String startDate, String endDate, String weakness, String diseases, String otherInfo, String reasonRegister, String patternTraining) {

        super(id, photoLink, dateOfBirth, name, phoneNumber, gender);

        this.length = length;
        this.weight = weight;
        this.startDate = startDate;
        this.endDate = endDate;
        this.weakness = weakness;
        this.diseases = diseases;
        this.otherInfo = otherInfo;
        this.reasonRegister = reasonRegister;
        this.patternTraining = patternTraining;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getWeakness() {
        return weakness;
    }

    public void setWeakness(String weakness) {
        this.weakness = weakness;
    }

    public String getDiseases() {
        return diseases;
    }

    public void setDiseases(String diseases) {
        this.diseases = diseases;
    }

    public String getOtherInfo() {
        return otherInfo;
    }

    public void setOtherInfo(String otherInfo) {
        this.otherInfo = otherInfo;
    }

    public String getReasonRegister() {
        return reasonRegister;
    }

    public void setReasonRegister(String reasonRegister) {
        this.reasonRegister = reasonRegister;
    }

    public String getPatternTraining() {
        return patternTraining;
    }

    public void setPatternTraining(String patternTraining) {
        this.patternTraining = patternTraining;
    }

    public void setMyInfo(Trainee trainee){
        AppRefDB.RefTrainees.child(trainee.getId()).setValue(trainee);
        DBLayer.getInstance().getMAPTrainees().put(trainee.getId() , trainee);
    }

    public String getMyRttId()
    {
        String rttId="";
        for (Map.Entry<String , RTT> item : DBLayer.getInstance().getMAPRTT().entrySet())
            if (item.getValue().getTraineeId().equals(this.getId()) && item.getValue().getStatus().equals(RTT.ACCEPT))
            {
                rttId=item.getValue().getId();
                break;
            }
        return rttId;
    }

    public void addWeight(double weight){
        String idWeight= AppRefDB.RefWeightTrainees.push().getKey();
        WeightTrainee weightTrainee=new WeightTrainee(idWeight, this.id, weight, App.CurrentTimeMillis());
        AppRefDB.RefWeightTrainees.child(idWeight).setValue(weightTrainee);
        DBLayer.getInstance().getMAPWeightTrainees().put(idWeight , weightTrainee);
    }

    public void setPhotoLink(String photoLink) {
        this.photoLink = photoLink;
        AppRefDB.RefTrainees.child(this.getId()).child("photoLink").setValue(photoLink);
    }

    // Weakness TRAINEE
    public static final String SHOULDERS = "Shoulders";
    public static final String LEGS = "Legs";
    public static final String CHEST = "Chest";
    public static final String ARMS = "Arms";

    // Diseases TRAINEE
    public static final String HEART_RATE = "Heart Rate";
    public static final String DIABETES = "Diabetes";
    public static final String HIGH_BLOOD_PRESSURE = "High Blood Pressure";

    // Reason Register
    public static final String BUILDING = "Building";
    public static final String FITNESS = "Fitness";
    public static final String WEIGHT_LOSS= "Weight Loss";

    // Training Pattern
    public static final String  DAYS3= "3 Days";
    public static final String  DAYS6= "6 Days";
}
