package com.example.gymapp.Activites;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.gymapp.R;
import com.google.firebase.auth.FirebaseAuth;

public class HomeTrainerActivity extends AppCompatActivity {

    // Declare Variables For UI
    Button buttonMyRequests,buttonMyTrainees,buttonAddTraining,buttonUpdateInfoTrainer,buttonUploadMyPhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_trainer);
        getSupportActionBar().setTitle("TRAINER - HOME");

        loadUI();
        loadActions();
    }

    // (CONNECT LAYOUT ELEMENTS WITH ACTIVITY)
    private void loadUI() {
        buttonMyRequests=(Button)findViewById(R.id.buttonMyRequests);
        buttonMyTrainees=(Button)findViewById(R.id.buttonMyTrainees);
        buttonAddTraining=(Button)findViewById(R.id.buttonAddTraining);
        buttonUpdateInfoTrainer=(Button)findViewById(R.id.buttonUpdateInfoTrainer);
        buttonUploadMyPhoto=(Button)findViewById(R.id.buttonUploadMyPhoto);
    }

    private void loadActions() {
        buttonMyRequests.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeTrainerActivity.this , MyRequestsActivity.class);
                startActivity(intent);
            }
        });

        buttonMyTrainees.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeTrainerActivity.this , MyTraineesActivity.class);
                startActivity(intent);
            }
        });

        buttonAddTraining.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeTrainerActivity.this , AddTrainingActivity.class);
                startActivity(intent);
            }
        });

        buttonUpdateInfoTrainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeTrainerActivity.this , UpdateInfoTrainerActivity.class);
                startActivity(intent);
            }
        });

        buttonUploadMyPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeTrainerActivity.this , UploadPhotoTrainerActivity.class);
                startActivity(intent);
            }
        });

        ((Button)findViewById(R.id.buttonSignOut)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(HomeTrainerActivity.this , WelcomeActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
