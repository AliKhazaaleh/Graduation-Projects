package com.example.gymapp.Activites;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import com.example.gymapp.Adapters.MyRequestsAdapter;
import com.example.gymapp.Objects.RTT;
import com.example.gymapp.Others.App;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MyRequestsActivity extends AppCompatActivity {

    // Declare Variables For UI
    int countAccept,countReject,countPending;
    ArrayList<RTT> arrayList;
    ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_requests);
        getSupportActionBar().setTitle("TRAINER - MY REQUESTS");

        loadObjects();
        loadUI();

    }

    private void loadObjects() {
        arrayList = new ArrayList<RTT>();

        countAccept=0;
        countReject=0;
        countPending=0;

        for (Map.Entry<String , RTT> item : DBLayer.getInstance().getMAPRTT().entrySet()){
            if (item.getValue().getTrainerId().equals(App.getUserId()) && !item.getValue().getStatus().equals(RTT.TERMINATE)){
                arrayList.add(item.getValue());
                switch (item.getValue().getStatus()){
                    case RTT.ACCEPT:
                        countAccept++;
                        break;
                    case RTT.REJECT:
                        countReject++;
                        break;
                    case RTT.PENDING:
                        countPending++;
                        break;
                }
            }
        }
    }

    // (CONNECT LAYOUT ELEMENTS WITH ACTIVITY)
    private void loadUI() {
        ((TextView) findViewById(R.id.textViewCountPending)).setText(countPending + " Pending");
        ((TextView) findViewById(R.id.textViewCountAccept)).setText(countAccept + " Accept");
        ((TextView) findViewById(R.id.textViewCountReject)).setText(countReject + " Reject");
        list = (ListView) findViewById(R.id.listViewMyRequest);

        List<TextView> listTextViewCount=new ArrayList<>();
        listTextViewCount.add(((TextView) findViewById(R.id.textViewCountPending)));
        listTextViewCount.add(((TextView) findViewById(R.id.textViewCountAccept)));
        listTextViewCount.add(((TextView) findViewById(R.id.textViewCountReject)));

        if (arrayList.size() > 0) {
            MyRequestsAdapter customAdapter = new MyRequestsAdapter(this, arrayList, listTextViewCount);
            list.setAdapter(customAdapter);
        }
    }

    public static void updateCountView(){
    }
}
