package com.example.gymapp.Jsons;

import com.example.gymapp.Objects.RTT;

public class RTTJson {
    public String id;
    public String traineeId;
    public String trainerId;
    public String date;
    public double rate;
    public String status;

    public RTT ConvertToObject(){
        RTT object = new RTT(id, traineeId, trainerId, date, rate,status );
        return object;
    }
}
