package com.example.gymapp.Jsons;

import com.example.gymapp.Objects.Training;

public class TrainingJson {

    public String id;
    public String name;
    public String photoLink;
    public String info;

    public Training ConvertToObject(){
        Training object = new Training(id, name, photoLink, info);
        return object;
    }
}
