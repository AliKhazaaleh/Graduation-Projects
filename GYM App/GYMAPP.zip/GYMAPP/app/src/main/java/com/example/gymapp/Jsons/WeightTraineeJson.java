package com.example.gymapp.Jsons;

import com.example.gymapp.Objects.WeightTrainee;

public class WeightTraineeJson {
    public String id;
    public String traineeId;
    public double weight;
    public long date;

    public WeightTrainee ConvertToObject(){
        WeightTrainee object = new WeightTrainee(id, traineeId, weight, date);
        return object;
    }
}
