package com.example.gymapp.Activites;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gymapp.Objects.Trainer;
import com.example.gymapp.Objects.User;
import com.example.gymapp.R;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import es.dmoral.toasty.Toasty;

public class RegisterTrainerActivity extends AppCompatActivity {

    // Declare Variables For UI
    public TextView textViewDOB;
    private Spinner spinnerGender;
    Calendar calendarDOB;

    List<String> LSTSpinnerGender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_trainer);
        getSupportActionBar().setTitle("TRAINER - REGISTER");

        loadObjects();
        loadUI();
        loadActions();
    }

    private void loadObjects() {
        LSTSpinnerGender = new ArrayList<>();
        LSTSpinnerGender.add(User.MALE);
        LSTSpinnerGender.add(User.FEMALE);
        calendarDOB = Calendar.getInstance();
    }

    // (CONNECT LAYOUT ELEMENTS WITH ACTIVITY)
    private void loadUI() {
        spinnerGender=(Spinner)findViewById(R.id.spinnerGender);
        textViewDOB=(TextView)findViewById(R.id.textViewDOB);

        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item , LSTSpinnerGender);
        spinnerGender.setAdapter(adapter1);
    }

    private void loadActions() {
        textViewDOB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear,
                                          int dayOfMonth) {
                        // TODO Auto-generated method stub
                        calendarDOB.set(Calendar.YEAR, year);
                        calendarDOB.set(Calendar.MONTH, monthOfYear);
                        calendarDOB.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        textViewDOB.setText(year+"-"+(monthOfYear+1)+"-"+dayOfMonth);
                    }
                };
                new DatePickerDialog(getActivity(), date, calendarDOB
                        .get(Calendar.YEAR), calendarDOB.get(Calendar.MONTH),
                        calendarDOB.get(Calendar.DAY_OF_MONTH)).show();
            }
        });



        ((Button)findViewById(R.id.buttonCompleteRegister)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String validations="";

                String nameTrainee=((EditText)findViewById(R.id.editTextNameTrainee)).getText().toString();
                String phoneNumberTrainer=((EditText)findViewById(R.id.editTextPhoneNumber)).getText().toString();

                if (nameTrainee.isEmpty())
                    validations+="- Add User Name.\n";

                if (textViewDOB.getText().toString().equals("1900-1-1"))
                    validations+="- Set Date Of Birth.\n";

                if (phoneNumberTrainer.isEmpty())
                    validations+="- Set Phone Number.\n";

                if (Calendar.getInstance().compareTo(calendarDOB) == -1)
                    validations+="- Must be Date Of Birth less than Today Date.\n";

                if (!validations.isEmpty()){
                    Toasty.warning(getBaseContext(), validations, Toast.LENGTH_LONG, true).show();
                    return;
                }

                Trainer trainer=new Trainer(FirebaseAuth.getInstance().getCurrentUser().getUid(),
                        "",
                        textViewDOB.getText().toString(),
                        ((EditText)findViewById(R.id.editTextNameTrainee)).getText().toString(),
                        ((EditText)findViewById(R.id.editTextPhoneNumber)).getText().toString(),
                        spinnerGender.getSelectedItem().toString(),
                        ((EditText)findViewById(R.id.editTextOtherInfo)).getText().toString(),
                        Trainer.PENDING);

                trainer.setMyInfo(trainer);
                Toasty.success( getBaseContext(), "Successful Register", Toast.LENGTH_SHORT, true).show();
                Intent intent = new Intent(RegisterTrainerActivity.this , HomeTrainerActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }


    public Activity getActivity(){
        return this;
    }

}

