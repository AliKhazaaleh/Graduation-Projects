package com.example.gymapp.Activites;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gymapp.Objects.RTT;
import com.example.gymapp.Objects.Trainee;
import com.example.gymapp.Objects.Trainer;
import com.example.gymapp.Objects.User;
import com.example.gymapp.Others.App;
import com.example.gymapp.Others.AppRefDB;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import es.dmoral.toasty.Toasty;

public class UpdateInfoTraineeActivity extends AppCompatActivity {

    // Declare Variables For UI
    public TextView textViewDOB, textViewStartDate, textViewEndDate;
    private Spinner spinnerGender,spinnerReasonRegister,spinnerPatternTraining,spinnerTrainer;
    private SeekBar seekBarLength, seekBarWeight;
    Calendar calendarStartDate,calendarEndDate,calendarDOB;

    List<String> LSTSpinnerGender, LSTSpinnerReasonRegister, LSTSpinnerPatternTraining, LSTSpinnerTrainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_info_trainee);
        getSupportActionBar().setTitle("TRAINEE - UPDATE INFO");

        loadObjects();
        loadUI();
        loadCurrentInfo();
        loadActions();
    }


    private void loadObjects() {
        LSTSpinnerGender = new ArrayList<>();
        LSTSpinnerGender.add(User.MALE);
        LSTSpinnerGender.add(User.FEMALE);

        LSTSpinnerReasonRegister= new ArrayList<>();
        LSTSpinnerReasonRegister.add(Trainee.BUILDING);
        LSTSpinnerReasonRegister.add(Trainee.FITNESS);
        LSTSpinnerReasonRegister.add(Trainee.WEIGHT_LOSS);

        LSTSpinnerPatternTraining= new ArrayList<>();
        LSTSpinnerPatternTraining.add(Trainee.DAYS3);
        LSTSpinnerPatternTraining.add(Trainee.DAYS6);

        LSTSpinnerTrainer= new ArrayList<>();
        LSTSpinnerTrainer.add(Trainer.DEFAULT);

        for (Map.Entry<String , Trainer> item : DBLayer.getInstance().getMAPTrainers().entrySet()){
            if (item.getValue().getStatus().equals(Trainer.ACCEPT))
                LSTSpinnerTrainer.add(item.getValue().getName());
        }

        calendarStartDate = Calendar.getInstance();
        calendarEndDate = Calendar.getInstance();
        calendarDOB = Calendar.getInstance();
    }

    // (CONNECT LAYOUT ELEMENTS WITH ACTIVITY)
    private void loadUI() {

        spinnerGender=(Spinner)findViewById(R.id.spinnerGender);
        spinnerPatternTraining=(Spinner)findViewById(R.id.spinnerPatternTraining);
        spinnerReasonRegister=(Spinner)findViewById(R.id.spinnerReasonRegister);
        spinnerTrainer=(Spinner)findViewById(R.id.spinnerTrainer);

        seekBarLength=(SeekBar)findViewById(R.id.seekBarLength);
        seekBarWeight=(SeekBar)findViewById(R.id.seekBarWeight);

        textViewDOB=(TextView)findViewById(R.id.textViewDOB);
        textViewStartDate=(TextView)findViewById(R.id.textViewStartDate);
        textViewEndDate=(TextView)findViewById(R.id.textViewEndDate);

        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item , LSTSpinnerGender);
        spinnerGender.setAdapter(adapter1);

        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item , LSTSpinnerReasonRegister);
        spinnerReasonRegister.setAdapter(adapter2);

        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item , LSTSpinnerPatternTraining);
        spinnerPatternTraining.setAdapter(adapter3);

        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item , LSTSpinnerTrainer);
        spinnerTrainer.setAdapter(adapter4);
    }

    private void loadActions() {

        seekBarLength.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                ((TextView)findViewById(R.id.textView4)).setText("Length - "+i+" - CM");
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });


        seekBarWeight.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                ((TextView)findViewById(R.id.textView5)).setText("Weight - "+String.format("%.1f",i/1000.0) +" - KG");
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        textViewDOB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear,
                                          int dayOfMonth) {
                        // TODO Auto-generated method stub
                        calendarDOB.set(Calendar.YEAR, year);
                        calendarDOB.set(Calendar.MONTH, monthOfYear);
                        calendarDOB.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        textViewDOB.setText(year+"-"+(monthOfYear+1)+"-"+dayOfMonth);
                    }
                };
                new DatePickerDialog(getActivity(), date, calendarDOB
                        .get(Calendar.YEAR), calendarDOB.get(Calendar.MONTH),
                        calendarDOB.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        textViewStartDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear,
                                          int dayOfMonth) {
                        // TODO Auto-generated method stub
                        calendarStartDate.set(Calendar.YEAR, year);
                        calendarStartDate.set(Calendar.MONTH, monthOfYear);
                        calendarStartDate.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        textViewStartDate.setText(year+"-"+(monthOfYear+1)+"-"+dayOfMonth);
                    }
                };
                new DatePickerDialog(getActivity(), date, calendarStartDate
                        .get(Calendar.YEAR), calendarStartDate.get(Calendar.MONTH),
                        calendarStartDate.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        textViewEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear,
                                          int dayOfMonth) {
                        // TODO Auto-generated method stub
                        calendarEndDate.set(Calendar.YEAR, year);
                        calendarEndDate.set(Calendar.MONTH, monthOfYear);
                        calendarEndDate.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        textViewEndDate.setText(year+"-"+(monthOfYear+1)+"-"+dayOfMonth);
                    }
                };
                new DatePickerDialog(getActivity(), date, calendarEndDate
                        .get(Calendar.YEAR), calendarEndDate.get(Calendar.MONTH),
                        calendarEndDate.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        ((Button)findViewById(R.id.buttonCompleteRegister)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


               // Toasty.warning(getBaseContext(), calendarDOB.compareTo(Calendar.getInstance())+" - value", Toast.LENGTH_LONG, true).show();
                String validations="";
                String nameTrainee=((EditText)findViewById(R.id.editTextNameTrainee)).getText().toString();
                if (nameTrainee.isEmpty())
                    validations+="- Add User Name.\n";

                if (textViewDOB.getText().toString().equals("1900-1-1"))
                    validations+="- Set Date Of Birth.\n";

                if (textViewStartDate.getText().toString().equals("1900-1-1"))
                    validations+="- Set Start Date.\n";

                if (textViewEndDate.getText().toString().equals("1900-1-1"))
                    validations+="- Set End Date.\n";

                if (calendarEndDate.compareTo(calendarStartDate) == -1)
                    validations+="- Must be EndDate more than StartDate.\n";

                if (Calendar.getInstance().compareTo(calendarDOB) == -1)
                    validations+="- Must be Date Of Birth less than Today Date.\n";

                if (!validations.isEmpty()){
                    Toasty.warning(getBaseContext(), validations, Toast.LENGTH_LONG, true).show();
                    return;
                }

                Trainee trainee=DBLayer.getInstance().getMAPTrainees().get(App.getUserId());
                trainee.setName(nameTrainee);

                trainee.setDateOfBirth(textViewDOB.getText().toString());
                trainee.setStartDate(textViewStartDate.getText().toString());
                trainee.setEndDate(textViewEndDate.getText().toString());

                trainee.setPhoneNumber(((EditText)findViewById(R.id.editTextPhoneNumber)).getText().toString());
                trainee.setOtherInfo(((EditText)findViewById(R.id.editTextOtherInfo)).getText().toString());

                trainee.setGender(spinnerGender.getSelectedItem().toString());
                trainee.setReasonRegister(spinnerReasonRegister.getSelectedItem().toString());
                trainee.setPatternTraining(spinnerPatternTraining.getSelectedItem().toString());

                trainee.setLength(seekBarLength.getProgress());
                trainee.setWeight(seekBarWeight.getProgress());

                List<String>LSTTemp=new ArrayList<>();
                if (((CheckBox)findViewById(R.id.checkBoxDiseasesHeartRate)).isChecked())
                    LSTTemp.add(Trainee.HEART_RATE);

                if (((CheckBox)findViewById(R.id.checkBoxDiseasesDiabetes)).isChecked())
                    LSTTemp.add(Trainee.DIABETES);

                if (((CheckBox)findViewById(R.id.checkBoxDiseasesHighBloodPressure)).isChecked())
                    LSTTemp.add(Trainee.HIGH_BLOOD_PRESSURE);

                String diseases="";
                for (int i=0 ; i<LSTTemp.size() ;i++)
                    if (i==0)
                        diseases=LSTTemp.get(i);
                    else
                        diseases+=" - "+LSTTemp.get(i);

                trainee.setDiseases(diseases);

                LSTTemp.clear();

                if (((CheckBox)findViewById(R.id.checkBoxWeaknessShoulders)).isChecked())
                    LSTTemp.add(Trainee.SHOULDERS);

                if (((CheckBox)findViewById(R.id.checkBoxWeaknessLegs)).isChecked())
                    LSTTemp.add(Trainee.LEGS);

                if (((CheckBox)findViewById(R.id.checkBoxWeaknessChest)).isChecked())
                    LSTTemp.add(Trainee.CHEST);

                if (((CheckBox)findViewById(R.id.checkBoxWeaknessArms)).isChecked())
                    LSTTemp.add(Trainee.ARMS);

                String weakness="";
                for (int i=0 ; i<LSTTemp.size() ;i++)
                    if (i==0)
                        weakness=LSTTemp.get(i);
                    else
                        weakness+=" - "+LSTTemp.get(i);

                trainee.setWeakness(weakness);
                trainee.setMyInfo(trainee);

                for (Map.Entry<String , RTT> item : DBLayer.getInstance().getMAPRTT().entrySet())
                    if (item.getValue().getTraineeId().equals(App.getUserId())){
                        item.getValue().setStatus(RTT.TERMINATE);
                    }

                String trainerName=spinnerTrainer.getSelectedItem().toString();
                int i = (int)(Math.random() * DBLayer.getInstance().getMAPTrainers().size());

                String trainerIdRandom="";
                String trainerId="";

                for (Map.Entry<String , Trainer> item : DBLayer.getInstance().getMAPTrainers().entrySet()){
                    if (item.getValue().getName().equals(trainerName)){
                        trainerId=item.getValue().getId();
                        break;
                    }
                    i--;
                    if (i==0)
                        trainerIdRandom=item.getValue().getId();
                }

                if (trainerId.isEmpty())
                    trainerId=trainerIdRandom;

                RTT rtt = new RTT(AppRefDB.RefRTT.push().getKey(), trainee.getId(), trainerId, Calendar.getInstance().getTime().toString() , 0, RTT.PENDING);
                rtt.setMyInfo(rtt);

                Toasty.success( getBaseContext(), "Successful Update", Toast.LENGTH_SHORT, true).show();
                Intent intent = new Intent(UpdateInfoTraineeActivity.this , HomeTraineeActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void loadCurrentInfo() {

        Trainee trainee= DBLayer.getInstance().getMAPTrainees().get(FirebaseAuth.getInstance().getCurrentUser().getUid());
        if (trainee == null)
            return;

        ((EditText)findViewById(R.id.editTextNameTrainee)).setText(trainee.getName().toString());
        ((EditText)findViewById(R.id.editTextPhoneNumber)).setText(trainee.getPhoneNumber().toString());
        ((EditText)findViewById(R.id.editTextOtherInfo)).setText(trainee.getOtherInfo().toString());

        seekBarLength.setProgress(trainee.getLength());
        ((TextView)findViewById(R.id.textView4)).setText("Length - "+trainee.getLength()+" - CM");

        seekBarWeight.setProgress(trainee.getWeight());
        ((TextView)findViewById(R.id.textView5)).setText("Weight - "+String.format("%.1f",trainee.getWeight()/1000.0) +" - KG");

        String[] DOB = trainee.getDateOfBirth().split("-");
        String[] StartDate = trainee.getStartDate().split("-");
        String[] EndDate = trainee.getEndDate().split("-");

        calendarDOB.set(Calendar.YEAR , Integer.parseInt(DOB[0]));
        calendarDOB.set(Calendar.MONTH , Integer.parseInt(DOB[1]));
        calendarDOB.set(Calendar.DAY_OF_MONTH , Integer.parseInt(DOB[2]));

        calendarStartDate.set(Calendar.YEAR , Integer.parseInt(StartDate[0]));
        calendarStartDate.set(Calendar.MONTH , Integer.parseInt(StartDate[1]));
        calendarStartDate.set(Calendar.DAY_OF_MONTH , Integer.parseInt(StartDate[2]));

        calendarEndDate.set(Calendar.YEAR , Integer.parseInt(EndDate[0]));
        calendarEndDate.set(Calendar.MONTH , Integer.parseInt(EndDate[1]));
        calendarEndDate.set(Calendar.DAY_OF_MONTH , Integer.parseInt(EndDate[2]));

        textViewDOB.setText(trainee.getDateOfBirth().toString());
        textViewStartDate.setText(trainee.getStartDate().toString());
        textViewEndDate.setText(trainee.getEndDate().toString());

        String[] diseases = trainee.getDiseases().split(" - ");
        String[] weakness = trainee.getWeakness().split(" - ");

        for (int i=0 ;i<diseases.length; i++)
            switch (diseases[i])
            {
                case Trainee.HEART_RATE:
                    ((CheckBox)findViewById(R.id.checkBoxDiseasesHeartRate)).setChecked(true);
                    break;
                case Trainee.HIGH_BLOOD_PRESSURE:
                    ((CheckBox)findViewById(R.id.checkBoxDiseasesHighBloodPressure)).setChecked(true);
                    break;
                case Trainee.DIABETES:
                    ((CheckBox)findViewById(R.id.checkBoxDiseasesDiabetes)).setChecked(true);
                    break;
            }

        for (int i=0 ;i<weakness.length; i++)
            switch (weakness[i])
            {
                case Trainee.SHOULDERS:
                    ((CheckBox)findViewById(R.id.checkBoxWeaknessShoulders)).setChecked(true);
                    break;
                case Trainee.ARMS:
                    ((CheckBox)findViewById(R.id.checkBoxWeaknessArms)).setChecked(true);
                    break;
                case Trainee.CHEST:
                    ((CheckBox)findViewById(R.id.checkBoxWeaknessChest)).setChecked(true);
                    break;
                case Trainee.LEGS:
                    ((CheckBox)findViewById(R.id.checkBoxWeaknessLegs)).setChecked(true);
                    break;
            }

        switch (trainee.getReasonRegister())
        {
            case Trainee.BUILDING:
                spinnerReasonRegister.setSelection(0);
                break;
            case Trainee.FITNESS:
                spinnerReasonRegister.setSelection(1);
                break;
            case Trainee.WEIGHT_LOSS:
                spinnerReasonRegister.setSelection(2);
                break;
        }
        switch (trainee.getGender())
        {
            case Trainee.MALE:
                spinnerGender.setSelection(0);
                break;
            case Trainee.FEMALE:
                spinnerGender.setSelection(1);
                break;
        }
        switch (trainee.getPatternTraining())
        {
            case Trainee.DAYS3:
                spinnerPatternTraining.setSelection(0);
                break;
            case Trainee.DAYS6:
                spinnerPatternTraining.setSelection(1);
                break;
        }

        String nameTrainer="";
        for (Map.Entry<String , RTT> item : DBLayer.getInstance().getMAPRTT().entrySet())
            if (item.getValue().getTraineeId().equals(App.getUserId()) && !item.getValue().getStatus().equals(RTT.TERMINATE)){
                nameTrainer=DBLayer.getInstance().getMAPTrainers().get(item.getValue().getTrainerId()).getName();
                break;
            }

        if (!nameTrainer.isEmpty()) {
            for (int i=0;i<LSTSpinnerTrainer.size();i++)
                if (LSTSpinnerTrainer.get(i).equals(nameTrainer)){
                    spinnerTrainer.setSelection(i);
                    break;
                }
        }

    }

    public Activity getActivity(){
        return this;
    }
}
