package com.example.gymapp.Fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.gymapp.Adapters.MyTraineesAdapter;
import com.example.gymapp.Adapters.TrainersAdminAdapter;
import com.example.gymapp.Objects.RTT;
import com.example.gymapp.Objects.Trainee;
import com.example.gymapp.Objects.Trainer;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;

import java.util.ArrayList;
import java.util.Map;


public class TrainersAdminPanelFragment extends Fragment {

    // Declare Variables For UI
    private View rootView;
    ListView listViewTrainersAdmin;
    ArrayList<Trainer> arrayList;

    public static TrainersAdminPanelFragment newInstance() {
        TrainersAdminPanelFragment fragment = new TrainersAdminPanelFragment();
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_admin_panel_trainers, container, false);
        LoadObjects();
        LoadUI();

        return  rootView;
    }

    private void LoadObjects() {
        arrayList = new ArrayList<Trainer>();
    }

    private void LoadUI() {
        listViewTrainersAdmin=(ListView)rootView.findViewById(R.id.listViewTrainersAdmin);

        for (Map.Entry<String , Trainer> item : DBLayer.getInstance().getMAPTrainers().entrySet())
            arrayList.add(item.getValue());

        if (arrayList.size()>0) {
            TrainersAdminAdapter customAdapter = new TrainersAdminAdapter(getActivity(), arrayList);
            listViewTrainersAdmin.setAdapter(customAdapter);
        }
    }

}
