package com.example.gymapp.Activites;

import android.app.Activity;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.gymapp.Objects.Trainer;
import com.example.gymapp.Others.App;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import es.dmoral.toasty.Toasty;

public class AuthenticationTrainerActivity extends AppCompatActivity {


    private EditText editTextUserEmailTrainer;
    private EditText editTextUserPasswordTrainer;
    private Button buttonSignInTrainer;
    private Button buttonSignUpTrainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authentication_trainer);
        getSupportActionBar().setTitle("TRAINER - AUTHENTICATION");

        boolean flagIsBlock=this.getIntent().getExtras().getBoolean(App.BLOCK_STATUS_KEY);
        if (flagIsBlock)
            Toasty.warning(this,"Your Status Is Block", Toast.LENGTH_SHORT, true).show();

        loadUI();
        loadActions();

    }

    // (CONNECT LAYOUT ELEMENTS WITH ACTIVITY)
    private void loadUI() {
        editTextUserEmailTrainer=(EditText)findViewById(R.id.editTextUserEmailTrainer);
        editTextUserPasswordTrainer=(EditText)findViewById(R.id.editTextUserPasswordTrainer);
        buttonSignInTrainer=(Button)findViewById(R.id.buttonSignInTrainer);
        buttonSignUpTrainer=(Button)findViewById(R.id.buttonSignUpTrainer);
    }

    private void loadActions() {

        // ACTION - SIGN IN TRAINEE
        buttonSignInTrainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email= editTextUserEmailTrainer.getText().toString();
                String password= editTextUserPasswordTrainer.getText().toString();

                if (email.isEmpty() || password.isEmpty())
                {
                    Toasty.warning(getBaseContext(), "Issue in Validation", Toast.LENGTH_SHORT, true).show();
                    return;
                }

                if (password.length()<8)
                {
                    Toasty.warning(getBaseContext(), "Password must more than 7 digits", Toast.LENGTH_SHORT, true).show();
                    return;
                }
                FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(getActivity(), new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {

                                if (!FirebaseAuth.getInstance().getCurrentUser().isEmailVerified()){
                                    Toasty.warning(getBaseContext(),"You can't login without verify your Email", Toast.LENGTH_SHORT, true).show();
                                    return;
                                }

                                if (DBLayer.getInstance().getMAPTrainers().containsKey(FirebaseAuth.getInstance().getCurrentUser().getUid())) {

                                    if (DBLayer.getInstance().getMAPTrainers().get(FirebaseAuth.getInstance().getCurrentUser().getUid()).getStatus().equals(Trainer.BLOCK)) {
                                        FirebaseAuth.getInstance().signOut();
                                        Toasty.warning(getBaseContext(),"Your Status Is Block", Toast.LENGTH_SHORT, true).show();
                                    } else {
                                        Toasty.success(getBaseContext(),"Successfully Login", Toast.LENGTH_SHORT, true).show();
                                        Intent intent = new Intent(AuthenticationTrainerActivity.this , HomeTrainerActivity.class);
                                        startActivity(intent);
                                    }
                                } else {
                                    Toasty.success(getBaseContext(),"Successfully Login", Toast.LENGTH_SHORT, true).show();
                                    Intent intent = new Intent(AuthenticationTrainerActivity.this , RegisterTrainerActivity.class);
                                    startActivity(intent);
                                }

                            } else {
                                Toasty.error(getBaseContext(),"Failed Register Or Login", Toast.LENGTH_SHORT, true).show();
                            }
                        }
                    });
            }
        });

        // ACTION - SIGN UP TRAINEE
        buttonSignUpTrainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email= editTextUserEmailTrainer.getText().toString();
                String password= editTextUserPasswordTrainer.getText().toString();
                if (email.isEmpty() || password.isEmpty()) {
                    Toasty.warning(getBaseContext(), "Issue in Validation", Toast.LENGTH_SHORT, true).show();
                    return;
                }

                if (password.length()<8) {
                    Toasty.warning(getBaseContext(), "Password must more than 7 digits", Toast.LENGTH_SHORT, true).show();
                    return;
                }

                FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(getActivity(), new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    if (!FirebaseAuth.getInstance().getCurrentUser().isEmailVerified()){
                                        Toasty.success(getBaseContext(), "Successfully, Last step you must verify your email "+FirebaseAuth.getInstance().getCurrentUser().getEmail(), Toast.LENGTH_LONG, true).show();
                                        FirebaseAuth.getInstance().getCurrentUser().sendEmailVerification();
                                    } else {
                                        Toasty.success(getBaseContext(), "Successfully, You can Sign In by your email "+FirebaseAuth.getInstance().getCurrentUser().getEmail(), Toast.LENGTH_LONG, true).show();
                                    }
                                } else {
                                    Toasty.error(getBaseContext() , "Failed Register", Toast.LENGTH_SHORT, true).show();
                                }
                            }
                        });

            }
        });


        // ACTION - RESET PASSWORD
        ((Button)findViewById(R.id.buttonResetPassword)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (editTextUserEmailTrainer.getText().toString().isEmpty())
                {
                    Toasty.warning(getBaseContext(), "Email is Empty", Toast.LENGTH_SHORT, true).show();
                    return;
                }
                Toasty.warning(getBaseContext(), "You can review Your Email To Rest Password - "+editTextUserEmailTrainer.getText().toString(), Toast.LENGTH_SHORT, true).show();
                FirebaseAuth.getInstance().sendPasswordResetEmail(editTextUserEmailTrainer.getText().toString());
            }
        });
    }

    public Activity getActivity(){
        return this;
    }

}
