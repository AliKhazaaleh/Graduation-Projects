package com.example.gymapp.Activites;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gymapp.Adapters.FullTrainingAdapter;
import com.example.gymapp.Adapters.MyTrainingAdapter;
import com.example.gymapp.Objects.FullTraining;
import com.example.gymapp.Objects.Training;
import com.example.gymapp.Others.App;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import es.dmoral.toasty.Toasty;

public class MyTrainingActivity extends AppCompatActivity {

    // Declare Variables For UI
    Button buttonSubmitDoneTraining;
    ListView listViewTrainings;
    TextView textViewDOT,textViewStatusTraining;

    Calendar calendarDOT;
    ArrayList<Training> arrayListTraining;
    HashMap<String , String> MAPSetMinOfTraining;
    FullTraining fullTraining;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_training);
        getSupportActionBar().setTitle("TRAINEE - MY TRAINING");

        loadObjects();
        loadUi();
        loadActions();
        loadTrainingOfDay();
    }

    private void loadObjects() {
        arrayListTraining= new ArrayList<>();
        MAPSetMinOfTraining = new HashMap<>();
        calendarDOT=Calendar.getInstance();

    }

    // (CONNECT LAYOUT ELEMENTS WITH ACTIVITY)
    private void loadUi() {
        buttonSubmitDoneTraining=(Button) findViewById(R.id.buttonSubmitDoneTraining);
        listViewTrainings=(ListView) findViewById(R.id.listViewTrainings);
        textViewDOT=(TextView) findViewById(R.id.textViewDOT);
        textViewStatusTraining=(TextView) findViewById(R.id.textViewStatusTraining);
        textViewDOT.setText(calendarDOT.get(Calendar.YEAR)+"-"+(calendarDOT.get(Calendar.MONTH)+1)+"-"+calendarDOT.get(Calendar.DAY_OF_MONTH));
    }

    private void loadActions() {

        textViewDOT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear,
                                          int dayOfMonth) {
                        // TODO Auto-generated method stub
                        calendarDOT.set(Calendar.YEAR, year);
                        calendarDOT.set(Calendar.MONTH, monthOfYear);
                        calendarDOT.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        textViewDOT.setText(year+"-"+(monthOfYear+1)+"-"+dayOfMonth);

                        loadTrainingOfDay();
                    }
                };
                new DatePickerDialog(getActivity(), date, calendarDOT
                        .get(Calendar.YEAR), calendarDOT.get(Calendar.MONTH),
                        calendarDOT.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        buttonSubmitDoneTraining.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                buttonSubmitDoneTraining.setAlpha((float)0.5);
                buttonSubmitDoneTraining.setEnabled(true);
                if (fullTraining!=null)
                    DBLayer.getInstance().getMAPFullTraining().get(fullTraining.getId()).setStatus(FullTraining.DONE);
            }
        });
    }

    public void reloadListView(){

        if (arrayListTraining.size()>0){
            MyTrainingAdapter customAdapter = new MyTrainingAdapter(this, arrayListTraining, MAPSetMinOfTraining);
            listViewTrainings.setAdapter(customAdapter);
        } else {
            listViewTrainings.setAdapter(null);
        }
    }

    public  void loadTrainingOfDay(){

        if (calendarDOT.get(Calendar.YEAR) < Calendar.getInstance().get(Calendar.YEAR) ||
                (calendarDOT.get(Calendar.YEAR) == Calendar.getInstance().get(Calendar.YEAR) && calendarDOT.get(Calendar.MONTH) < Calendar.getInstance().get(Calendar.MONTH)) ||
                (calendarDOT.get(Calendar.YEAR) == Calendar.getInstance().get(Calendar.YEAR) && calendarDOT.get(Calendar.MONTH) == Calendar.getInstance().get(Calendar.MONTH) && calendarDOT.get(Calendar.DAY_OF_MONTH) < Calendar.getInstance().get(Calendar.DAY_OF_MONTH))) {

            buttonSubmitDoneTraining.setEnabled(false);
            buttonSubmitDoneTraining.setAlpha((float)0.5);
        } else {
            buttonSubmitDoneTraining.setEnabled(true);
            buttonSubmitDoneTraining.setAlpha((float)1.0);
        }

        fullTraining=null;
        for (Map.Entry<String , FullTraining> item : DBLayer.getInstance().getMAPFullTraining().entrySet())
        {
            Calendar calendarDateTraining=Calendar.getInstance();
            calendarDateTraining.setTimeInMillis(item.getValue().getDate());

            if (item.getValue().getTraineeId().equals(App.getUserId()) &&
                    calendarDateTraining.get(Calendar.YEAR) == calendarDOT.get(Calendar.YEAR) &&
                    calendarDateTraining.get(Calendar.MONTH) == calendarDOT.get(Calendar.MONTH) &&
                    calendarDateTraining.get(Calendar.DAY_OF_MONTH) == calendarDOT.get(Calendar.DAY_OF_MONTH))
            {
                fullTraining=item.getValue();
                break;
            }
        }

        if (fullTraining==null){
            Toasty.warning(getBaseContext(), "Not Exist Any Training For This Day", Toast.LENGTH_SHORT, true).show();

            arrayListTraining.clear();
            MAPSetMinOfTraining.clear();
            reloadListView();
            buttonSubmitDoneTraining.setEnabled(false);
            buttonSubmitDoneTraining.setAlpha((float)0.5);
            ((TextView)findViewById(R.id.textViewStatusTraining)).setText("Status - No Training");

        } else {

            ((TextView)findViewById(R.id.textViewStatusTraining)).setText("Status - "+fullTraining.getStatus());

            arrayListTraining.clear();
            MAPSetMinOfTraining.clear();

            if (!fullTraining.getStatus().equals(FullTraining.VACATION))
            {
                String[] arTraining=fullTraining.getTrainingList().split(" && ");
                for (int i = 0;i<arTraining.length; i++) {

                    String[] detailsTraining = arTraining[i].split(" __ ");
                    arrayListTraining.add(DBLayer.getInstance().getMAPTrainings().get(detailsTraining[0]));
                    MAPSetMinOfTraining.put(detailsTraining[0],detailsTraining[1]);
                }
            }
            reloadListView();

            if (fullTraining.getStatus().equals(FullTraining.DONE) || fullTraining.getStatus().equals(FullTraining.VACATION))
            {
                buttonSubmitDoneTraining.setEnabled(false);
                buttonSubmitDoneTraining.setAlpha((float)0.5);
            } else {
                buttonSubmitDoneTraining.setEnabled(true);
                buttonSubmitDoneTraining.setAlpha((float)1.0);
            }
        }
    }


    public Activity getActivity(){
        return this;
    }

}
