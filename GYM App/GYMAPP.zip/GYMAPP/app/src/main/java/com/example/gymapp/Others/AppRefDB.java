package com.example.gymapp.Others;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class AppRefDB {

    private static FirebaseDatabase DB = FirebaseDatabase.getInstance();
    public static DatabaseReference RefAdmins = DB.getReference("Admins");
    public static DatabaseReference RefTrainers = DB.getReference("Trainers");
    public static DatabaseReference RefTrainees = DB.getReference("Trainees");
    public static DatabaseReference RefRTT = DB.getReference("RTT");
    public static DatabaseReference RefWeightTrainees = DB.getReference("WeightTrainees");
    public static DatabaseReference RefTrainings = DB.getReference("Trainings");
    public static DatabaseReference RefFullTraining = DB.getReference("FullTraining");
    public static StorageReference mStorageRef = FirebaseStorage.getInstance().getReference("img");

    private AppRefDB() {
    }

}
