package com.example.gymapp.Activites;

import android.app.Activity;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.gymapp.Others.App;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import es.dmoral.toasty.Toasty;

public class AuthenticationTraineeActivity extends AppCompatActivity {

    // Declare Variables For UI
    private EditText editTextUserEmail;
    private EditText editTextUserPassword;
    private Button buttonSignIn;
    private Button buttonSignUp;
    private Button buttonShowTrainersList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authentication_trainee);
        getSupportActionBar().setTitle("TRAINEE - AUTHENTICATION");

        loadUI();
        loadActions();
    }

    // CONNECT LAYOUT ELEMENTS WITH ACTIVITY (BUTTONS, TEXTVIEWS AND SPINNERS)
    private void loadUI() {
        editTextUserEmail=(EditText)findViewById(R.id.editTextUserEmail);
        editTextUserPassword=(EditText)findViewById(R.id.editTextUserPassword);
        buttonSignIn=(Button)findViewById(R.id.buttonSignIn);
        buttonSignUp=(Button)findViewById(R.id.buttonSignUp);
        buttonShowTrainersList=(Button) findViewById(R.id.buttonShowTrainersList);
    }

    // LOAD ACTIONS
    private void loadActions() {

        // ACTION - SIGN IN TRAINEE
        buttonSignIn.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {

             String email= editTextUserEmail.getText().toString();
             String password= editTextUserPassword.getText().toString();

             if (email.isEmpty() || password.isEmpty()) {
                 Toasty.warning(getBaseContext(), "Email or Password is Empty", Toast.LENGTH_SHORT, true).show();
                 return;
             }
             if (password.length()<8) {
                 Toasty.warning(getBaseContext(), "Password must more than 7 digits", Toast.LENGTH_SHORT, true).show();
                 return;
             }

             FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
                     .addOnCompleteListener(getActivity(), new OnCompleteListener<AuthResult>() {
                         @Override
                         public void onComplete(@NonNull Task<AuthResult> task) {
                             if (task.isSuccessful()) {

                                 if (!FirebaseAuth.getInstance().getCurrentUser().isEmailVerified()){
                                     Toasty.warning(getBaseContext(),"You can't login without verify your Email", Toast.LENGTH_SHORT, true).show();
                                     return;
                                 }

                                 Toasty.success(getBaseContext(),"Successfully Login", Toast.LENGTH_SHORT, true).show();
                                 if (DBLayer.getInstance().getMAPTrainees().containsKey(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
                                     Intent intent = new Intent(AuthenticationTraineeActivity.this , HomeTraineeActivity.class);
                                     startActivity(intent);
                                 } else {
                                     Intent intent = new Intent(AuthenticationTraineeActivity.this , RegisterTraineeActivity.class);
                                     startActivity(intent);
                                 }

                             } else {
                                 Toasty.error(getBaseContext(),"Failed Login", Toast.LENGTH_SHORT, true).show();
                             }
                         }
                     });
         }
        });

        // ACTION - SIGN UP TRAINEE
        buttonSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email= editTextUserEmail.getText().toString();
                String password= editTextUserPassword.getText().toString();

                if (email.isEmpty() || password.isEmpty())
                {
                    Toasty.warning(getBaseContext(), "Email or Password is Empty", Toast.LENGTH_SHORT, true).show();
                    return;
                }
                if (password.length()<8) {
                    Toasty.warning(getBaseContext(), "Password must more than 7 digits", Toast.LENGTH_SHORT, true).show();
                    return;
                }
                FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(getActivity(), new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    if (!FirebaseAuth.getInstance().getCurrentUser().isEmailVerified()){
                                        Toasty.success(getBaseContext(), "Successfully, Last step you must verify your email "+FirebaseAuth.getInstance().getCurrentUser().getEmail(), Toast.LENGTH_LONG, true).show();
                                        FirebaseAuth.getInstance().getCurrentUser().sendEmailVerification();
                                    } else {
                                        Toasty.success(getBaseContext(), "Successfully, You can Sign In by your email "+FirebaseAuth.getInstance().getCurrentUser().getEmail(), Toast.LENGTH_LONG, true).show();
                                    }
                                } else {
                                    Toasty.error(getBaseContext() , "Failed Register", Toast.LENGTH_SHORT, true).show();
                                }
                            }
                        });
            }
        });

        // ACTION - RESET PASSWORD
        ((Button)findViewById(R.id.buttonResetPassword)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (editTextUserEmail.getText().toString().isEmpty())
                {
                    Toasty.warning(getBaseContext(), "Email is Empty", Toast.LENGTH_SHORT, true).show();
                    return;
                }

                Toasty.warning(getBaseContext(), "You can review Your Email To Rest Password - "+editTextUserEmail.getText().toString(), Toast.LENGTH_SHORT, true).show();
                FirebaseAuth.getInstance().sendPasswordResetEmail(editTextUserEmail.getText().toString());
            }
        });

        // ACTION - SHOW TRAINERS LIST
        buttonShowTrainersList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AuthenticationTraineeActivity.this , TrainersListActivity.class);
                startActivity(intent);
            }
        });
    }

    public Activity getActivity(){
        return this;
    }

}
