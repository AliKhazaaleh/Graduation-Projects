package com.example.gymapp.Jsons;

import com.example.gymapp.Objects.Admin;

public class AdminJson {

    public String id;
    public String userName;
    public String password;

    public Admin ConvertToObject(){
        Admin object = new Admin(id, userName, password);
        return object;
    }
}
