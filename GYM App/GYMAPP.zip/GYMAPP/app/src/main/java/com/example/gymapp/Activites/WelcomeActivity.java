package com.example.gymapp.Activites;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.gymapp.Others.App;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;
import com.google.firebase.auth.FirebaseAuth;

import es.dmoral.toasty.Toasty;

public class WelcomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        getSupportActionBar().setTitle("GYM APP");
        DBLayer.getInstance().configBasicMode();
        loadActions();
    }

    private void loadActions() {

        ((Button)findViewById(R.id.buttonAsAdmin)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(WelcomeActivity.this , AuthenticationAdminActivity.class);
                startActivity(intent);
            }
        });

        ((Button)findViewById(R.id.buttonAsTrainer)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(WelcomeActivity.this , SplashTrainerActivity.class);
                startActivity(intent);
            }
        });
        ((Button)findViewById(R.id.buttonAsTrainee)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(WelcomeActivity.this , SplashTraineeActivity.class);
                startActivity(intent);
            }
        });

        ((Button)findViewById(R.id.buttonAbout)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(WelcomeActivity.this , AboutActivity.class);
                startActivity(intent);
            }
        });

    }
}
