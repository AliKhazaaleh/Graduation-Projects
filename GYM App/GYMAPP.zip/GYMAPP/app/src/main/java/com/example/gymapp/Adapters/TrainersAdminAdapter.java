package com.example.gymapp.Adapters;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.DataSetObserver;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.gymapp.Activites.AddTrainingActivity;
import com.example.gymapp.Activites.HomeTraineeActivity;
import com.example.gymapp.Activites.MyTrainingActivity;
import com.example.gymapp.Activites.TraineeInfoActivity;
import com.example.gymapp.Activites.TrainerInfoActivity;
import com.example.gymapp.Objects.RTT;
import com.example.gymapp.Objects.Trainee;
import com.example.gymapp.Objects.Trainer;
import com.example.gymapp.Others.App;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class TrainersAdminAdapter implements ListAdapter {

    ArrayList<Trainer> arrayList;
    Context context;
    public TrainersAdminAdapter(Context context, ArrayList<Trainer> arrayList) {
        this.arrayList=arrayList;
        this.context=context;
    }
    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }
    @Override
    public boolean isEnabled(int position) {
        return true;
    }
    @Override
    public void registerDataSetObserver(DataSetObserver observer) {
    }
    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {
    }
    @Override
    public int getCount() {
        return arrayList.size();
    }
    @Override
    public Object getItem(int position) {
        return position;
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public boolean hasStableIds() {
        return false;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Trainer trainer=arrayList.get(position);
        if(convertView==null) {
            LayoutInflater layoutInflater = LayoutInflater.from(context);
            convertView=layoutInflater.inflate(R.layout.item_trainer_admin, null);
        }
        CircleImageView imageViewStatusRequest=(CircleImageView)convertView.findViewById(R.id.imageViewStatusRequest);

        ((TextView)convertView.findViewById(R.id.textViewNameTrainer)).setText(trainer.getName());

        if (trainer.getPhotoLink() == null || trainer.getPhotoLink().equals("")) {
            ((CircleImageView)convertView.findViewById(R.id.imageViewPhotoTrainer)).setImageResource(R.mipmap.logo_trainer);
        } else{
            Picasso.get().load(trainer.getPhotoLink()).into((CircleImageView)convertView.findViewById(R.id.imageViewPhotoTrainer));

            ((CircleImageView)convertView.findViewById(R.id.imageViewPhotoTrainer)).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
                    final ImageView imageViewPhoto = new ImageView(context);

                    Picasso.get().load(trainer.getPhotoLink()).into(imageViewPhoto);
                    dialogBuilder.setView(imageViewPhoto);

                    AlertDialog alertDialog = dialogBuilder.create();
                    alertDialog.show();
                }
            });
        }

        switch (trainer.getStatus()) {
            case Trainer.ACCEPT:
                ((Button)convertView.findViewById(R.id.buttonAcceptRequest)).setVisibility(View.GONE);
                ((Button)convertView.findViewById(R.id.buttonRejectRequest)).setVisibility(View.GONE);
                ((Button)convertView.findViewById(R.id.buttonBlock)).setEnabled(true);

                ((CircleImageView)convertView.findViewById(R.id.imageViewStatusRequest)).setImageResource(R.mipmap.logo_accept);
                break;
            case Trainer.REJECT:
                //((Button)convertView.findViewById(R.id.buttonAcceptRequest)).setVisibility(View.GONE);
                //((Button)convertView.findViewById(R.id.buttonRejectRequest)).setVisibility(View.GONE);
                ((Button)convertView.findViewById(R.id.buttonAcceptRequest)).setEnabled(true);
                ((Button)convertView.findViewById(R.id.buttonRejectRequest)).setEnabled(true);

                ((Button)convertView.findViewById(R.id.buttonBlock)).setVisibility(View.GONE);
                ((CircleImageView)convertView.findViewById(R.id.imageViewStatusRequest)).setImageResource(R.mipmap.logo_reject);

                break;
            case Trainer.PENDING:
                ((Button)convertView.findViewById(R.id.buttonAcceptRequest)).setEnabled(true);
                ((Button)convertView.findViewById(R.id.buttonRejectRequest)).setEnabled(true);
                ((Button)convertView.findViewById(R.id.buttonBlock)).setVisibility(View.GONE);

                ((CircleImageView)convertView.findViewById(R.id.imageViewStatusRequest)).setImageResource(R.mipmap.logo_pending);
                break;
            case Trainer.BLOCK:

                ((Button)convertView.findViewById(R.id.buttonAcceptRequest)).setVisibility(View.GONE);
                ((Button)convertView.findViewById(R.id.buttonRejectRequest)).setVisibility(View.GONE);
                ((Button)convertView.findViewById(R.id.buttonBlock)).setEnabled(true);

                ((Button)convertView.findViewById(R.id.buttonBlock)).setText("UnBlock");
                ((CircleImageView)convertView.findViewById(R.id.imageViewStatusRequest)).setImageResource(R.mipmap.logo_block);
                break;
        }

        ((CircleImageView)convertView.findViewById(R.id.imageViewTrainerInfo)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context , TrainerInfoActivity.class);
                intent.putExtra(App.MODE_APP, App.MODE_ADMIN);
                intent.putExtra(App.TRAINER_INFO_KEY, trainer.getId());
                context.startActivity(intent);
            }
        });

        ((Button)convertView.findViewById(R.id.buttonAcceptRequest)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBLayer.getInstance().getMAPTrainers().get(trainer.getId()).setStatus(Trainer.ACCEPT);
                imageViewStatusRequest.setImageResource(R.mipmap.logo_accept);
               // ((Button)view).setEnabled(false);
               // ((Button)view).setAlpha((float)0.5);
            }
        });

        ((Button)convertView.findViewById(R.id.buttonRejectRequest)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBLayer.getInstance().getMAPTrainers().get(trainer.getId()).setStatus(Trainer.REJECT);
                imageViewStatusRequest.setImageResource(R.mipmap.logo_reject);
                //((Button)view).setEnabled(false);
                //((Button)view).setAlpha((float)0.5);
            }
        });
        ((Button)convertView.findViewById(R.id.buttonBlock)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (trainer.getStatus().equals(Trainer.BLOCK)) {
                    DBLayer.getInstance().getMAPTrainers().get(trainer.getId()).setStatus(Trainer.ACCEPT);
                    trainer.setStatus(Trainer.ACCEPT);
                    ((Button)view).setText("Block");
                    imageViewStatusRequest.setImageResource(R.mipmap.logo_accept);
                } else {
                    DBLayer.getInstance().getMAPTrainers().get(trainer.getId()).setStatus(Trainer.BLOCK);
                    trainer.setStatus(Trainer.BLOCK);
                    ((Button)view).setText("UnBlock");
                    imageViewStatusRequest.setImageResource(R.mipmap.logo_block);
                }
            }
        });

        return convertView;
    }
    @Override
    public int getItemViewType(int position) {
        return position;
    }
    @Override
    public int getViewTypeCount() {
        return arrayList.size();
    }
    @Override
    public boolean isEmpty() {
        return false;
    }
}