package com.example.gymapp.Jsons;

import com.example.gymapp.Objects.Trainer;

public class TrainerJson {

    public String id;
    public String photoLink;
    public String dateOfBirth;
    public String name;
    public String phoneNumber;
    public String info;
    public String gender;
    public String status;

    public Trainer ConvertToObject(){
        Trainer object = new Trainer(id, photoLink, dateOfBirth, name, phoneNumber, gender, info, status);
        return object;
    }
}
