package com.example.gymapp.Activites;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.example.gymapp.Adapters.MyRequestsAdapter;
import com.example.gymapp.Adapters.MyTraineesAdapter;
import com.example.gymapp.Objects.RTT;
import com.example.gymapp.Objects.Trainee;
import com.example.gymapp.Others.App;
import com.example.gymapp.Others.DBLayer;
import com.example.gymapp.R;

import java.util.ArrayList;
import java.util.Map;

public class MyTraineesActivity extends AppCompatActivity {

    // Declare Variables For UI
    ArrayList<Trainee> arrayList;
    ListView list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_trainees);
        getSupportActionBar().setTitle("TRAINER - MY TRAINEES");

        loadObjects();
        loadUI();
    }

    private void loadObjects() {
        arrayList = new ArrayList<Trainee>();
    }

    // (CONNECT LAYOUT ELEMENTS WITH ACTIVITY)
    private void loadUI() {

        for (Map.Entry<String , RTT> item : DBLayer.getInstance().getMAPRTT().entrySet())
            if (item.getValue().getTrainerId().equals(App.getUserId()) && item.getValue().getStatus().equals(RTT.ACCEPT))
                arrayList.add(DBLayer.getInstance().getMAPTrainees().get(item.getValue().getTraineeId()));

        list = (ListView) findViewById(R.id.listViewMyTrainees);

        if (arrayList.size()>0)
        {
            MyTraineesAdapter customAdapter = new MyTraineesAdapter(this, arrayList);
            list.setAdapter(customAdapter);
        }
    }
}
