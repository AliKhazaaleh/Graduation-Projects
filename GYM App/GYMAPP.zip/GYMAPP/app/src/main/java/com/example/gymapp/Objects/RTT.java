package com.example.gymapp.Objects;

import com.example.gymapp.Others.AppRefDB;
import com.example.gymapp.Others.DBLayer;

public class RTT {
    String id;
    String traineeId;
    String trainerId;
    String date;
    double rate;
    String status;
    public RTT(String id, String traineeId, String trainerId, String date, double rate, String status) {
        this.id = id;
        this.traineeId = traineeId;
        this.trainerId = trainerId;
        this.date = date;
        this.rate = rate;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTraineeId() {
        return traineeId;
    }

    public void setTraineeId(String traineeId) {
        this.traineeId = traineeId;
    }

    public String getTrainerId() {
        return trainerId;
    }

    public void setTrainerId(String trainerId) {
        this.trainerId = trainerId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        AppRefDB.RefRTT.child(this.getId()).child("rate").setValue(rate);
        this.rate = rate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
        AppRefDB.RefRTT.child(this.getId()).child("status").setValue(status);
    }

    public void setMyInfo(RTT rtt){
        AppRefDB.RefRTT.child(rtt.getId()).setValue(rtt);
        DBLayer.getInstance().getMAPRTT().put(rtt.getId() , rtt);
    }


    public static final String PENDING = "Pending";
    public static final String ACCEPT = "Accept";
    public static final String REJECT = "Reject";
    public static final String TERMINATE = "TERMINATE";
}
