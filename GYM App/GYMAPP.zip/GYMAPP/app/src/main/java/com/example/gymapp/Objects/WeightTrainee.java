package com.example.gymapp.Objects;

public class WeightTrainee {
    String id;
    String traineeId;
    double weight;
    long date;

    public WeightTrainee(String id, String traineeId, double weight, long date) {
        this.id = id;
        this.traineeId = traineeId;
        this.weight = weight;
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTraineeId() {
        return traineeId;
    }

    public void setTraineeId(String traineeId) {
        this.traineeId = traineeId;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }
}
