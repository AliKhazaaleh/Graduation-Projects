﻿
function setPaddingTop() {

    Button_View.style.paddingTop = ConvertDpToPx(Slider_PaddingTop.value) + "px";
    TextViewPaddingTop.value = Slider_PaddingTop.value;
}


function setPaddingBottom() {
    Button_View.style.paddingBottom = ConvertDpToPx(Slider_PaddingBottom.value) + "px";
    TextViewPaddingBootom.value = Slider_PaddingBottom.value;
}


function setPaddingLeft() {
    Button_View.style.paddingLeft = ConvertDpToPx(Slider_PaddingLeft.value) + "px";
    TextViewPaddingLeft.value = Slider_PaddingLeft.value;
}


function setPaddingRight() {
    Button_View.style.paddingRight = ConvertDpToPx(Slider_PaddingRight.value) + "px";
    TextViewPaddingRight.value = Slider_PaddingRight.value;
}