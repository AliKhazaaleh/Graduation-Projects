﻿var DirectionSkew = "left";

function setShapeRect() {


    shape = "Rect";
    Slider_Height.disabled = false;
    Slider_Width.disabled = false;
    Slider_Diameter.disabled = true;
    Slider_Rib.disabled = true;
    SelectSkew.disabled = true;

    Button_View.style.height = ConvertDpToPx(Slider_Height.value) + "px";
    Button_View.style.width = ConvertDpToPx(Slider_Width.value) + "px";
    Button_View.style.transform = "skew(" + 0 + "deg)";
    setStrokeWidth();

    checkboxSameCorner.disabled = false;


    if (BGColor != "solid")
        setGradiant();

    if (flagCheckBoxSameCorner == false) {


        Slider_SameCorner.disabled = true;

        Slider_TopleftCorner.disabled = false;
        Slider_TopRightCorner.disabled = false;
        Slider_BottomleftCorner.disabled = false;
        Slider_BottomRightCorner.disabled = false;


        Button_View.style.borderTopLeftRadius = ConvertDpToPx(Slider_TopleftCorner.value) + "px";
        Button_View.style.borderTopRightRadius = ConvertDpToPx(Slider_TopRightCorner.value) + "px";
        Button_View.style.borderBottomLeftRadius = ConvertDpToPx(Slider_BottomleftCorner.value) + "px";
        Button_View.style.borderBottomRightRadius = ConvertDpToPx(Slider_BottomRightCorner.value) + "px";


    } else {

        Slider_SameCorner.disabled = false;

        Slider_TopleftCorner.disabled = true;
        Slider_TopRightCorner.disabled = true;
        Slider_BottomleftCorner.disabled = true;
        Slider_BottomRightCorner.disabled = true;

        Button_View.style.borderRadius = ConvertDpToPx(Slider_SameCorner.value) + "px";
    }

}

function setShapeCircle() {

    shape = "Circle";
    Slider_Height.disabled = true;
    Slider_Width.disabled = true;
    Slider_Diameter.disabled = false;
    Slider_Rib.disabled = true;
    SelectSkew.disabled = true;


    Slider_TopleftCorner.disabled = true;
    Slider_TopRightCorner.disabled = true;
    Slider_BottomleftCorner.disabled = true;
    Slider_BottomRightCorner.disabled = true;
    Slider_SameCorner.disabled = true;

    checkboxSameCorner.disabled = true;

    if (BGColor != "solid")
        setGradiant();

    Button_View.style.height = ConvertDpToPx(Slider_Diameter.value) + "px";
    Button_View.style.width = ConvertDpToPx(Slider_Diameter.value) + "px";
    Button_View.style.borderRadius = ConvertDpToPx(Slider_Diameter.value) + "px";
    Button_View.style.transform = "skew(" + 0 + "deg)";
    setStrokeWidth();

}


function setShapeOval() {

    shape = "oval";

    Slider_Height.disabled = false;
    Slider_Width.disabled = false;
    Slider_Diameter.disabled = true;
    Slider_Rib.disabled = true;
    SelectSkew.disabled = true;

    Slider_TopleftCorner.disabled = true;
    Slider_TopRightCorner.disabled = true;
    Slider_BottomleftCorner.disabled = true;
    Slider_BottomRightCorner.disabled = true;
    Slider_SameCorner.disabled = true;

    checkboxSameCorner.disabled = true;

    if (BGColor != "solid")
        setGradiant();

    Button_View.style.borderRadius = "50%";
    Button_View.style.height = ConvertDpToPx(Slider_Height.value) + "px";
    Button_View.style.width = ConvertDpToPx(Slider_Width.value) + "px";
    Button_View.style.transform = "skew(" + 0 + "deg)";
    setStrokeWidth();
}



function setShapeParallelogram() {

    shape = "Parallelogram";
    Slider_Height.disabled = true;
    Slider_Width.disabled = true;
    Slider_Diameter.disabled = true;
    Slider_Rib.disabled = false;
    SelectSkew.disabled = false;

    Slider_TopleftCorner.disabled = true;
    Slider_TopRightCorner.disabled = true;
    Slider_BottomleftCorner.disabled = true;
    Slider_BottomRightCorner.disabled = true;
    Slider_SameCorner.disabled = true;
    checkboxSameCorner.disabled = true;

    Button_View.style.width = ConvertDpToPx(Slider_Rib.value) + "px";
    Button_View.style.height = ConvertDpToPx(Slider_Rib.value) + "px";
    Button_View.style.borderRadius = 0 + "px";
    setStrokeWidth();

    if (DirectionSkew == "left")
        Button_View.style.transform = "skew(" + 20 + "deg)";
    else
        Button_View.style.transform = "skew(" + -20 + "deg)";

}

function SetShapeType(select) {

    switch (select) {

        case "1": setShapeRect(); break;
        case "2": setShapeOval(); break;
        case "3": setShapeCircle(); break;
        case "4": setShapeParallelogram(); break;
        
    }
}




function setSkewLeft() {
    Button_View.style.transform = "skew(" + 20 + "deg)";
    DirectionSkew = "left";
}

function setSkewRight() {
    Button_View.style.transform = "skew(" + -20 + "deg)";
    DirectionSkew = "right";

}


function SetTypeSkew(select) {

    switch (select) {

        case "1": setSkewLeft(); break;
        case "2": setSkewRight(); break;

    }


}
function setRib() {

    Button_View.style.width = ConvertDpToPx(Slider_Rib.value) + "px";
    Button_View.style.height = ConvertDpToPx(Slider_Rib.value) + "px";
    TextViewRib.value = Slider_Rib.value;

}