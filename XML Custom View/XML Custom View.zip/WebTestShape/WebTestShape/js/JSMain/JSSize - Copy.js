﻿
var screenDP = 3;
var shape = "Rect";

function setwidth() {
    Button_View.style.width = ConvertDpToPx(Slider_Width.value) + "px";
    TextViewWidth.value = Slider_Width.value;


    if (shape == "oval")
        Button_View.style.borderRadius = "50%";;

    if (BGColor == "gradiant") {
        setGradiant();
    }
}

function setheight() {

    Button_View.style.height = ConvertDpToPx(Slider_Height.value) + "px";
    TextViewHeight.value = Slider_Height.value;

    if (shape == "oval")
        Button_View.style.borderRadius = "50%";


    if (checkboxSolid.checked == false) {
        setGradiant();
    }

}



function setDiameter() {

    Button_View.style.height = ConvertDpToPx(Slider_Diameter.value) + "px";
    Button_View.style.width = ConvertDpToPx(Slider_Diameter.value) + "px";
    Button_View.style.borderRadius = ConvertDpToPx(Slider_Diameter.value) + "px";
    TextViewDiameter.value = Slider_Diameter.value;

}




function setldpi() {
    screenDP = 1;

    setTextSize();
    setPaddingTop();
    setPaddingBottom();
    setPaddingLeft();
    setPaddingRight();
    Button_View.style.borderWidth = ConvertDpToPx(Slider_StrokeWidth.value) + "px";


    if (BGColor != "solid")
        setGradiant();


    if (shape == "Rect") {

        Button_View.style.height = ConvertDpToPx(Slider_Height.value) + "px";
        Button_View.style.width = ConvertDpToPx(Slider_Width.value) + "px";

        if (checkboxSameCorner.checked == true)
            setSameCorner();
        else {
            setCorTopLeft();
            setCorTopRight();
            setCorBottomLeft();
            setCorBottomRight();
        }

    } else if (shape == "Circle") {
        setShapeCircle();

    } else if (shape == "oval") {
        setShapeOval();
    } else if (shape == "Parallelogram") {
        setShapeParallelogram();
    }
}


function setmdpi() {
    screenDP = 2;

    setTextSize();

    setPaddingTop();
    setPaddingBottom();
    setPaddingLeft();
    setPaddingRight();
    Button_View.style.borderWidth = ConvertDpToPx(Slider_StrokeWidth.value) + "px";

    if (BGColor != "solid")
        setGradiant();


    if (shape == "Rect") {

        Button_View.style.height = ConvertDpToPx(Slider_Height.value) + "px";
        Button_View.style.width = ConvertDpToPx(Slider_Width.value) + "px";

        if (checkboxSameCorner.checked == true)
            setSameCorner();
        else {
            setCorTopLeft();
            setCorTopRight();
            setCorBottomLeft();
            setCorBottomRight();
        }

    } else if (shape == "Circle") {
        setShapeCircle();

    } else if (shape == "oval") {
        setShapeOval();
    } else if (shape == "Parallelogram") {
        setShapeParallelogram();
    }

}

function sethdpi() {
    screenDP = 3;

    setTextSize();

    setPaddingTop();
    setPaddingBottom();
    setPaddingLeft();
    setPaddingRight();
    Button_View.style.borderWidth = ConvertDpToPx(Slider_StrokeWidth.value) + "px";

    if (BGColor != "solid")
        setGradiant();


    if (shape == "Rect") {

        Button_View.style.height = ConvertDpToPx(Slider_Height.value) + "px";
        Button_View.style.width = ConvertDpToPx(Slider_Width.value) + "px";

        if (checkboxSameCorner.checked == true)
            setSameCorner();
        else {
            setCorTopLeft();
            setCorTopRight();
            setCorBottomLeft();
            setCorBottomRight();
        }

    } else if (shape == "Circle") {
        setShapeCircle();

    } else if (shape == "oval") {
        setShapeOval();
    } else if (shape == "Parallelogram") {
        setShapeParallelogram();
    }

}

function setxhdpi() {
    screenDP = 4;


    setTextSize();

    setPaddingTop();
    setPaddingBottom();
    setPaddingLeft();
    setPaddingRight();
    Button_View.style.borderWidth = ConvertDpToPx(Slider_StrokeWidth.value) + "px";

    if (BGColor != "solid")
        setGradiant();


    if (shape == "Rect") {

        Button_View.style.height = ConvertDpToPx(Slider_Height.value) + "px";
        Button_View.style.width = ConvertDpToPx(Slider_Width.value) + "px";

        if (checkboxSameCorner.checked == true)
            setSameCorner();
        else {
            setCorTopLeft();
            setCorTopRight();
            setCorBottomLeft();
            setCorBottomRight();
        }

    } else if (shape == "Circle") {
        setShapeCircle();

    } else if (shape == "oval") {
        setShapeOval();
    } else if (shape == "Parallelogram") {
        setShapeParallelogram();
    }

}
/*
function setxxhdpi() {
    screenDP = 5;

    setTextSize();

    setPaddingTop();
    setPaddingBottom();
    setPaddingLeft();
    setPaddingRight();
    Button_View.style.borderWidth = ConvertDpToPx(Slider_StrokeWidth.value) + "px";


    if (BGColor != "solid")
        setGradiant();

    if (shape == "Rect") {

        Button_View.style.height = ConvertDpToPx(Slider_Height.value) + "px";
        Button_View.style.width = ConvertDpToPx(Slider_Width.value) + "px";

        if (checkboxSameCorner.checked == true)
            setSameCorner();
        else {
            setCorTopLeft();
            setCorTopRight();
            setCorBottomLeft();
            setCorBottomRight();
        }

    } else if (shape == "Circle") {
        setShapeCircle();

    } else if (shape == "oval") {
        setShapeOval();
    } else if (shape == "Parallelogram") {
        setShapeParallelogram();
    }

}

*/

function SetDPType(select) {

    switch (select) {

        case "1": setldpi();  break;
        case "2": setmdpi(); break;
        case "3": sethdpi(); break;
        case "4": setxhdpi(); break;



    }


}


function ConvertDpToPx(x) {

    switch (screenDP) {
        case 1: return ((x / 4) * 3 + x % 4); break;
        case 2: return (x); break;
        case 3: return (x * 1.5); break;
        case 4: return (x * 2); break;
        case 5: return (x * 3); break;

    }

}


