﻿
function GenerateCodeView() {

    var CodeButton = "<Button\n android:layout_width=\"wrap_content\"\nandroid:layout_height=\"wrap_content\"\n";

    CodeButton += "android:id=\"@+id/" + TextID.value + "\"\n";

    CodeButton += "android:text=\"" + Text_ValueText.value + "\"\n";
    CodeButton += "android:textColor=\"" + TextChooserColor.value + "\"\n";
    CodeButton += "android:textSize=\"" + Slider_TextSize.value + "sp\"\n";

    if (checkboxBold.value == "true" && checkboxItalic.value == "true")
        CodeButton += "android:textStyle=\"bold|italic\"\n";
    else if (checkboxBold.value == "true")
        CodeButton += "android:textStyle=\"bold\"\n";
    else if (checkboxItalic.value == "true")
        CodeButton += "android:textStyle=\"italic\"\n";


    CodeButton += "android:fontFamily=\"" + FontTybe + "\"\n";



    if (checkboxTextAllCaps.value == "true")
        CodeButton += "android:textAllCaps=\"true\"\n";
    else
        CodeButton += "android:textAllCaps=\"false\"\n";


    CodeButton += "android:gravity=\"" + TextGravity + "\"\n";
    CodeButton += "android:alpha=\"" + (0.1 * Slider_Alpha.value).toFixed(1) + "\"\n";

    if (RadioEnableTrue.value == "true")
        CodeButton += "android:enable=\"true\"\n";
    else
        CodeButton += "android:enable=\"false\"\n";

    CodeButton += "android:shadowColor=" + "\"" + ShadowColor.value + "\"\n";
    CodeButton += "android:shadowDx=\"" + Slider_ShadowCenterX.value + "\"\n";
    CodeButton += "android:shadowDy=\"" + Slider_ShadowCenterY.value + "\"\n";
    CodeButton += "android:shadowRadius=\"" + Slider_ShadowRaduis.value + "\"\n";


    CodeButton += "android:paddingLeft=\"" + Slider_PaddingLeft.value + "dp\"\n";
    CodeButton += "android:paddingRight=\"" + Slider_PaddingRight.value + "dp\"\n";
    CodeButton += "android:paddingTop=\"" + Slider_PaddingTop.value + "dp\"\n";
    CodeButton += "android:paddingBottom=\"" + Slider_PaddingBottom.value + "dp\"\n";

    CodeButton += "android:background=\"@drawable/CustomView\"\n";

    CodeButton += "/>\n";


    return CodeButton;
}


function GenerateCodePadding() {

    var CodePadding = "<padding\n";

    CodePadding += "android:bottom =\"" + Slider_PaddingBottom.value + "dp\"\n";
    CodePadding += "android:top =\"" + Slider_PaddingTop.value + "dp\"\n";
    CodePadding += "android:left =\"" + Slider_PaddingLeft.value + "dp\"\n";
    CodePadding += "android:right =\"" + Slider_PaddingRight.value + "dp\"\n";
    CodePadding += " ></padding>\n";

    return CodePadding;
}


function GenerateCodeStroke() {

    var CodeStroke = "<stroke\n"
    CodeStroke += "android:width=\"" + Slider_StrokeWidth.value + "dp\"\n";
    CodeStroke += "android:color=\"" + StrokeChooserColor.value + "\"\n";

    if (typeStroke == "Dotted") {

        CodeStroke += "android:dashWidth=\"2dp\"\n";
        CodeStroke += "android:dashGap=\"2dp\"\n";

    }
    else if (typeStroke == "Dashed") {

        CodeStroke += "android:dashWidth=\"5dp\"\n";
        CodeStroke += "android:dashGap=\"2dp\"\n";

    }

    CodeStroke += "></stroke>\n";

    return CodeStroke;
}


function GenerateCorner() {

    var CodeCorner = "<corners\n";

    if (flagCheckBoxSameCorner == true) {
        CodeCorner += "android:radius=\"" + Slider_SameCorner.value + "dp\"\n";
    } else {
        CodeCorner += "android:bottomLeftRadius=\"" + Slider_BottomleftCorner.value + "dp\"\n";
        CodeCorner += "android:bottomRightRadius=\"" + Slider_BottomRightCorner.value + "dp\"\n";
        CodeCorner += "android:topLeftRadius=\"" + Slider_TopleftCorner.value + "dp\"\n";
        CodeCorner += "android:topRightRadius=\"" + Slider_TopRightCorner.value + "dp\"\n";
    }

    CodeCorner += "></corners>\n";

    return CodeCorner;
}


function GenerateCodeBGColor() {

    var CodeBGColor;
    if (BGColor == "solid") {

        CodeBGColor = "<solid\n"
        CodeBGColor += "android:color=\"" + SolidChooserColor.value + "\"\n";
        CodeBGColor += "></solid>\n";

    } else {


        CodeBGColor = "<gradient\n";

        if (GradiantType == "linear") {

            CodeBGColor += "android:type=\"linear\"\n";

            var InXMLAngle;

            switch (ValueAngle) {
                case 90: InXMLAngle = 0; break;
                case 45: InXMLAngle = 45; break;
                case 0: InXMLAngle = 90; break;
                case 315: InXMLAngle = 135; break;
                case 270: InXMLAngle = 180; break;
                case 225: InXMLAngle = 225; break;
                case 180: InXMLAngle = 270; break;
                case 135: InXMLAngle = 315; break;

            }

            CodeBGColor += "android:angle=\"" + InXMLAngle + "\"\n";
            CodeBGColor += "android:centerX=\"" + Slider_CenterY.value + "%\"\n";
            CodeBGColor += "android:centerY=\"50%\"\n";



        } else if (GradiantType == "Radial") {

            CodeBGColor += "android:type=\"radial\"\n";

            CodeBGColor += "android:centerX=\"" + Slider_CenterY.value + "%\"\n";
            CodeBGColor += "android:centerY=\"" + Slider_CenterX.value + "%\"\n";
            CodeBGColor += "android:gradientRadius=\"" + Slider_RadialRadius.value + "dp\"\n";

        }

        CodeBGColor += "android:startColor=\"" + GradiantChooserStartColor.value + "\"\n";
        CodeBGColor += "android:centerColor=\"" + GradiantChooserCenterColor.value + "\"\n";
        CodeBGColor += "android:endColor=\"" + GradiantChooserEndColor.value + "\"\n";

        CodeBGColor += "></gradient>\n";
    }

    return CodeBGColor;
}


function GenerateCodeSize() {


    var CodeSize = "<size\n";

    if (shape == "Rect" || shape == "oval") {


        CodeSize += "android:width=\"" + Slider_Width.value + "dp\"\n";
        CodeSize += "android:height=\"" + Slider_Height.value + "dp\"\n";

    }
    else if (shape == "Parallelogram") {

        CodeSize += "android:width=\"" + Slider_Rib.value + "dp\"\n";
        CodeSize += "android:height=\"" + Slider_Rib.value + "dp\"\n";



    } else if (shape == "Circle") {

        CodeSize += "android:width=\"" + Slider_Diameter.value + "dp\"\n";
        CodeSize += "android:height=\"" + Slider_Diameter.value + "dp\"\n";

    }


    CodeSize += "></size>\n";

    return CodeSize;
}

function GenerateCodeShape() {

    var CodeShape;

    if (shape == "Rect") {

        CodeShape = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\n";
        CodeShape += "android:shape=\"rectangle\"\n";
        CodeShape += ">\n";

        CodeShape += GenerateCodePadding();
        CodeShape += GenerateCodeSize();
        CodeShape += GenerateCodeStroke();
        CodeShape += GenerateCodeBGColor();

        CodeShape += GenerateCorner();
        CodeShape += "</shape>\n";

    }
    else if (shape == "Parallelogram") {



        CodeShape = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
        CodeShape += "<layer-list xmlns:android=\"http://schemas.android.com/apk/res/android\" >\n";
        CodeShape += "<item>\n";
        CodeShape += "<rotate\n"

        if (DirectionSkew == "left")
            CodeShape += "android:fromDegrees=\"75\" >\n";
        else
            CodeShape += "android:fromDegrees=\"105\" >\n";



        CodeShape += "<shape\n";
        CodeShape += "android:shape=\"rectangle\"\n";
        CodeShape += ">\n";


        CodeShape += GenerateCodePadding();
        CodeShape += GenerateCodeSize();
        CodeShape += GenerateCodeStroke();
        CodeShape += GenerateCodeBGColor();


        CodeShape += "</shape>\n";

        CodeShape += "</rotate>\n";
        CodeShape += "</item>\n";
        CodeShape += "</layer-list>\n";

    }
    else if (shape == "oval") {
        CodeShape = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\n";
        CodeShape += "android:shape=\"oval\"\n";
        CodeShape += ">\n";

        CodeShape += GenerateCodePadding();
        CodeShape += GenerateCodeSize();
        CodeShape += GenerateCodeStroke();
        CodeShape += GenerateCodeBGColor();

        CodeShape += "</shape>\n";

    }
    else if (shape == "Circle") {
        CodeShape = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\n";
        CodeShape += "android:shape=\"oval\"\n";
        CodeShape += ">\n";


        CodeShape += GenerateCodePadding();
        CodeShape += GenerateCodeSize();
        CodeShape += GenerateCodeStroke();
        CodeShape += GenerateCodeBGColor();


        CodeShape += "</shape>\n";

    }


    return CodeShape;

}

function SetCodeGenerate() {

    document.getElementById("TextCodeView").textContent = GenerateCodeView();
    document.getElementById("TextCodeCustom").textContent = GenerateCodeShape();

}
