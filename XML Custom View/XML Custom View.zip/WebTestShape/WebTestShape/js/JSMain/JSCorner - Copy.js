﻿
var flagCheckBoxSameCorner = true;

function setCheckSameCorner() {

    if (flagCheckBoxSameCorner == false) {

        flagCheckBoxSameCorner = true;

        Slider_SameCorner.disabled = false;

        Slider_TopleftCorner.disabled = true;
        Slider_TopRightCorner.disabled = true;
        Slider_BottomleftCorner.disabled = true;
        Slider_BottomRightCorner.disabled = true;

        Button_View.style.borderRadius = ConvertDpToPx(Slider_SameCorner.value) + "px";

        checkboxSameCorner.checked = true;

    } else {

        flagCheckBoxSameCorner = false;

        Slider_SameCorner.disabled = true;

        Slider_TopleftCorner.disabled = false;
        Slider_TopRightCorner.disabled = false;
        Slider_BottomleftCorner.disabled = false;
        Slider_BottomRightCorner.disabled = false;

        Button_View.style.borderTopLeftRadius = ConvertDpToPx(Slider_TopleftCorner.value) + "px";
        Button_View.style.borderTopRightRadius = ConvertDpToPx(Slider_TopRightCorner.value) + "px";
        Button_View.style.borderBottomLeftRadius = ConvertDpToPx(Slider_BottomleftCorner.value) + "px";
        Button_View.style.borderBottomRightRadius = ConvertDpToPx(Slider_BottomRightCorner.value) + "px";

        checkboxSameCorner.checked = false;
    }

}

function setSameCorner() {

    Button_View.style.borderRadius = ConvertDpToPx(Slider_SameCorner.value) + "px";
    TextViewSameCorner.value = Slider_SameCorner.value;

}


function setCorTopLeft() {

    Button_View.style.borderTopLeftRadius = ConvertDpToPx(Slider_TopleftCorner.value) + "px";
    TextViewTopleftCorner.value = Slider_TopleftCorner.value;
}

function setCorTopRight() {

    Button_View.style.borderTopRightRadius = ConvertDpToPx(Slider_TopRightCorner.value) + "px";
    TextViewTopRightCorner.value = Slider_TopRightCorner.value;
}

function setCorBottomLeft() {

    Button_View.style.borderBottomLeftRadius = ConvertDpToPx(Slider_BottomleftCorner.value) + "px";
    TextViewBottomleftCorner.value = Slider_BottomleftCorner.value;
}

function setCorBottomRight() {

    Button_View.style.borderBottomRightRadius = ConvertDpToPx(Slider_BottomRightCorner.value) + "px";
    TextViewBottomRightCorner.value = Slider_BottomRightCorner.value;
}

