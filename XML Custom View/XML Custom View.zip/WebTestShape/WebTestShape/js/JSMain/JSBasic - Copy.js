﻿
function openTab(tabname, nowtab) {
    var i;

    var x = document.getElementsByClassName("tab");

    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
        // x[i].style.borderColor = "#49f5e9";
    }

    document.getElementById(tabname).style.display = "block";

    document.getElementById("Basic").style.borderColor = "#e9f5e9";
    document.getElementById("Shape").style.borderColor = "#e9f5e9";
    document.getElementById("Text").style.borderColor = "#e9f5e9";
    document.getElementById("Stroke").style.borderColor = "#e9f5e9";
    document.getElementById("BGColor").style.borderColor = "#e9f5e9";
    document.getElementById("Padding").style.borderColor = "#e9f5e9";


    document.getElementById(nowtab).style.borderColor = "black";

}



function ChangeID() {

    var NameID = TextID.value;

    if (NameID == "" || (NameID[0] >= 0 && NameID[0] <= 9))
    { TextID.value = "View_" + Math.floor((Math.random() * 100) + 1); return; }



    for (var i = 0 ; i < NameID.length ; i++) {

        if (NameID[i] == '_' || (NameID[i] >= 'A' && NameID[i] <= 'Z') || (NameID[i] >= 'a' && NameID[i] <= 'z') || (NameID[i] >= 0 && NameID[i] <= 9))
            continue;
        else {

            TextID.value = "View_" + Math.floor((Math.random() * 100) + 1);
            return;
        }

    }


}





function setEnablesTrue() {

    RadioEnableTrue.checked = true;
    RadioEnableFalse.checked = false;

    RadioEnableTrue.value = "true";
    RadioEnableFalse.value = "false";
    Button_View.disabled = false;


}

function setEnablesFalse() {

    RadioEnableTrue.checked = false;
    RadioEnableFalse.checked = true;


    RadioEnableTrue.value = "false";
    RadioEnableFalse.value = "true";

    Button_View.disabled = true;
}


