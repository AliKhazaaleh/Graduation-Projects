﻿function setAlpha() {
    TextViewAlpha.value = Slider_Alpha.value;
    Button_View.style.opacity = 0.1 * Slider_Alpha.value;

}

var BGColor = "solid";
var GradiantType = "linear";
var ValueAngle = 90;

function setSolidColor() {
    Button_View.style.background = SolidChooserColor.value;
}

function setCheckSolidColor() {

    if (BGColor == "solid") {

        BGColor = "gradiant";
        SolidChooserColor.disabled = true;

        SelectGradiantType.disabled = false;
        GradiantChooserStartColor.disabled = false;
        GradiantChooserCenterColor.disabled = false;
        GradiantChooserEndColor.disabled = false;


        if (GradiantType == "linear") {

            SelectLinearAngle.disabled = false;
            Slider_RadialRadius.disabled = true;
            Slider_CenterX.value = 50;
            Slider_CenterX.disabled = true;
            Slider_CenterY.disabled = false;

        } else {

            SelectLinearAngle.disabled = true;
            Slider_RadialRadius.disabled = false;
            Slider_CenterX.disabled = false;
            Slider_CenterY.disabled = false;

        }


        setGradiant();

    } else {

        BGColor = "solid";
        SolidChooserColor.disabled = false;
        Button_View.style.background = SolidChooserColor.value;

        SelectGradiantType.disabled = true;
        GradiantChooserStartColor.disabled = true;
        GradiantChooserCenterColor.disabled = true;
        GradiantChooserEndColor.disabled = true;


        SelectLinearAngle.disabled = true;
        Slider_RadialRadius.disabled = true;
        Slider_CenterX.disabled = true;
        Slider_CenterY.disabled = true;

    }
}


function SetGradiantLinearType() {

    GradiantType = "linear";

    SelectLinearAngle.disabled = false;
    Slider_RadialRadius.disabled = true;
    Slider_CenterX.value = 50;
    Slider_CenterX.disabled = true;
    Slider_CenterY.disabled = false;

    setGradiant();

}


function SetGradiantRadialType() {

    GradiantType = "Radial";

    SelectLinearAngle.disabled = true;
    Slider_RadialRadius.disabled = false;
    Slider_CenterX.disabled = false;
    Slider_CenterY.disabled = false;

    setGradiant();
}

function SetGradiantType(select) {

    switch (select) {

        case "1": SetGradiantLinearType();  break;
        case "2": SetGradiantRadialType(); break;
    }


}

function setGradiant() {

    var perSColorStart = 15, perSColorCenter = 40, perSColorEnd = 80;


    switch (Slider_CenterY.value) {

        case "0": perSColorStart = 0; perSColorCenter = 0; perSColorEnd = 65; break;
        case "25": perSColorStart = 0; perSColorCenter = 30; perSColorEnd = 70; break;
        case "50": perSColorStart = 15; perSColorCenter = 40; perSColorEnd = 85; break;
        case "75": perSColorStart = 20; perSColorCenter = 60; perSColorEnd = 90; break;
        case "100": perSColorStart = 0; perSColorCenter = 100; perSColorEnd = 100; break;
    }


    TextViewCenterY.value = Slider_CenterY.value;
    TextViewCenterX.value = Slider_CenterX.value;
    TextViewRadialRadius.value = Slider_RadialRadius.value;

    if (GradiantType == "linear") {

        Button_View.style.backgroundImage = "linear-gradient(" + ValueAngle + "deg ," + GradiantChooserStartColor.value + " " + perSColorStart + "%" + ", " + GradiantChooserCenterColor.value + " " + perSColorCenter + "%" + " ," + GradiantChooserEndColor.value + " " + perSColorEnd + "%" + ")";


    } else {
        //   Button_View.style.backgroundImage = "radial-gradient(at 10%  100px ,  red, yellow, black)";
        if (shape == "Circle")
            Button_View.style.backgroundImage = "radial-gradient(" + ConvertDpToPx(Slider_RadialRadius.value) / (5 * screenDP) + "em " + ConvertDpToPx(Slider_RadialRadius.value) + "px " + "at " + Slider_CenterY.value + "%" + ((ConvertDpToPx(Slider_Diameter.value) / 100) * Slider_CenterX.value) + "px , " + GradiantChooserStartColor.value + ", " + GradiantChooserCenterColor.value + "," + GradiantChooserEndColor.value + ")";
        else
            Button_View.style.backgroundImage = "radial-gradient(" + ConvertDpToPx(Slider_RadialRadius.value) / (5 * screenDP) + "em " + ConvertDpToPx(Slider_RadialRadius.value) + "px " + "at " + Slider_CenterY.value + "%" + ((ConvertDpToPx(Slider_Height.value) / 100) * Slider_CenterX.value) + "px , " + GradiantChooserStartColor.value + ", " + GradiantChooserCenterColor.value + "," + GradiantChooserEndColor.value + ")";
    }

}


function setValueAngle0360() {
    ValueAngle = 90;
    setGradiant();
}



function setValueAngle45() {
    ValueAngle = 45;
    setGradiant();
}



function setValueAngle90() {
    ValueAngle = 0;
    setGradiant();
}



function setValueAngle135() {
    ValueAngle = 315;
    setGradiant();
}


function setValueAngle180() {
    ValueAngle = 270;
    setGradiant();
}


function setValueAngle225() {
    ValueAngle = 225;
    setGradiant();
}


function setValueAngle270() {
    ValueAngle = 180;
    setGradiant();
}

function setValueAngle315() {
    ValueAngle = 135;
    setGradiant();
}


function SetAngleType(select){

    switch (select) {

        case "1": setValueAngle0360(); break;
        case "2": setValueAngle45(); break;
        case "3": setValueAngle90(); break;
        case "4": setValueAngle135(); break;
        case "5": setValueAngle180(); break;
        case "6": setValueAngle225(); break;
        case "7": setValueAngle270(); break;
        case "8": setValueAngle315(); break;
        
    }
}