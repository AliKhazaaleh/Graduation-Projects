﻿
var TextGravity = "center";
var FontTybe = "sans-serif";


function setText() {
    Button_View.value = Text_ValueText.value;
}

function setTextSize() {
    Button_View.style.fontSize = ConvertDpToPx(Slider_TextSize.value) + "px";
    TextViewTextSize.value = Slider_TextSize.value;
}

function setTextColor() {
    Button_View.style.color = TextChooserColor.value;
}


function setBold() {

    if (checkboxBold.value == "true") {
        checkboxBold.value = "false";
        Button_View.style.fontWeight = "normal";
    } else {
        checkboxBold.value = "true";
        Button_View.style.fontWeight = "Bold";
    }

}

function setItalic() {

    if (checkboxItalic.value == "true") {
        checkboxItalic.value = "false";
        Button_View.style.fontStyle = "normal";
    } else {
        checkboxItalic.value = "true";
        Button_View.style.fontStyle = "italic";
    }
}


function setTextALLcaps() {

    if (checkboxTextAllCaps.value == "true") {
        checkboxTextAllCaps.value = "false";
        Button_View.style.textTransform = "none";
    } else {
        checkboxTextAllCaps.value = "true";
        Button_View.style.textTransform = "uppercase";
    }
}

function setFontCursive() {
    Button_View.style.fontFamily = "cursive";
    FontTybe = "cursive";
}

function setFontSerif() {
    Button_View.style.fontFamily = "serif";
    FontTybe = "serif";
}

function setFontMonoSpace() {
    Button_View.style.fontFamily = "monospace";
    FontTybe = "monospace";
}

function setFontDefault() {
    Button_View.style.fontFamily = "sans-serif";
    FontTybe = "sans-serif";
}

function setFontCasual() {
    Button_View.style.fontFamily = "Comic Sans MS";
    FontTybe = "casual";
}

function SetFontType(select) {

    switch (select) {

        case "1": setFontDefault(); break;
        case "2": setFontCursive(); break;
        case "3": setFontSerif(); break;
        case "4": setFontMonoSpace(); break;
        case "5": setFontCasual(); break;

    }
}


function setAlignTextLeft() {
    Button_View.style.textAlign = "left";
    TextGravity = "left|center_vertical";
}

function setAlignTextRight() {
    Button_View.style.textAlign = "right";
    TextGravity = "right|center_vertical";
}

function setAlignTextCenter() {
    Button_View.style.textAlign = "center";
    TextGravity = "center";
}


function SetTextGravity(select){

    switch (select){
    
        case "1": setAlignTextCenter(); break;
        case "2": setAlignTextLeft(); break;
        case "3": setAlignTextRight(); break;

    }

}


function setShadow() {

    TextViewShadowCenterX.value = Slider_ShadowCenterX.value;
    TextViewShadowCenterY.value = Slider_ShadowCenterY.value;
    TextViewShadowRadius.value = Slider_ShadowRaduis.value;

    Button_View.style.textShadow = Slider_ShadowCenterX.value + "px " + Slider_ShadowCenterY.value + "px " + Slider_ShadowRaduis.value + "px " + ShadowColor.value;


}


function sendMail() {


}