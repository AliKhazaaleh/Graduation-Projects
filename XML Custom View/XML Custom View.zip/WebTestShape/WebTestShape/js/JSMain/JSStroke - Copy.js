﻿var typeStroke = "normal";

function setStrokeWidth() {


    if (shape == "Parallelogram") {
        Button_View.style.borderWidth = 0 + "px " + ConvertDpToPx(Slider_StrokeWidth.value) + "px " + 0 + "px " + ConvertDpToPx(Slider_StrokeWidth.value) + "px";
    }
    else {
        Button_View.style.borderWidth = ConvertDpToPx(Slider_StrokeWidth.value) + "px";
    }

    TextViewStrokeWidth.value = Slider_StrokeWidth.value;
    Button_View.style.borderColor = StrokeChooserColor.value;

}

function setStrokeColor() {

    if (Slider_StrokeWidth.value > 0 || RadioDashed.checked == true || RadioDotted == true) {
        Button_View.style.borderColor = StrokeChooserColor.value;


    }

}

function setDottedStroke() {

    if (typeStroke == "Dotted") {

        typeStroke = "normal";
        Button_View.style.borderStyle = "solid";

        setStrokeWidth();
        setStrokeColor();
    } else {
        typeStroke = "Dotted";
        RadioDashed.checked = false;
        Button_View.style.borderStyle = "dotted";
    }


}


function setDashedStroke() {

    if (typeStroke == "Dashed") {

        typeStroke = "normal";
        Button_View.style.borderStyle = "solid";
        setStrokeWidth();
        setStrokeColor();
    } else {
        typeStroke = "Dashed";
        RadioDotted.checked = false;
        Button_View.style.borderStyle = "dashed";
    }
}