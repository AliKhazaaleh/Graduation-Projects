﻿class RadioButton extends View {

    constructor(CustomView) {
        super(CustomView);
        this.text = "RadioButton";
        this.checked = false;
        this.text_gravity = "left|center_vertical";

    }

    // Add Methods For Text of RadioButton
    setText(Value) {
        this.text = Value;
        document.getElementById('RadioButton_Text').textContent = Value;
    }


    setEnablesTrue(CustomType) {

        document.getElementById(CustomType + '_RadioEnableTrue').checked = true;
        document.getElementById(CustomType + '_RadioEnableFalse').checked = false;

        this.enable = true;
        ViewShow.disabled = false;
        RadioPartCheck.disabled = false;
    }

    setEnablesFalse(CustomType) {

        document.getElementById(CustomType + '_RadioEnableTrue').checked = false;
        document.getElementById(CustomType + '_RadioEnableFalse').checked = true;

        this.enable = false;
        ViewShow.disabled = true;
        RadioPartCheck.disabled = true;
    }

    setCheckedTrue(CustomType) {
        document.getElementById(CustomType + '_RadioCheckedTrue').checked = true;
        document.getElementById(CustomType + '_RadioCheckedFalse').checked = false;

        this.Checked = true;
        RadioPartCheck.checked = true;
    }

    setCheckedFalse(CustomType) {

        document.getElementById(CustomType + '_RadioCheckedTrue').checked = false;
        document.getElementById(CustomType + '_RadioCheckedFalse').checked = true;

        this.checked = false;
        RadioPartCheck.checked = false;
    }

    setTextSize(Value) {

        this.text_size = Value;
        TextViewTextSize.value = this.text_size;
        RadioButton_Text.style.fontSize = ConvertDpToPx(this.text_size) + "px";
    }



    setBold() {

        if (this.bold) {
            this.bold = false;
            RadioButton_Text.style.fontWeight = "normal";
        } else {
            this.bold = true;
            RadioButton_Text.style.fontWeight = "Bold";
        }
    }

    setItalic() {

        if (this.italic) {
            this.italic = false;
            RadioButton_Text.style.fontStyle = "normal";
        } else {
            this.italic = true;
            RadioButton_Text.style.fontStyle = "italic";
        }
    }

    // End Methods For Text of RadioButton



    // Functions For Generate Code RadioButton  
    GenerateCodeRadioButton() {

        var CodeRadioButton = "<RadioButton\n android:layout_width=\"wrap_content\"\nandroid:layout_height=\"wrap_content\"\n" + "";

        CodeRadioButton += "android:id=\"@+id/" + this.id + "\"\n";
        CodeRadioButton += "android:text=\"" + this.text + "\"\n";
        CodeRadioButton += "android:textColor=\"" + this.text_color + "\"\n";
        CodeRadioButton += "android:textSize=\"" + this.text_size + "sp\"\n";


        if (this.bold && this.italic)
            CodeRadioButton += "android:textStyle=\"bold|italic\"\n";
        else if (this.bold)
            CodeRadioButton += "android:textStyle=\"bold\"\n";
        else if (this.italic)
            CodeRadioButton += "android:textStyle=\"italic\"\n";

        CodeRadioButton += "android:fontFamily=\"" + this.font_family + "\"\n";

        if (this.text_all_caps)
            CodeRadioButton += "android:textAllCaps=\"true\"\n";
        else
            CodeRadioButton += "android:textAllCaps=\"false\"\n";

        CodeRadioButton += "android:gravity=\"" + this.text_gravity + "\"\n";
        CodeRadioButton += "android:alpha=\"" + (0.1 * this.alpha).toFixed(1) + "\"\n";
        CodeRadioButton += "android:enabled=\"" + this.enable + "\"\n";
        CodeRadioButton += "android:checked=\"" + this.checked + "\"\n";

        CodeRadioButton += "android:shadowColor=" + "\"" + this.shadow_color + "\"\n";
        CodeRadioButton += "android:shadowDx=\"" + this.shadow_center_x + "\"\n";
        CodeRadioButton += "android:shadowDy=\"" + this.shadow_center_y + "\"\n";
        CodeRadioButton += "android:shadowRadius=\"" + this.shadow_radius + "\"\n";

        CodeRadioButton += "android:paddingLeft=\"" + this.padding_left + "dp\"\n" + "";
        CodeRadioButton += "android:paddingRight=\"" + this.padding_right + "dp\"\n";
        CodeRadioButton += "android:paddingTop=\"" + this.padding_top + "dp\"\n";
        CodeRadioButton += "android:paddingBottom=\"" + this.padding_bottom + "dp\"\n";

        CodeRadioButton += "android:background=\"@drawable/Write Name File ???\"\n";

        CodeRadioButton += "/>\n";

        return CodeRadioButton;
    }
    // end Function Generate Code RadioButton

}

var myRadioButton = new RadioButton("RadioButton");
