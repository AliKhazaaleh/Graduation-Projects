﻿class Button extends View {

    constructor(CustomView) {
        super(CustomView);
        this.text = "Button";
    }

    // Add Methods For Text of Button
    setText(Value) {
        this.text = Value;
        ViewShow.value = this.text;
    }

    // End Methods For Text of Button


    // Functions For Generate Code Button   
    GenerateCodeButton() {

        var CodeButton = "<Button\n android:layout_width=\"wrap_content\"\nandroid:layout_height=\"wrap_content\"\n" + "";

        CodeButton += "android:id=\"@+id/" + this.id + "\"\n";
        CodeButton += "android:text=\"" + this.text + "\"\n";
        CodeButton += "android:textColor=\"" + this.text_color + "\"\n";
        CodeButton += "android:textSize=\"" + this.text_size + "sp\"\n";

        if (this.bold && this.italic)
            CodeButton += "android:textStyle=\"bold|italic\"\n";
        else if (this.bold)
            CodeButton += "android:textStyle=\"bold\"\n";
        else if (this.italic)
            CodeButton += "android:textStyle=\"italic\"\n";

        CodeButton += "android:fontFamily=\"" + this.font_family + "\"\n";

        if (this.text_all_caps)
            CodeButton += "android:textAllCaps=\"true\"\n";
        else
            CodeButton += "android:textAllCaps=\"false\"\n";

        CodeButton += "android:gravity=\"" + this.text_gravity + "\"\n";
        CodeButton += "android:alpha=\"" + (0.1 * this.alpha).toFixed(1) + "\"\n";
        CodeButton += "android:enabled=\"" + this.enable + "\"\n";

        CodeButton += "android:shadowColor=" + "\"" + this.shadow_color + "\"\n";
        CodeButton += "android:shadowDx=\"" + this.shadow_center_x + "\"\n";
        CodeButton += "android:shadowDy=\"" + this.shadow_center_y + "\"\n";
        CodeButton += "android:shadowRadius=\"" + this.shadow_radius + "\"\n";

        CodeButton += "android:paddingLeft=\"" + this.padding_left + "dp\"\n" + "";
        CodeButton += "android:paddingRight=\"" + this.padding_right + "dp\"\n";
        CodeButton += "android:paddingTop=\"" + this.padding_top + "dp\"\n";
        CodeButton += "android:paddingBottom=\"" + this.padding_bottom + "dp\"\n";

        CodeButton += "android:background=\"@drawable/Write Name File ???\"\n";

        CodeButton += "/>\n";

        return CodeButton;
    }
    // end Function Generate Code Button

}

var myButton = new Button("Button");

