﻿/// <reference path="JSClassesCustom.js" />

// --------------------------------------------- start class Stroke 
class Stroke {

    constructor() {
        this.type = "normal";
        this.width = 0;
        this.color = "#000000";
    }

    setStrokeWidth(shape , Value) {

        this.width = Value;
        TextViewStrokeWidth.value = this.width;
        ViewShow.style.borderColor = this.color;


        if (this.type == 'normal')
            ViewShow.style.borderStyle = "solid";

        if (shape == "Parallelogram") {
            ViewShow.style.borderWidth = 0 + "px " + ConvertDpToPx(this.width) + "px " + 0 + "px " + ConvertDpToPx(this.width) + "px";
        }
        else {
            ViewShow.style.borderWidth = ConvertDpToPx(this.width) + "px";
        }

       

    }

    setStrokeColor(Value) {

        this.color = Value;
        if (this.width > 0) {   
            ViewShow.style.borderColor = this.color;
        }

    }

   
    setDashedStroke(CustomType) {

        if (this.type == "Dashed") {

            this.type = "normal";
            ViewShow.style.borderStyle = "solid";
            document.getElementById(CustomType + '_RadioDashed').checked = false;
            setStrokeWidth();
       

        } else {
            this.type = "Dashed";
            ViewShow.style.borderStyle = "dashed";
        }
    }

     GenerateCodeStroke() {

        var CodeStroke = "<stroke\n"
        CodeStroke += "android:width=\"" + this.width + "dp\"\n";
        CodeStroke += "android:color=\"" + this.color + "\"\n";

        if (this.type == "Dashed") {
            CodeStroke += "android:dashWidth=\"" + (6 * (this.width / 3)) + "dp\"\n";
            CodeStroke += "android:dashGap=\"" + (3 * (this.width / 3)) + "dp\"\n";
        }

        CodeStroke += "></stroke>\n";
        return CodeStroke;
    }

}

// ------------------------------------------------ end Class Stroke 

//------------------------------------------------- start Class Corners

class Corners {

    constructor() {
        this.flag_same = true;
        this.same = 0;
        this.top_left = 8;
        this.top_right = 8;
        this.bottom_left = 8;
        this.bottom_right = 8;
    }


    setCheckSameCorner(CustomType) {

        if (this.flag_same == false) {

            this.flag_same = true;

            
            document.getElementById(CustomType + '_Slider_SameCorner').disabled = false;

            document.getElementById(CustomType + '_Slider_TopRightCorner').disabled = true;
            document.getElementById(CustomType + '_Slider_TopleftCorner').disabled = true;
            document.getElementById(CustomType + '_Slider_BottomRightCorner').disabled = true;
            document.getElementById(CustomType + '_Slider_BottomleftCorner').disabled = true;

            ViewShow.style.borderRadius = ConvertDpToPx(this.same) + "px";


        } else {

            this.flag_same = false;


            document.getElementById(CustomType + '_Slider_SameCorner').disabled = true;

            document.getElementById(CustomType + '_Slider_TopRightCorner').disabled = false;
            document.getElementById(CustomType + '_Slider_TopleftCorner').disabled = false;
            document.getElementById(CustomType + '_Slider_BottomRightCorner').disabled = false;
            document.getElementById(CustomType + '_Slider_BottomleftCorner').disabled = false;

            ViewShow.style.borderTopLeftRadius = ConvertDpToPx(this.top_left) + "px";
            ViewShow.style.borderTopRightRadius = ConvertDpToPx(this.top_right) + "px";
            ViewShow.style.borderBottomLeftRadius = ConvertDpToPx(this.bottom_left) + "px";
            ViewShow.style.borderBottomRightRadius = ConvertDpToPx(this.bottom_right) + "px";

        }

    }


    setSameCorner(Value) {

        this.same = Value;
        TextViewSameCorner.value = this.same;
        ViewShow.style.borderRadius = ConvertDpToPx(this.same) + "px";
        
       
    }


    setCorTopLeft(Value) {
        ViewShow.style.borderTopLeftRadius = ConvertDpToPx(Value) + "px";
        TextViewTopleftCorner.value = Value;
        this.top_left = Value;
    }
    
    setCorTopRight(Value){
        ViewShow.style.borderTopRightRadius = ConvertDpToPx(Value) + "px";
        TextViewTopRightCorner.value = Value;
        this.top_right = Value;
    }

    setCorBottomLeft(Value) {
        ViewShow.style.borderBottomLeftRadius = ConvertDpToPx(Value) + "px";
        TextViewBottomleftCorner.value = Value;
        this.bottom_left = Value;
    }

    setCorBottomRight(Value) {
        ViewShow.style.borderBottomRightRadius = ConvertDpToPx(Value) + "px";
        TextViewBottomRightCorner.value = Value;
        this.bottom_right = Value;
    }



    GenerateCorner() {

        var CodeCorner = "<corners\n";

        if (this.flag_same == true) {
            CodeCorner += "android:radius=\"" + this.same + "dp\"\n";
        } else {
            CodeCorner += "android:bottomLeftRadius=\"" + this.bottom_left + "dp\"\n";
            CodeCorner += "android:bottomRightRadius=\"" + this.bottom_right + "dp\"\n";
            CodeCorner += "android:topLeftRadius=\"" + this.top_left + "dp\"\n";
            CodeCorner += "android:topRightRadius=\"" + this.top_right + "dp\"\n";
        }

        CodeCorner += "></corners>\n";

        return CodeCorner;
    }

}


//------------------------------------------------- end Class Corners

//------------------------------------------------- start Class Solid

class Solid  {

    constructor() {
        this.color = "#29ab23";
    }

    setSolidColor(Value) {
        this.color = Value;
        ViewShow.style.background = this.color;
    }

    GenerateCodeSolid() {

        var CodeSolid = "<solid\n";
        CodeSolid += "android:color=\"" + this.color + "\"\n";
        CodeSolid += "></solid>\n";

        return CodeSolid;
    }

}
// ----------------------------------------------- end Class Solid
// ----------------------------------------------- start Class Gradient

class Gradient {

    constructor() {
        this.type = "linear";
        this.start_color = "#ff6b6b";
        this.center_color = "#ffe66d";
        this.end_color = "#292f36";
        this.radial_radius = 30;
        this.center_x = 50;
        this.center_y = 50;
        this.angle = 90;
    }

    setValueAngle0360(CustomType) {
        this.angle = 90;
        this.setGradiant(CustomType);
    }

    setValueAngle45(CustomType) {
        this.angle = 45;
        this.setGradiant(CustomType);
    }

    setValueAngle90(CustomType) {
        this.angle = 0;
        this.setGradiant(CustomType);
    }

    setValueAngle135(CustomType) {
        this.angle = 315;
        this.setGradiant(CustomType);
    }

    setValueAngle180(CustomType) {
        this.angle = 270;
        this.setGradiant(CustomType);
    }

    setValueAngle225(CustomType) {
        this.angle = 225;
        this.setGradiant(CustomType);
    }

    setValueAngle270(CustomType) {
        this.angle = 180;
        this.setGradiant(CustomType);
    }

    setValueAngle315(CustomType) {
        this.angle = 135;
        this.setGradiant(CustomType);
    }

    SetAngleType(select, CustomType) {

        switch (select) {
            case "1": this.setValueAngle0360(CustomType); break;
            case "2": this.setValueAngle45(CustomType); break;
            case "3": this.setValueAngle90(CustomType); break;
            case "4": this.setValueAngle135(CustomType); break;
            case "5": this.setValueAngle180(CustomType); break;
            case "6": this.setValueAngle225(CustomType); break;
            case "7": this.setValueAngle270(CustomType); break;
            case "8": this.setValueAngle315(CustomType); break;
        }
    }


    SetGradiantLinearType(CustomType) {

        this.type = "linear";

        document.getElementById(CustomType + '_SelectLinearAngle').disabled = false;
        document.getElementById(CustomType + '_Slider_RadialRadius').disabled = true;
        document.getElementById(CustomType + '_Slider_Center_Y').value = 50;
        document.getElementById(CustomType + '_Slider_Center_Y').disabled = true;
        document.getElementById(CustomType + '_Slider_Center_X').disabled = false;



        this.setGradiant(CustomType);

    }


    SetGradiantRadialType(CustomType) {

        this.type = "Radial";

        document.getElementById(CustomType + '_SelectLinearAngle').disabled = true;
        document.getElementById(CustomType + '_Slider_RadialRadius').disabled = false;
        document.getElementById(CustomType + '_Slider_Center_Y').disabled = false;
        document.getElementById(CustomType + '_Slider_Center_X').disabled = false;


        this.setGradiant(CustomType);
    }

    SetGradiantType(select , CustomType) {

        switch (select) {

            case "1": this.SetGradiantLinearType(CustomType); break;
            case "2": this.SetGradiantRadialType(CustomType); break;
        }


    }

    setGradiant(CustomType) {

        this.center_x = document.getElementById(CustomType + '_Slider_Center_X').value;
        this.center_y = document.getElementById(CustomType + '_Slider_Center_Y').value;
        this.radial_radius = document.getElementById(CustomType + '_Slider_RadialRadius').value;

        this.start_color = document.getElementById(CustomType + '_GradiantChooserStartColor').value;
        this.center_color = document.getElementById(CustomType + '_GradiantChooserCenterColor').value;
        this.end_color = document.getElementById(CustomType + '_GradiantChooserEndColor').value;

        var perSColorStart = 15, perSColorCenter = 40, perSColorEnd = 80;


        switch (this.center_x) {

            case "0": perSColorStart = 0; perSColorCenter = 0; perSColorEnd = 65; break;
            case "25": perSColorStart = 0; perSColorCenter = 30; perSColorEnd = 70; break;
            case "50": perSColorStart = 15; perSColorCenter = 40; perSColorEnd = 85; break;
            case "75": perSColorStart = 20; perSColorCenter = 60; perSColorEnd = 90; break;
            case "100": perSColorStart = 0; perSColorCenter = 100; perSColorEnd = 100; break;
        }


      
        TextViewCenter_X.value = this.center_x;
        TextViewCenter_Y.value = this.center_y;
        TextViewRadialRadius.value = this.radial_radius;

     
        if (this.type == "linear") {

            ViewShow.style.backgroundImage = "linear-gradient(" + this.angle + "deg ," + this.start_color + " " + perSColorStart + "%" + ", " + this.center_color + " " + perSColorCenter + "%" + " ," + this.end_color + " " + perSColorEnd + "%" + ")";

        } else {

            var object;

            switch (CustomType) {
                case 'Button': object = myButton; break;
                case 'TextView': object = myTextView; break;
                case 'RadioButton': object = myRadioButton; break;
                case 'CheckBox': object = myCheckBox; break;
                case 'Shape': object = myButton; break;
                case 'EditText': object = myEditText; break;
            }

            //   Button_View.style.backgroundImage = "radial-gradient(at 10%  100px ,  red, yellow, black)";
            if (object.myShape.type == "Circle")
                ViewShow.style.backgroundImage = "radial-gradient(" + ConvertDpToPx(this.radial_radius) / (5 * screenDP) + "em " + ConvertDpToPx(this.radial_radius) + "px " + "at " + this.center_x + "%" + ((ConvertDpToPx(document.getElementById(CustomType + '_Slider_Diameter').value) / 100) * this.center_y) + "px , " + this.start_color + ", " + this.center_color + "," + this.end_color + ")";   
            else
                ViewShow.style.backgroundImage = "radial-gradient(" + ConvertDpToPx(this.radial_radius) / (5 * screenDP) + "em " + ConvertDpToPx(this.radial_radius) + "px " + "at " + this.center_x + "%" + ((ConvertDpToPx(document.getElementById(CustomType + '_Slider_Height').value) / 100) * this.center_y) + "px , " + this.start_color + ", " + this.center_color + "," + this.end_color + ")";
        }

    }



    GenerateCodeGradient() {
     
       var CodeGra = "<gradient\n";
        
        if (this.type == "linear") {

            CodeGra += "android:type=\"linear\"\n";

            var InXMLAngle;

            switch (this.angle) {
                case 90: InXMLAngle = 0; break;
                case 45: InXMLAngle = 45; break;
                case 0: InXMLAngle = 90; break;
                case 315: InXMLAngle = 135; break;
                case 270: InXMLAngle = 180; break;
                case 225: InXMLAngle = 225; break;
                case 180: InXMLAngle = 270; break;
                case 135: InXMLAngle = 315; break;
            }

            CodeGra += "android:angle=\"" + InXMLAngle + "\"\n";
            CodeGra += "android:centerX=\"" + this.center_x + "%\"\n";
            CodeGra += "android:centerY=\"50%\"\n";

        } else if (this.type == "Radial") {

            CodeGra += "android:type=\"radial\"\n";

            CodeGra += "android:centerX=\"" + this.center_x + "%\"\n";
            CodeGra += "android:centerY=\"" + this.center_y + "%\"\n";
            CodeGra += "android:gradientRadius=\"" + this.radial_radius + "dp\"\n";

        }

        CodeGra += "android:startColor=\"" + this.start_color + "\"\n";
        CodeGra += "android:centerColor=\"" + this.center_color + "\"\n";
        CodeGra += "android:endColor=\"" + this.end_color + "\"\n";
        

        CodeGra += "></gradient>\n";


        return CodeGra;
    }


}
// -------------------------------------------------------- end Class Gradient
// -------------------------------------------------------- start Class BGColor
class BGColor {
    constructor() {
        this.type = "solid";
        this.ob_solid = new Solid();
        this.ob_gradient = new Gradient();
    }

    setCheckSolidColor(CustomType) {

        if (this.type == "solid") {

            this.type = "gradient";
            document.getElementById(CustomType + '_SolidChooserColor').disabled = true;

            document.getElementById(CustomType + '_SelectGradiantType').disabled = false;
            document.getElementById(CustomType + '_GradiantChooserStartColor').disabled = false;
            document.getElementById(CustomType + '_GradiantChooserCenterColor').disabled = false;
            document.getElementById(CustomType + '_GradiantChooserEndColor').disabled = false;
            
      

            if (this.ob_gradient.type == "linear") {

                document.getElementById(CustomType + '_SelectLinearAngle').disabled = false;
                document.getElementById(CustomType + '_Slider_RadialRadius').disabled = true;
                document.getElementById(CustomType + '_Slider_Center_Y').value = 50;
                document.getElementById(CustomType + '_Slider_Center_Y').disabled = true;
                document.getElementById(CustomType + '_Slider_Center_X').disabled = false;
             
          
                          

            } else {


                document.getElementById(CustomType + '_SelectLinearAngle').disabled = true;
                document.getElementById(CustomType + '_Slider_RadialRadius').disabled = false;

                document.getElementById(CustomType + '_Slider_Center_Y').disabled = false;
                document.getElementById(CustomType + '_Slider_Center_X').disabled = false;


            }


            this.ob_gradient.setGradiant(CustomType);

        } else {

            this.type = "solid";
            document.getElementById(CustomType + '_SolidChooserColor').disabled = false;
            ViewShow.style.background = this.ob_solid.color;


            document.getElementById(CustomType + '_SelectGradiantType').disabled = true;
            
            document.getElementById(CustomType + '_GradiantChooserStartColor').disabled = true;
            document.getElementById(CustomType + '_GradiantChooserCenterColor').disabled = true;
            document.getElementById(CustomType + '_GradiantChooserEndColor').disabled = true;


            document.getElementById(CustomType + '_SelectLinearAngle').disabled = true;
            document.getElementById(CustomType + '_Slider_RadialRadius').disabled = true;

            document.getElementById(CustomType + '_Slider_Center_Y').disabled = true;
            document.getElementById(CustomType + '_Slider_Center_X').disabled = true;

        }
    }


    GenerateCodeBGColor() {
       if (this.type == "gradient")
        return this.ob_gradient.GenerateCodeGradient();
       else
           return this.ob_solid.GenerateCodeSolid();
    }


}


// -------------------------------------------------------- end Class BGColor

class Shape {

    constructor(CustomType) {

        this.width = 105;
        this.height = 40;
        this.diameter = 70;
        this.rib = 70;

        this.dir_skew = "left";
        this.ob_stroke = new Stroke();
        this.ob_corners = new Corners();
        this.ob_BGcolor = new BGColor();       
       
 switch(CustomType){
     case 'Button': this.setIniValuesForButton(); break;
     case 'TextView': this.setIniValuesForTextView(); break;
     case 'EditText': this.setIniValuesForEditText(); break;
     case 'RadioButton': this.setIniValuesForRadioButton(); break;
     case 'CheckBox': this.setIniValuesForCheckBox(); break;
     case 'Shape': this.setIniValuesForShape(); break;
        }
    }

    setIniValuesForButton() {       
        this.type = "Rect";
        this.ob_BGcolor.ob_solid.color = "#29ab23";
    }
 
    setIniValuesForTextView() {
        this.type = "Rect";
        this.ob_stroke.width = "3";
        this.ob_stroke.color = "#4DDA1B";
        this.ob_BGcolor.ob_solid.color = "#D3F9D3";
    }


    setIniValuesForEditText() {
        this.type = "Rect";
        this.ob_stroke.width = 3;
        this.ob_stroke.color = "#4DDA1B";
        this.ob_BGcolor.ob_solid.color = "#F1E722";
    }

    setIniValuesForRadioButton() {
        this.type = "oval";
        this.ob_BGcolor.ob_solid.color = "#29ab23";
    }

    setIniValuesForCheckBox() {
        this.type = "oval";
        this.ob_BGcolor.ob_solid.color = "#29ab23";
    }

    setIniValuesForShape() {
        this.type = "Rect";   
        this.ob_BGcolor.ob_solid.color = "#29ab23";
    }
    

    setwidth(Value) {
        this.width = Value;

        ViewShow.style.width = ConvertDpToPx(this.width) + "px";
        TextViewWidth.value = this.width;
        

        if (this.type == "oval")
            ViewShow.style.borderRadius = "50%";;

        if (this.ob_BGcolor.type == "gradient") {
            this.ob_BGcolor.ob_gradient.setGradiant();
        }

    }

    setheight(Value) {
        this.height = Value;

        ViewShow.style.height = ConvertDpToPx(this.height) + "px";
        TextViewHeight.value = this.height;

        if (this.type == "oval")
            ViewShow.style.borderRadius = "50%";

        if ( checkboxSolid.checked == false) {
            this.ob_BGcolor.ob_gradient.setGradiant();
        }
    }

    setDiameter(Value) {
        this.diameter = Value;
        ViewShow.style.height = ConvertDpToPx(this.diameter) + "px";
        ViewShow.style.width = ConvertDpToPx(this.diameter) + "px";
        ViewShow.style.borderRadius = "50%";
        TextViewDiameter.value = this.diameter;
    }

    setRib(Value) {
        this.rib = Value;
        ViewShow.style.width = ConvertDpToPx(this.rib) + "px";
        ViewShow.style.height = ConvertDpToPx(this.rib) + "px";
        TextViewRib.value = this.rib;
    }



    setShapeRect(CustomType) {

        this.type = "Rect";
      
        document.getElementById(CustomType + '_Slider_Width').disabled = false;
        document.getElementById(CustomType + '_Slider_Height').disabled = false;
        document.getElementById(CustomType + '_Slider_Diameter').disabled = true;
        document.getElementById(CustomType + '_Slider_Rib').disabled = true ;
        document.getElementById(CustomType + '_SelectSkew').disabled = true;
       

        ViewShow.style.height = ConvertDpToPx(this.height) + "px";
        ViewShow.style.width = ConvertDpToPx(this.width) + "px";

        ViewShow.style.transform = "skew(" + 0 + "deg)";
        
        document.getElementById(CustomType + '_checkboxSameCorner').disabled = false;


        if (this.ob_corners.flag_same == false) {
            document.getElementById(CustomType + '_Slider_SameCorner').disabled = true;
            
            document.getElementById(CustomType + '_Slider_TopleftCorner').disabled = false;
            document.getElementById(CustomType + '_Slider_TopRightCorner').disabled = false;
            document.getElementById(CustomType + '_Slider_BottomleftCorner').disabled = false;
            document.getElementById(CustomType + '_Slider_BottomRightCorner').disabled = false;

            ViewShow.style.borderTopLeftRadius = ConvertDpToPx(this.ob_corners.top_left) + "px";
            ViewShow.style.borderTopRightRadius = ConvertDpToPx(this.ob_corners.top_right) + "px";
            ViewShow.style.borderBottomLeftRadius = ConvertDpToPx(this.ob_corners.bottom_left) + "px";
            ViewShow.style.borderBottomRightRadius = ConvertDpToPx(this.ob_corners.bottom_right) + "px";


        } else {

            document.getElementById(CustomType + '_Slider_SameCorner').disabled = false;

            document.getElementById(CustomType + '_Slider_TopleftCorner').disabled = true;
            document.getElementById(CustomType + '_Slider_TopRightCorner').disabled = true;
            document.getElementById(CustomType + '_Slider_BottomleftCorner').disabled = true;
            document.getElementById(CustomType + '_Slider_BottomRightCorner').disabled = true;

            ViewShow.style.borderRadius = ConvertDpToPx(this.ob_corners.same) + "px";
        }


        this.ob_stroke.setStrokeWidth(this.type, this.ob_stroke.width);

        if (this.ob_BGcolor.type != "solid")
            this.ob_BGcolor.ob_gradient.setGradiant(CustomType);
    }

    setShapeCircle(CustomType) {

        this.type = "Circle";
        document.getElementById(CustomType + '_Slider_Width').disabled = true;
        document.getElementById(CustomType + '_Slider_Height').disabled = true;

        document.getElementById(CustomType + '_Slider_Diameter').disabled = false;
        document.getElementById(CustomType + '_Slider_Rib').disabled = true;
        document.getElementById(CustomType + '_SelectSkew').disabled = true;


        document.getElementById(CustomType + '_Slider_TopleftCorner').disabled = true;
        document.getElementById(CustomType + '_Slider_TopRightCorner').disabled = true;
        document.getElementById(CustomType + '_Slider_BottomleftCorner').disabled = true;
        document.getElementById(CustomType + '_Slider_BottomRightCorner').disabled = true;

       
        document.getElementById(CustomType + '_Slider_SameCorner').disabled = true;
        document.getElementById(CustomType + '_checkboxSameCorner').disabled = true;

       
        ViewShow.style.height = ConvertDpToPx(this.diameter) + "px";
        ViewShow.style.width = ConvertDpToPx(this.diameter) + "px";
        ViewShow.style.borderRadius =  "50%";
        ViewShow.style.transform = "skew(" + 0 + "deg)";

        this.ob_stroke.setStrokeWidth(this.type, this.ob_stroke.width);

        if (this.ob_BGcolor.type != "solid")
            this.ob_BGcolor.ob_gradient.setGradiant(CustomType);

    }


    setShapeOval(CustomType) {

        this.type = "oval";

        document.getElementById(CustomType + '_Slider_Width').disabled = false;
        document.getElementById(CustomType + '_Slider_Height').disabled = false;

        document.getElementById(CustomType + '_Slider_Diameter').disabled = true;
        document.getElementById(CustomType + '_Slider_Rib').disabled = true;
        document.getElementById(CustomType + '_SelectSkew').disabled = true;
      
        document.getElementById(CustomType + '_Slider_TopleftCorner').disabled = true;
        document.getElementById(CustomType + '_Slider_TopRightCorner').disabled = true;
        document.getElementById(CustomType + '_Slider_BottomleftCorner').disabled = true;
        document.getElementById(CustomType + '_Slider_BottomRightCorner').disabled = true;

        document.getElementById(CustomType + '_Slider_SameCorner').disabled = true;
        document.getElementById(CustomType + '_checkboxSameCorner').disabled = true;

        ViewShow.style.height = ConvertDpToPx(this.height) + "px";
        ViewShow.style.width = ConvertDpToPx(this.width) + "px";
        ViewShow.style.borderRadius = "50%";
        ViewShow.style.transform = "skew(" + 0 + "deg)";

        this.ob_stroke.setStrokeWidth(this.type, this.ob_stroke.width);

        if (this.ob_BGcolor.type != "solid")
            this.ob_BGcolor.ob_gradient.setGradiant(CustomType);
    }



    setShapeParallelogram(CustomType) {

        this.type = "Parallelogram";

        document.getElementById(CustomType + '_Slider_Width').disabled = true;
        document.getElementById(CustomType + '_Slider_Height').disabled = true;

        document.getElementById(CustomType + '_Slider_Diameter').disabled = true;
        document.getElementById(CustomType + '_Slider_Rib').disabled = false;
        document.getElementById(CustomType + '_SelectSkew').disabled = false;

        document.getElementById(CustomType + '_Slider_TopleftCorner').disabled = true;
        document.getElementById(CustomType + '_Slider_TopRightCorner').disabled = true;
        document.getElementById(CustomType + '_Slider_BottomleftCorner').disabled = true;
        document.getElementById(CustomType + '_Slider_BottomRightCorner').disabled = true;

        document.getElementById(CustomType + '_Slider_SameCorner').disabled = true;
        document.getElementById(CustomType + '_checkboxSameCorner').disabled = true

        ViewShow.style.width = ConvertDpToPx(this.rib) + "px";
        ViewShow.style.height = ConvertDpToPx(this.rib) + "px";
        ViewShow.style.borderRadius = 0 + "px";

        if (this.dir_skew == "left")
            ViewShow.style.transform = "skew(" + 20 + "deg)";
        else
            ViewShow.style.transform = "skew(" + -20 + "deg)";

        this.ob_stroke.setStrokeWidth(this.type, this.ob_stroke.width);
    }


    SetShapeType(select , CustomType) {
        switch (select) {
            case "1": this.setShapeRect(CustomType); break;
            case "2": this.setShapeOval(CustomType); break;
            case "3": this.setShapeCircle(CustomType); break;
            case "4": this.setShapeParallelogram(CustomType); break;
        }
    }

    setSkewLeft() {
        ViewShow.style.transform = "skew(" + 20 + "deg)";
        this.dir_skew = "left";
    }

    setSkewRight() {
        ViewShow.style.transform = "skew(" + -20 + "deg)";
        this.dir_skew = "right";
    }


    SetTypeSkew(select) {

        switch (select) {
            case "1": this.setSkewLeft(); break;
            case "2": this.setSkewRight(); break;
        }
    }


    GenerateCodeSize() {

        var CodeSize = "<size\n";

        if (this.type == "Rect" || this.type == "oval") {
            CodeSize += "android:width=\"" + this.width + "dp\"\n";
            CodeSize += "android:height=\"" + this.height + "dp\"\n";
        }
        else if (this.type == "Parallelogram") {
            CodeSize += "android:width=\"" + this.rib + "dp\"\n";
            CodeSize += "android:height=\"" + this.rib + "dp\"\n";
        } else if (this.type == "Circle") {
            CodeSize += "android:width=\"" + this.diameter + "dp\"\n";
            CodeSize += "android:height=\"" + this.diameter + "dp\"\n";
        }

        CodeSize += "></size>\n";
        return CodeSize;
    }

    GenerateCodePadding() {

        var CodePadding = "<padding\n";

        CodePadding += "android:bottom =\"" + TextViewPaddingBottom.value + "dp\"\n";
        CodePadding += "android:top =\"" + TextViewPaddingTop.value + "dp\"\n";
        CodePadding += "android:left =\"" + TextViewPaddingLeft.value + "dp\"\n";
        CodePadding += "android:right =\"" + TextViewPaddingRight.value + "dp\"\n";
        CodePadding += " ></padding>\n";

        return CodePadding;
    }


    GenerateCodeShape() {

        var CodeShape;

        if (this.type == "Rect") {

            CodeShape = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\n";
            CodeShape += "android:shape=\"rectangle\"\n";
            CodeShape += ">\n";

            CodeShape += this.GenerateCodePadding();
            CodeShape += this.GenerateCodeSize();
            CodeShape += this.ob_stroke.GenerateCodeStroke();
            CodeShape += this.ob_BGcolor.GenerateCodeBGColor();

            CodeShape += this.ob_corners.GenerateCorner();
            CodeShape += "</shape>\n";

        }
        else if (this.type == "Parallelogram") {

            CodeShape = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
            CodeShape += "<layer-list xmlns:android=\"http://schemas.android.com/apk/res/android\" >\n";
            CodeShape += "<item>\n";
            CodeShape += "<rotate\n"

            if (this.dir_skew == "left")
                CodeShape += "android:fromDegrees=\"75\" >\n";
            else
                CodeShape += "android:fromDegrees=\"105\" >\n";


            CodeShape += "<shape\n";
            CodeShape += "android:shape=\"rectangle\"\n";
            CodeShape += ">\n";

            CodeShape += this.GenerateCodePadding();
            CodeShape += this.GenerateCodeSize();
            CodeShape += this.ob_stroke.GenerateCodeStroke();
            CodeShape += this.ob_BGcolor.GenerateCodeBGColor();

            CodeShape += "</shape>\n";

            CodeShape += "</rotate>\n";
            CodeShape += "</item>\n";
            CodeShape += "</layer-list>\n";

        }
        else if (this.type == "oval") {
            CodeShape = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\n";
            CodeShape += "android:shape=\"oval\"\n";
            CodeShape += ">\n";

            CodeShape += this.GenerateCodePadding();
            CodeShape += this.GenerateCodeSize();
            CodeShape += this.ob_stroke.GenerateCodeStroke();
            CodeShape += this.ob_BGcolor.GenerateCodeBGColor();

            CodeShape += "</shape>\n";

        }
        else if (this.type == "Circle") {
            CodeShape = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\n";
            CodeShape += "android:shape=\"oval\"\n";
            CodeShape += ">\n";

            CodeShape += this.GenerateCodePadding();
            CodeShape += this.GenerateCodeSize();
            CodeShape += this.ob_stroke.GenerateCodeStroke();
            CodeShape += this.ob_BGcolor.GenerateCodeBGColor();

            CodeShape += "</shape>\n";
        }

        return CodeShape;
    }

}



