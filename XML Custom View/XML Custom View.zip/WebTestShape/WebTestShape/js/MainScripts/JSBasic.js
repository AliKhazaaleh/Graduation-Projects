﻿function openTab(tabname, nowtab) {
    var i;
    
    var x = document.getElementsByClassName("tab");

    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
        // x[i].style.borderColor = "#49f5e9";
    }

    document.getElementById(tabname).style.display = "block";
    document.getElementById("Basic").style.borderColor = "black";
    document.getElementById("Shape").style.borderColor = "black";
    document.getElementById("Text").style.borderColor = "black";
    document.getElementById("Stroke").style.borderColor = "black";
    document.getElementById("BGColor").style.borderColor = "black";
    document.getElementById("Padding").style.borderColor = "black";

    document.getElementById(nowtab).style.borderColor = "#fff";
}



function SetCodeGenerateButton() {

    document.forms[0].target = '_blank';

    $('#TextCodeView').attr('readonly', 'false');
    $('#TextCodeCustom').attr('readonly', 'false');

  
    document.getElementById("TextCodeView").textContent = myButton.GenerateCodeButton();
    document.getElementById("TextCodeCustom").textContent = myButton.myShape.GenerateCodeShape();

    $('#TextCodeView').attr('readonly', 'true');
    $('#TextCodeCustom').attr('readonly', 'true');
}

         
function SetCodeGenerateTextView() {

    document.forms[0].target = '_blank';

    $('#TextCodeView').attr('readonly', 'false');
    $('#TextCodeCustom').attr('readonly', 'false');

   
    document.getElementById("TextCodeView").textContent = myTextView.GenerateCodeTextView();
    document.getElementById("TextCodeCustom").textContent = myTextView.myShape.GenerateCodeShape();

    $('#TextCodeView').attr('readonly', 'true');
    $('#TextCodeCustom').attr('readonly', 'true');
}

function SetCodeGenerateEditText() {

    document.forms[0].target = '_blank';
    $('#TextCodeView').attr('readonly', 'false');
    $('#TextCodeCustom').attr('readonly', 'false');

   
    document.getElementById("TextCodeView").textContent = myEditText.GenerateCodeEditText();
    document.getElementById("TextCodeCustom").textContent = myEditText.myShape.GenerateCodeShape();

    $('#TextCodeView').attr('readonly', 'true');
    $('#TextCodeCustom').attr('readonly', 'true');
}
         
function SetCodeGenerateRadioButton() {

    document.forms[0].target = '_blank';
    $('#TextCodeView').attr('readonly', 'false');
    $('#TextCodeCustom').attr('readonly', 'false');

  
    document.getElementById("TextCodeView").textContent = myRadioButton.GenerateCodeRadioButton();
    document.getElementById("TextCodeCustom").textContent = myRadioButton.myShape.GenerateCodeShape();

    $('#TextCodeView').attr('readonly', 'true');
    $('#TextCodeCustom').attr('readonly', 'true');
}

         
function SetCodeGenerateCheckBox(){

    document.forms[0].target = '_blank';

    $('#TextCodeView').attr('readonly', 'false');
    $('#TextCodeCustom').attr('readonly', 'false');

   
    document.getElementById("TextCodeView").textContent = myCheckBox.GenerateCodeCheckBox();
    document.getElementById("TextCodeCustom").textContent = myCheckBox.myShape.GenerateCodeShape();

    $('#TextCodeView').attr('readonly', 'true');
    $('#TextCodeCustom').attr('readonly', 'true');
}


function SetCodeGenerateShape() {

    document.forms[0].target = '_blank';
    $('#TextCodeCustom').attr('readonly', 'false');

    document.getElementById("TextCodeCustom").textContent = myButton.myShape.GenerateCodeShape();

    $('#TextCodeCustom').attr('readonly', 'true');
}



// button
var ar_Code_Custom_Button = [
    "<?xml version=\"1.0\" encoding=\"utf-8\"?> \n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\" \nandroid:shape=\"rectangle\" > \n<padding \nandroid:bottom =\"0dp\" \nandroid:top =\"0dp\" \nandroid:left =\"0dp\" \nandroid:right =\"0dp\" ></padding> \n<size \n android:width=\"123dp\" \nandroid:height=\"34dp\" ></size>\n <stroke \nandroid:width=\"2dp\" \nandroid:color=\"#000000\" ></stroke> <solid \nandroid:color=\"#1b5cb1\" >\n</solid> <corners \nandroid:bottomLeftRadius=\"50dp\" \nandroid:bottomRightRadius=\"8dp\" \nandroid:topLeftRadius=\"8dp\" \nandroid:topRightRadius=\"50dp\" >\n</corners> </shape>"
    , "<?xml version=\"1.0\" \nencoding=\"utf-8\"?> \n<layer-list xmlns:android=\"http://schemas.android.com/apk/res/android\" > \n<item> \n<rotate \nandroid:fromDegrees=\"45\" \nandroid:toDegrees=\"50\" \nandroid:pivotX=\"50%\" \nandroid:pivotY=\"50%\" >>\n<shape \nandroid:shape=\"rectangle\" >\n<solid android:color=\"#ff0000\" />\n<size android:width=\"105dp\" \nandroid:height=\"105dp\">\n</size>\n</shape>\n</rotate>\n</item>\n</layer-list>"
    , "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\nandroid:shape=\"rectangle\"><paddingandroid:bottom =\"0dp\"\nandroid:top =\"0dp\"\nandroid:left =\"0dp\" \nandroid:right =\"0dp\"></padding>\n<size \nandroid:width=\"108dp\"\nandroid:height=\"48dp\"></size><stroke \nandroid:width=\"3dp\"\nandroid:color=\"#d2d200\">\n</stroke><solid \nandroid:color=\"#00003c\"></solid>\n<corners \nandroid:radius=\"50dp\"></corners></shape>"
    , "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<layer-list xmlns:android=\"http://schemas.android.com/apk/res/android\" ><item  \nandroid:width=\"100dp\" android:height=\"100dp\" \nandroid:gravity=\"center\">\n<shape \nandroid:shape=\"oval\" ><solid \nandroid:color=\"#393E41\" />\n<stroke \nandroid:width=\"2dp\" ></stroke></shape> </item><item \nandroid:width=\"75dp\" \nandroid:height=\"75dp\"\n android:gravity=\"center\"><shape \nandroid:shape=\"oval\" >\n<solid  \n android:color=\"#E94F37\" /><stroke\n android:width=\"2dp\" ></stroke>\n</shape>\n </item><item \nandroid:width=\"70dp\" \nandroid:height=\"40dp\" \nandroid:gravity=\"center\"><shape  \nandroid:shape=\"oval\" ><solid \n android:color=\"#F6F7EB\" /><stroke\n android:width=\"2dp\" >\n</stroke></shape></item></layer-list>"

];
var ar_Code_View_Button = [
    "<Button android:layout_width=\"wrap_content\" \nandroid:layout_height=\"wrap_content\" \nandroid:id=\"@+id/Button_login\" \nandroid:text=\"Login\" \nandroid:textColor=\"#000000\"\n android:textSize=\"10sp\"\n android:fontFamily=\"sans-serif\" \nandroid:textAllCaps=\"false\" \nandroid:gravity=\"center\" \nandroid:alpha=\"1.0\" \nandroid:enable=\"true\" \nandroid:shadowColor=\"#000000\" \nandroid:shadowDx=\"0\" android:shadowDy=\"0\"\n android:shadowRadius=\"0\"\n android:paddingLeft=\"0dp\" \nandroid:paddingRight=\"0dp\" \nandroid:paddingTop=\"0dp\"\n android:paddingBottom=\"0dp\" \nandroid:background=\"@drawable/Write Name File ???\" />"
    , "<Button \nandroid:layout_width=\"wrap_content\" \nandroid:layout_height=\"wrap_content\" \nandroid:id=\"@+id/Button_Stop\" \nandroid:text=\"Stop\" \nandroid:textColor=\"#000000\" \nandroid:textSize=\"16sp\" \nandroid:textStyle=\"bold|italic\" \nandroid:background=\"@drawable/Write Name File ???\"/>"
  , "<Button android:layout_width=\"wrap_content\"\nandroid:layout_height=\"wrap_content\ \nandroid:id=\"@+id/View_00\ \nandroid:text=\"GO!\"\nandroid:textColor=\"#cccc00\"android:textSize=\"20sp\"\nandroid:textStyle=\"bold\"\nandroid:fontFamily=\"sans-serif\"\nandroid:textAllCaps=\"false\"\nandroid:gravity=\"center\"\nandroid:alpha=\"1.0\"\nandroid:enabled=\"true\"\nandroid:shadowColor=\"#000000\"\nandroid:shadowDx=\"0\"\nandroid:shadowDy=\"0\"\nandroid:shadowRadius=\"0\"\nandroid:paddingLeft=\"0dp\"\nandroid:paddingRight=\"0dp\"\nandroid:paddingTop=\"0dp\"\nandroid:paddingBottom=\"0dp\"\nandroid:background=\"@drawable/Write Name File ???\"/>"
    , "<Buttonandroid:layout_width=\"wrap_content\"\nandroid:layout_height=\"wrap_content\" \nandroid:text=\"GO\" \nandroid:id=\"@+id/buttonGO\" \nandroid:textSize=\"20sp\"\nandroid:background=\"@drawable/Write Name File ???\"/>"


];
// TextView
var ar_Code_Custom_TextView = [
    "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n <shape xmlns:android=\"http://schemas.android.com/apk/res/android\" \nandroid:shape=\"oval\" >\n <padding \nandroid:bottom =\"10dp\" \nandroid:top =\"0dp\" \nandroid:left =\"0dp\"\n android:right =\"0dp\" >\n</padding> <size\n android:width=\"102dp\"\n android:height=\"57dp\" ></size> <stroke \nandroid:width=\"0dp\" \nandroid:color=\"#000000\" ></stroke> <gradient \nandroid:type=\"radial\" \nandroid:centerX=\"50%\"\n android:centerY=\"49%\" \nandroid:gradientRadius=\"34dp\" \nandroid:startColor=\"#bdabbe\"\n android:centerColor=\"#3fda4a\"\n android:endColor=\"#0e2b04\" >\n</gradient> </shape> "
    , "<?xml version=\"1.0\" encoding=\"utf-8\"?> \n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\" \nandroid:shape=\"oval\" > \n<padding \nandroid:bottom =\"0dp\" \nandroid:top =\"0dp\" \nandroid:left =\"0dp\" \nandroid:right =\"0dp\" ></padding> <size \nandroid:width=\"70dp\" \nandroid:height=\"70dp\" ></size> <stroke \nandroid:width=\"3dp\" \nandroid:color=\"#d174c4\" ></stroke> <solid \nandroid:color=\"#5770e3\" >\n</solid> </shape>"
    , "<?xml version=\"1.0\" encoding=\"utf-8\"?> \n<layer-list xmlns:android=\"http://schemas.android.com/apk/res/android\" >\n <item> <rotate \nandroid:fromDegrees=\"105\" > <shape \nandroid:shape=\"rectangle\" > <padding \nandroid:bottom =\"0dp\" \nandroid:top =\"0dp\"\n android:left =\"0dp\"\n android:right =\"0dp\" ></padding> <size \nandroid:width=\"68dp\" \nandroid:height=\"68dp\" ></size> <stroke \nandroid:width=\"3dp\" \nandroid:color=\"#000000\"\n android:dashWidth=\"5dp\" \nandroid:dashGap=\"2dp\" ></stroke> <gradient\n android:type=\"linear\"\n android:angle=\"315\"\n android:centerX=\"0%\" \nandroid:centerY=\"50%\"\n android:startColor=\"#ffffbf\"\n android:centerColor=\"#ffe66a\"\n android:endColor=\"#6f6f00\" ></gradient>\n </shape> </rotate> </item> </layer-list>"
];

var ar_Code_View_TextView = [
    "<TextView android:layout_width=\"wrap_content\" \nandroid:layout_height=\"wrap_content\"\n android:id=\"@+id/View_00\"\n android:text=\"TextView\" \nandroid:textColor=\"#000000\"\n android:textSize=\"15sp\" \nandroid:textStyle=\"bold|italic\" \nandroid:fontFamily=\"serif\"\n android:textAllCaps=\"false\"\n android:gravity=\"center\" android:alpha=\"1.0\"\n android:enable=\"true\"\n android:shadowColor=\"#7d5573\"\n android:shadowDx=\"-2\" \nandroid:shadowDy=\"11\"\n android:shadowRadius=\"7\" \nandroid:paddingLeft=\"0dp\" \nandroid:paddingRight=\"0dp\" \nandroid:paddingTop=\"0dp\"\n android:paddingBottom=\"10dp\"\n android:background=\"@drawable/Write Name File ???\" />"
      , "<TextView android:layout_width=\"wrap_content\"\n android:layout_height=\"wrap_content\" \nandroid:id=\"@+id/View_00\"\n android:text=\"Text\"\n android:textColor=\"#7d1780\"\n android:textSize=\"20sp\"\n android:fontFamily=\"cursive\"\n android:textAllCaps=\"false\" \nandroid:gravity=\"center\"\n android:alpha=\"1.0\" android:enabled=\"true\"\n android:shadowColor=\"#d69ad5\"\n android:shadowDx=\"1\" \nandroid:shadowDy=\"4\"\n android:shadowRadius=\"4\" \nandroid:paddingLeft=\"0dp\"\n android:paddingRight=\"0dp\" \nandroid:paddingTop=\"0dp\" \nandroid:paddingBottom=\"0dp\" \nandroid:background=\"@drawable/Write Name File ???\" />"
      , "<TextView android:layout_width=\"wrap_content\" \nandroid:layout_height=\"wrap_content\" \nandroid:id=\"@+id/View_00\"\n android:text=\"Enter\"\n android:textColor=\"#000000\" \nandroid:textSize=\"16sp\"\n android:textStyle=\"bold\"\n android:fontFamily=\"monospace\"\n android:textAllCaps=\"true\" \nandroid:gravity=\"center\" android:alpha=\"1.0\"\n android:enable=\"true\"\n android:shadowColor=\"#292f36\"\n android:shadowDx=\"0\"\n android:shadowDy=\"0\" \nandroid:shadowRadius=\"2\"\n android:paddingLeft=\"0dp\"\n android:paddingRight=\"0dp\" \nandroid:paddingTop=\"0dp\"\n android:paddingBottom=\"0dp\" \nandroid:background=\"@drawable/Write Name File ???\" />"
];
//EditText
var ar_Code_Custom_EditText = [
      "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\nandroid:shape=\"rectangle\"><padding \nandroid:bottom =\"7dp\"\nandroid:top =\"0dp\"\nandroid:left =\"0dp\"\nandroid:right =\"7dp\" ></padding><sizeandroid:width=\"105dp\"\nandroid:height=\"40dp\"></size><strokeandroid:width=\"1dp\"\nandroid:color=\"#2299d2\"></stroke><solid \nandroid:color=\"#88c085\"></solid><corners \nandroid:radius=\"9dp\"></corners></shape>"
      , "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\nandroid:shape=\"oval\"><padding  \nandroid:bottom =\"0dp\"\nandroid:top =\"0dp\"\nandroid:left =\"8dp\"\nandroid:right =\"0dp\" ></padding><sizeandroid:width=\"114dp\"\nandroid:height=\"55dp\"></size><strokeandroid:width=\"4dp\"\nandroid:color=\"#8ac6c2\"android:dashWidth=\"8dp\"\nandroid:dashGap=\"4dp\"></stroke><solid \nandroid:color=\"#1d22f5\"></solid></shape>"
      , "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\nandroid:shape=\"rectangle\"><padding \nandroid:bottom =\"3dp\"\nandroid:top =\"0dp\"\nandroid:left =\"0dp\"\nandroid:right =\"0dp\" ></padding><sizeandroid:width=\"132dp\"\nandroid:height=\"38dp\"></size><strokeandroid:width=\"1dp\"\nandroid:color=\"#000040\"></stroke><solid \nandroid:color=\"#c1b90d\"></solid><corners \nandroid:radius=\"6dp\"></corners></shape>"
];
var ar_Code_View_EditText = [
       "<EditText android:layout_width=\"wrap_content\"\n android:layout_height=\"wrap_content\"\nandroid:id=\"@+id/View_00\" \nandroid:textSize=\"10sp\" \nandroid:hint=\"Type message..\" \nandroid:textColor=\"#453ded\"\nandroid:inputType=\"text\"\nandroid:selectAllOnFocus=\"false\"\nandroid:maxLength=\"40\"\nandroid:fontFamily=\"sans-serif-condensed\"\nandroid:textAllCaps=\"false\"\nandroid:gravity=\"center\"\nandroid:alpha=\"1.0\"\nandroid:enabled=\"true\"\nandroid:shadowColor=\"#292f36\"\nandroid:shadowDx=\"0\"\nandroid:shadowDy=\"0\"android:shadowRadius=\"0\"\nandroid:paddingLeft=\"0dp\"android:paddingRight=\"7dp\"\nandroid:paddingTop=\"0dp\"\nandroid:paddingBottom=\"7dp\"\nandroid:background=\"@drawable/Write Name File ???\"/>"
       , "<EditText android:layout_width=\"wrap_content\" \nandroid:layout_height=\"wrap_content\" \nandroid:id=\"@+id/View_00\" \nandroid:textSize=\"11sp\" \nandroid:hint=\"Insert Number..\" \nandroid:textColor=\"#ffffff\"\nandroid:inputType=\"number\"\nandroid:selectAllOnFocus=\"true\"\nandroid:maxLength=\"14\"\nandroid:textStyle=\"italic\"\nandroid:fontFamily=\"sans-serif-condensed\"\nandroid:textAllCaps=\"false\"\nandroid:gravity=\"center\"android:alpha=\"1.0\"android:enabled=\"true\"\nandroid:shadowColor=\"#79bbb9\"\nandroid:shadowDx=\"1\"\nandroid:shadowDy=\"0\"\nandroid:shadowRadius=\"0\"android:paddingLeft=\"8dp\"\nandroid:paddingRight=\"0dp\"\nandroid:paddingTop=\"0dp\"\nandroid:paddingBottom=\"0dp\"\nandroid:background=\"@drawable/Write Name File ???\"/>"
       , "<EditText android:layout_width=\"wrap_content\" \nandroid:layout_height=\"wrap_content\" \nandroid:id=\"@+id/View_00\"\nandroid:textSize=\"13sp\" \nandroid:hint=\"Password..\" \nandroid:textColor=\"#000000\" \nandroid:inputType=\"text\"\nandroid:selectAllOnFocus=\"false\"\nandroid:maxLength=\"10\"\nandroid:fontFamily=\"sans-serif-condensed\"\nandroid:textAllCaps=\"false\"\nandroid:gravity=\"center\"\nandroid:alpha=\"1.0\"android:enabled=\"true\"\nandroid:shadowColor=\"#0a0b0c\"\nandroid:shadowDx=\"0\"\nandroid:shadowDy=\"0\"android:shadowRadius=\"0\"\nandroid:paddingLeft=\"0dp\"android:paddingRight=\"0dp\"\nandroid:paddingTop=\"0dp\"\nandroid:paddingBottom=\"3dp\"\nandroid:background=\"@drawable/Write Name File ???\"/>"

];
//RadioButton
var ar_Code_Custom_RadioButton = [
     "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<layer-list xmlns:android=\"http://schemas.android.com/apk/res/android\" ><item  \nandroid:gravity=\"center\"><shape  \nandroid:shape=\"oval\" ><solid\n android:color=\"#FF0000\" /><stroke \nandroid:width=\"2dp\" \nandroid:color=\"#7acfd6\" ></stroke><size \nandroid:width=\"180dp\"\nandroid:height=\"70dp\">\n</size><corners \nandroid:bottomLeftRadius=\"30dp\" \nandroid:topRightRadius=\"30dp\"></corners></shape></item><item \nandroid:top=\"40dp\" \nandroid:right=\"15dp\" \nandroid:width=\"100dp\" \nandroid:height=\"50dp\" \nandroid:gravity=\"center\"><shape\n android:shape=\"line\"><stroke\n android:width=\"3dp\" \nandroid:color=\"#7acfd6\"\n android:dashWidth=\"3dp\"\n android:dashGap=\"3dp\"  >\n</stroke> </shape> \n</item> <item\n android:bottom=\"40dp\" \nandroid:right=\"15dp\" \n  android:width=\"100dp\" \nandroid:height=\"50dp\" \nandroid:gravity=\"center\"><shape\n android:shape=\"line\"  > <stroke\n android:width=\"3dp\" \nandroid:color=\"#7acfd6\" \nandroid:dashWidth=\"3dp\" \nandroid:dashGap=\"3dp\"  ></stroke></shape></e></layer-list>"
     , "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\nandroid:shape=\"oval\"><padding \nandroid:bottom =\"0dp\"\nandroid:top =\"0dp\"\nandroid:left =\"0dp\"\nandroid:right =\"0dp\" ></padding><size \nandroid:width=\"105dp\"\nandroid:height=\"40dp\"></size><stroke \nandroid:width=\"2dp\"\nandroid:color=\"#ffffff\"\nandroid:dashWidth=\"4dp\" \nandroid:dashGap=\"2dp\"></stroke><gradient \nandroid:type=\"linear\"\nandroid:angle=\"45\"\nandroid:centerX=\"75%\"\nandroid:centerY=\"50%\"\nandroid:startColor=\"#61a7a4\"\nandroid:centerColor=\"#a0cbca\"\nandroid:endColor=\"#233c3d\">\n</gradient>\n</shape>"
     , "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\nandroid:shape=\"rectangle\"><padding \nandroid:bottom =\"0dp\"android:top =\"0dp\"\nandroid:left =\"0dp\"\nandroid:right =\"0dp\" ></padding><size \nandroid:width=\"105dp\"\nandroid:height=\"40dp\"></size><stroke \nandroid:width=\"0dp\"\nandroid:color=\"#000000\"></stroke><solid \nandroid:color=\"#4f64ac\"></solid><corners \nandroid:radius=\"6dp\">\n</corners>\n</shape>"
];
var ar_Code_View_RadioButton = [
     "<RadioButton android:layout_width=\"wrap_content\"\nandroid:layout_height=\"wrap_content\"\nandroid:text=\"OPTION 1\"\nandroid:textColor=\"#000000\"\nandroid:id=\"@+id/RadiobuttonOP1\"\nandroid:textSize=\"16sp\"\nandroid:textStyle=\"bold\"\nandroid:background=\"@drawable/Write Name File ???\" />"
     , "<RadioButton android:layout_width=\"wrap_content\"\nandroid:layout_height=\"wrap_content\"\nandroid:id=\"@+id/View_00\"\nandroid:text=\"YES\"\nandroid:textColor=\"#000000\"\nandroid:textSize=\"13sp\"\nandroid:fontFamily=\"serif\"\nandroid:textAllCaps=\"false\"\nandroid:gravity=\"center\"\nandroid:alpha=\"1.0\"\nandroid:enabled=\"true\"\nandroid:checked=\"false\"\nandroid:shadowColor=\"#000000\"\nandroid:shadowDx=\"0\"android:shadowDy=\"0\"\nandroid:shadowRadius=\"0\"\nandroid:paddingLeft=\"0dp\"\nandroid:paddingRight=\"0dp\"\nandroid:paddingTop=\"0dp\"\nandroid:paddingBottom=\"0dp\"\nandroid:background=\"@drawable/Write Name File ???\"/>"
     , "<RadioButtonandroid:layout_width=\"wrap_content\"\nandroid:layout_height=\"wrap_content\"\nandroid:id=\"@+id/View_00\"\nandroid:text=\"Good\"\nandroid:textColor=\"#d3d3d3\"\nandroid:textSize=\"15sp\"\nandroid:textStyle=\"bold|italic\"\nandroid:fontFamily=\"sans-serif-condensed\"\nandroid:textAllCaps=\"false\"\nandroid:gravity=\"center\"\nandroid:alpha=\"1.0\"\nandroid:enabled=\"true\"\nandroid:checked=\"false\"\nandroid:shadowColor=\"#000000\"\nandroid:shadowDx=\"0\"\nandroid:shadowDy=\"0\"\nandroid:shadowRadius=\"0\"\nandroid:paddingLeft=\"0dp\"\nandroid:paddingRight=\"0dp\"\nandroid:paddingTop=\"0dp\"\nandroid:paddingBottom=\"0dp\"\nandroid:background=\"@drawable/Write Name File ???\"/>"
];
//CheckBox
var ar_Code_Custom_CheckBox = [
     "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<layer-list xmlns:android=\"http://schemas.android.com/apk/res/android\" ><item><rotate \nandroid:fromDegrees=\"75\" ><shape \nandroid:shape=\"rectangle\"><padding \nandroid:bottom =\"0dp\"android:top =\"0dp\"android:left =\"0dp\"\nandroid:right =\"0dp\" >\n</padding><size \nandroid:width=\"59dp\"android:height=\"59dp\">\n</size><stroke \nandroid:width=\"2dp\"android:color=\"#80ff80\"\nandroid:dashWidth=\"4dp\"\nandroid:dashGap=\"2dp\">\n</stroke><solidandroid:color=\"#175e13\">\n</solid></shape>\n</rotate>\n</item>\n</layer-list>"
     , "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\nandroid:shape=\"rectangle\"><padding \nandroid:bottom =\"0dp\"\nandroid:top =\"0dp\"\nandroid:left =\"0dp\"\nandroid:right =\"0dp\" >\n</padding>\n<size \nandroid:width=\"71dp\"\nandroid:height=\"40dp\">\n</size>\n<strokeandroid:width=\"2dp\"android:color=\"#0b039a\"\nandroid:dashWidth=\"4dp\"\nandroid:dashGap=\"2dp\"></stroke><gradient \nandroid:type=\"radial\"\nandroid:centerX=\"50%\"\nandroid:centerY=\"49%\"\nandroid:gradientRadius=\"41dp\"\nandroid:startColor=\"#6d9fc9\"\nandroid:centerColor=\"#bae6ed\"\nandroid:endColor=\"#ffffff\">\n</gradient><corners \nandroid:radius=\"0dp\">\n</corners>\n</shape>"
     , "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\nandroid:shape=\"oval\"><padding \nandroid:bottom =\"0dp\"\nandroid:top =\"0dp\"\nandroid:left =\"0dp\"\nandroid:right =\"0dp\" >\n</padding><size \nandroid:width=\"70dp\"\nandroid:height=\"70dp\">\n</size><stroke \nandroid:width=\"1dp\"\nandroid:color=\"#fefbfa\" \nandroid:dashWidth=\"2dp\"\nandroid:dashGap=\"1dp\">\n</stroke><gradient \nandroid:type=\"linear\"\nandroid:angle=\"0\"\nandroid:centerX=\"50%\"\nandroid:centerY=\"50%\"\nandroid:startColor=\"#ffbbbb\"\nandroid:centerColor=\"#ff2424\"\nandroid:endColor=\"#460000\">\n</gradient>\n</shape>"
];
var ar_Code_View_CheckBox = [
     "<CheckBox android:layout_width=\"wrap_content\"\nandroid:layout_height=\"wrap_content\"\nandroid:id=\"@+id/View_00\"\nandroid:text=\"Check\"\nandroid:textColor=\"#ffffff\"\nandroid:textSize=\"12sp\"\nandroid:textStyle=\"bold|italic\"\nandroid:fontFamily=\"casual\"\nandroid:textAllCaps=\"false\"\nandroid:gravity=\"center\"\nandroid:alpha=\"1.0\"\nandroid:enabled=\"true\"\nandroid:checked=\"false\"\nandroid:shadowColor=\"#000000\"\nandroid:shadowDx=\"0\"\nandroid:shadowDy=\"0\"\nandroid:shadowRadius=\"0\"\nandroid:paddingLeft=\"0dp\"\nandroid:paddingRight=\"0dp\"\nandroid:paddingTop=\"0dp\"\nandroid:paddingBottom=\"0dp\"\nandroid:background=\"@drawable/Write Name File ???\"/>"
     , "<CheckBox android:layout_width=\"wrap_content\"\nandroid:layout_height=\"wrap_content\"\nandroid:id=\"@+id/View_00\"\nandroid:text=\"Enable\"\nandroid:textColor=\"#3d30d6\"\nandroid:textSize=\"11sp\"\nandroid:fontFamily=\"sans-serif-condensed\"\nandroid:textAllCaps=\"false\"\nandroid:gravity=\"center\"\nandroid:alpha=\"1.0\"android:enabled=\"true\"\nandroid:checked=\"false\"\nandroid:shadowColor=\"#292f36\"\nandroid:shadowDx=\"0\"android:shadowDy=\"0\"\nandroid:shadowRadius=\"1\"\nandroid:paddingLeft=\"0dp\"\nandroid:paddingRight=\"0dp\"\nandroid:paddingTop=\"0dp\"\nandroid:paddingBottom=\"0dp\"\nandroid:background=\"@drawable/Write Name File ???\"/>"
     , "<CheckBoxandroid:layout_width=\"wrap_content\"\nandroid:layout_height=\"wrap_content\"\nandroid:id=\"@+id/View_00\"\nandroid:text=\"CheckBox\"\nandroid:textColor=\"#ffffff\"\nandroid:textSize=\"10sp\"\nandroid:textStyle=\"bold|italic\"\nandroid:fontFamily=\"sans-serif-condensed\"\nandroid:textAllCaps=\"false\"\nandroid:gravity=\"center\"\nandroid:alpha=\"1.0\"\nandroid:enabled=\"true\"\nandroid:checked=\"false\"\nandroid:shadowColor=\"#000000\"\nandroid:shadowDx=\"0\"\nandroid:shadowDy=\"0\"\nandroid:shadowRadius=\"0\"\nandroid:paddingLeft=\"0dp\"\nandroid:paddingRight=\"0dp\"\nandroid:paddingTop=\"0dp\"\nandroid:paddingBottom=\"0dp\"\nandroid:background=\"@drawable/Write Name File ???\"/>"
];
//Shape
var ar_Code_Custom_Shape = [
     "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\nandroid:shape=\"rectangle\">\n<padding \nandroid:bottom =\"0dp\"\nandroid:top =\"0dp\"\nandroid:left =\"0dp\"\nandroid:right =\"0dp\" >\n</padding><size \nandroid:width=\"82dp\"\nandroid:height=\"80dp\"></size><stroke \nandroid:width=\"1dp\"\nandroid:color=\"#d2d2ff\"></stroke>\n<gradientandroid:type=\"linear\"\nandroid:angle=\"0\"\nandroid:centerX=\"50%\"android:centerY=\"50%\"\nandroid:startColor=\"#e8e8ff\"\nandroid:centerColor=\"#aeaeff\"\nandroid:endColor=\"#000080\">\n</gradient>\n<corners \nandroid:radius=\"0dp\">\n</corners>\n</shape>"
     , "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\nandroid:shape=\"oval\">\n<padding \nandroid:bottom =\"0dp\"\nandroid:top =\"0dp\"\nandroid:left =\"0dp\"\nandroid:right =\"0dp\" >\n</padding><size \nandroid:width=\"70dp\" \nandroid:height=\"70dp\"></size><stroke \nandroid:width=\"1dp\"\nandroid:color=\"#000000\"></stroke>\n<gradientandroid:type=\"linear\"\nandroid:angle=\"135\"\nandroid:centerX=\"50%\"android:centerY=\"50%\"\nandroid:startColor=\"#313131\"\nandroid:centerColor=\"#ffeb8a\"\nandroid:endColor=\"#333a44\">\n</gradient>\n</shape>"

];
var ar_Code_View_Shape = [
   "\n", "\n"
];
function SetCodeTemp(TypeView, Num) {

    $('#TextCodeViewTemp').attr('readonly', 'false');
    $('#TextCodeCustomTemp').attr('readonly', 'false');

    if (TypeView == "Button") {
         document.getElementById("TextCodeViewTemp").textContent = ar_Code_View_Button[Num];
         document.getElementById("TextCodeCustomTemp").textContent = ar_Code_Custom_Button[Num];
    }
    if (TypeView == "TextView") {

        document.getElementById("TextCodeViewTemp").textContent = ar_Code_View_TextView[Num];
        document.getElementById("TextCodeCustomTemp").textContent = ar_Code_Custom_TextView[Num];
    }
    if (TypeView == "EditText") {

        document.getElementById("TextCodeViewTemp").textContent = ar_Code_View_EditText[Num];
        document.getElementById("TextCodeCustomTemp").textContent = ar_Code_Custom_EditText[Num];
    }
    if (TypeView == "RadioButton") {

        document.getElementById("TextCodeViewTemp").textContent = ar_Code_View_RadioButton[Num];
        document.getElementById("TextCodeCustomTemp").textContent = ar_Code_Custom_RadioButton[Num];
    }
    if (TypeView == "CheckBox") {

        document.getElementById("TextCodeViewTemp").textContent = ar_Code_View_CheckBox[Num];
        document.getElementById("TextCodeCustomTemp").textContent = ar_Code_Custom_CheckBox[Num];
    }
    if (TypeView == "Shape") {
        document.getElementById("TextCodeViewTemp").textContent = "Code Custom Only";
        document.getElementById("TextCodeCustomTemp").textContent = ar_Code_Custom_Shape[Num];

    }

    $('#TextCodeViewTemp').attr('readonly', 'true');
    $('#TextCodeCustomTemp').attr('readonly', 'true');
}

var screenDP = 3;

function setldpi(CustomType) {
    screenDP = 1;
    var object;

    switch (CustomType) {
        case 'Button': object = myButton; break;
        case 'TextView': object = myTextView; break;
        case 'RadioButton': object = myRadioButton; break;
        case 'CheckBox': object = myCheckBox; break;
        case 'Shape': object = myButton; break;
        case 'EditText': object = myEditText; break;

    }

    if (object.myShape.type == "Rect") {

        ViewShow.style.height = ConvertDpToPx(document.getElementById(CustomType + '_Slider_Height').value) + "px";
        ViewShow.style.width = ConvertDpToPx(document.getElementById(CustomType + '_Slider_Width').value) + "px";

        if (document.getElementById(CustomType + '_checkboxSameCorner').checked == true)
            object.myShape.ob_corners.setSameCorner(object.myShape.ob_corners.same);
        else {
            object.myShape.ob_corners.setCorTopLeft(object.myShape.ob_corners.top_left);
            object.myShape.ob_corners.setCorTopRight(object.myShape.ob_corners.top_right);
            object.myShape.ob_corners.setCorBottomLeft(object.myShape.ob_corners.bottom_left);
            object.myShape.ob_corners.setCorBottomRight(object.myShape.ob_corners.bottom_right);
        }

    } else if (object.myShape.type == "Circle") {
        object.myShape.setShapeCircle(CustomType);
    } else if (object.myShape.type == "oval") {
        object.myShape.setShapeOval(CustomType);
    } else if (object.myShape.type == "Parallelogram") {
        object.myShape.setShapeParallelogram(CustomType);
    }



    if (object.myShape.ob_BGcolor.type != "solid")
        object.myShape.ob_BGcolor.ob_gradient.setGradiant(CustomType);

    ViewShow.style.borderWidth = ConvertDpToPx(object.myShape.ob_stroke.width) + "px";


    object.setTextSize(object.text_size);
    object.setPaddingTop(object.padding_top);
    object.setPaddingBottom(object.padding_bottom);
    object.setPaddingLeft(object.padding_left);
    object.setPaddingRight(object.padding_right);


}


function setmdpi( CustomType) {
    screenDP = 2;

    var object;

    switch (CustomType) {
        case 'Button': object = myButton; break;
        case 'TextView': object = myTextView; break;
        case 'RadioButton': object = myRadioButton; break;
        case 'CheckBox': object = myCheckBox; break;
        case 'Shape': object = myButton; break;
        case 'EditText': object = myEditText; break;


    }


    if (object.myShape.type == "Rect") {

        ViewShow.style.height = ConvertDpToPx(document.getElementById(CustomType + '_Slider_Height').value) + "px";
        ViewShow.style.width = ConvertDpToPx(document.getElementById(CustomType + '_Slider_Width').value) + "px";

        if (document.getElementById(CustomType + '_checkboxSameCorner').checked == true)
            object.myShape.ob_corners.setSameCorner(object.myShape.ob_corners.same);
        else {
            object.myShape.ob_corners.setCorTopLeft(object.myShape.ob_corners.top_left);
            object.myShape.ob_corners.setCorTopRight(object.myShape.ob_corners.top_right);
            object.myShape.ob_corners.setCorBottomLeft(object.myShape.ob_corners.bottom_left);
            object.myShape.ob_corners.setCorBottomRight(object.myShape.ob_corners.bottom_right);
        }

    } else if (object.myShape.type == "Circle") {
        object.myShape.setShapeCircle(CustomType);
    } else if (object.myShape.type == "oval") {
        object.myShape.setShapeOval(CustomType);
    } else if (object.myShape.type == "Parallelogram") {
        object.myShape.setShapeParallelogram(CustomType);
    }

    if (object.myShape.ob_BGcolor.type != "solid")
        object.myShape.ob_BGcolor.ob_gradient.setGradiant(CustomType);

    ViewShow.style.borderWidth = ConvertDpToPx(object.myShape.ob_stroke.width) + "px";

    object.setTextSize(object.text_size);
    object.setPaddingTop(object.padding_top);
    object.setPaddingBottom(object.padding_bottom);
    object.setPaddingLeft(object.padding_left);
    object.setPaddingRight(object.padding_right);

}



function sethdpi( CustomType) {
    screenDP = 3;
    var object;

    switch (CustomType) {
        case 'Button': object = myButton; break;
        case 'TextView': object = myTextView; break;
        case 'RadioButton': object = myRadioButton; break;
        case 'CheckBox': object = myCheckBox; break;
        case 'Shape': object = myButton; break;
        case 'EditText': object = myEditText; break;

    }



    if (object.myShape.type == "Rect") {

        ViewShow.style.height = ConvertDpToPx(document.getElementById(CustomType + '_Slider_Height').value) + "px";
        ViewShow.style.width = ConvertDpToPx(document.getElementById(CustomType + '_Slider_Width').value) + "px";

        if (document.getElementById(CustomType + '_checkboxSameCorner').checked == true)
            object.myShape.ob_corners.setSameCorner(object.myShape.ob_corners.same);
        else {
            object.myShape.ob_corners.setCorTopLeft(object.myShape.ob_corners.top_left);
            object.myShape.ob_corners.setCorTopRight(object.myShape.ob_corners.top_right);
            object.myShape.ob_corners.setCorBottomLeft(object.myShape.ob_corners.bottom_left);
            object.myShape.ob_corners.setCorBottomRight(object.myShape.ob_corners.bottom_right);
        }

    } else if (object.myShape.type == "Circle") {
        object.myShape.setShapeCircle(CustomType);
    } else if (object.myShape.type == "oval") {
        object.myShape.setShapeOval(CustomType);
    } else if (object.myShape.type == "Parallelogram") {
        object.myShape.setShapeParallelogram(CustomType);
    }



    if (object.myShape.ob_BGcolor.type != "solid")
        object.myShape.ob_BGcolor.ob_gradient.setGradiant(CustomType);

    
    ViewShow.style.borderWidth = ConvertDpToPx(object.myShape.ob_stroke.width) + "px";
    object.setTextSize(object.text_size);
    object.setPaddingTop(object.padding_top);
    object.setPaddingBottom(object.padding_bottom);
    object.setPaddingLeft(object.padding_left);
    object.setPaddingRight(object.padding_right);


}

function setxhdpi(CustomType) {
    screenDP = 4;

    var object;

    switch (CustomType) {
        case 'Button': object = myButton; break;
        case 'TextView': object = myTextView; break;
        case 'RadioButton': object = myRadioButton; break;
        case 'CheckBox': object = myCheckBox; break;
        case 'Shape': object = myButton; break;
        case 'EditText': object = myEditText; break;


    }

    if (object.myShape.type == "Rect") {

        ViewShow.style.height = ConvertDpToPx(document.getElementById(CustomType + '_Slider_Height').value) + "px";
        ViewShow.style.width = ConvertDpToPx(document.getElementById(CustomType + '_Slider_Width').value) + "px";

        if (document.getElementById(CustomType + '_checkboxSameCorner').checked == true)
            object.myShape.ob_corners.setSameCorner(object.myShape.ob_corners.same);
        else {
            object.myShape.ob_corners.setCorTopLeft(object.myShape.ob_corners.top_left);
            object.myShape.ob_corners.setCorTopRight(object.myShape.ob_corners.top_right);
            object.myShape.ob_corners.setCorBottomLeft(object.myShape.ob_corners.bottom_left);
            object.myShape.ob_corners.setCorBottomRight(object.myShape.ob_corners.bottom_right);
        }

    } else if (object.myShape.type == "Circle") {
        object.myShape.setShapeCircle(CustomType);
    } else if (object.myShape.type == "oval") {
        object.myShape.setShapeOval(CustomType);
    } else if (object.myShape.type == "Parallelogram") {
        object.myShape.setShapeParallelogram(CustomType);
    }



    if (object.myShape.ob_BGcolor.type != "solid")
        object.myShape.ob_BGcolor.ob_gradient.setGradiant(CustomType);

    ViewShow.style.borderWidth = ConvertDpToPx(object.myShape.ob_stroke.width) + "px";
    object.setTextSize(object.text_size);
    object.setPaddingTop(object.padding_top);
    object.setPaddingBottom(object.padding_bottom);
    object.setPaddingLeft(object.padding_left);
    object.setPaddingRight(object.padding_right);

}

/*
function setxxhdpi() {
    screenDP = 5;

    setTextSize();

    setPaddingTop();
    setPaddingBottom();
    setPaddingLeft();
    setPaddingRight();
    Button_View.style.borderWidth = ConvertDpToPx(Slider_StrokeWidth.value) + "px";

    if (BGColor != "solid")
        setGradiant();

    if (shape == "Rect") {

        Button_View.style.height = ConvertDpToPx(Slider_Height.value) + "px";
        Button_View.style.width = ConvertDpToPx(Slider_Width.value) + "px";

        if (checkboxSameCorner.checked == true)
            setSameCorner();
        else {
            setCorTopLeft();
            setCorTopRight();
            setCorBottomLeft();
            setCorBottomRight();
        }

    } else if (shape == "Circle") {
        setShapeCircle();

    } else if (shape == "oval") {
        setShapeOval();
    } else if (shape == "Parallelogram") {
        setShapeParallelogram();
    }
}

*/

function SetDPType(select, CustomType) {

    switch (select) {
        case "1": setldpi( CustomType); break;
        case "2": setmdpi( CustomType); break;
        case "3": sethdpi( CustomType); break;
        case "4": setxhdpi( CustomType); break;
    }
}


function ConvertDpToPx(x) {

    switch (screenDP) {
        case 1: return ((x / 4) * 3 + x % 4); break;
        case 2: return (x); break;
        case 3: return (x * 1.5); break;
        case 4: return (x * 2); break;
        case 5: return (x * 3); break;
    }
}


