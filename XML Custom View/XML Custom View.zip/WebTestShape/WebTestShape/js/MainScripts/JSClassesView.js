﻿class View {
    // start Construct
    constructor(CustomView) {
        this.id = "View_00";
        this.text_color = "#000000";
        this.text_size = 10;
        this.text_gravity = "center";
        this.font_family = "sans-serif-condensed";
        this.shadow_color = "#000000";
        this.shadow_center_x = 0;
        this.shadow_center_y = 0;
        this.shadow_radius = 0;
        this.enable = true;
        this.alpha = 10;
        this.text_all_caps = false;
        this.bold = false;
        this.italic = false;
        this.padding_left = 0;
        this.padding_right = 0;
        this.padding_top = 0;
        this.padding_bottom = 0;
        this.myShape = new Shape(CustomView);
    }
    // end Construct


    // start Tab Basic methods  
    setEnablesTrue(CustomType) {

        document.getElementById(CustomType +'_RadioEnableTrue').checked = true;
        document.getElementById(CustomType + '_RadioEnableFalse').checked = false;

        this.enable = true;
        ViewShow.disabled = false;
    };

    setEnablesFalse(CustomType) {

        document.getElementById(CustomType + '_RadioEnableTrue').checked = false;
        document.getElementById(CustomType + '_RadioEnableFalse').checked = true;

        this.enable = false;
        ViewShow.disabled = true;
    };

    setAlpha(Value) {
        this.alpha = Value;
        TextViewAlpha.value = Value;
        ViewShow.style.opacity = 0.1 * Value;
    };

    
    ChangeID(CustomType) {

        var NameID = document.getElementById(CustomType+'_ID').value;
        if (NameID == "" || (NameID[0] >= 0 && NameID[0] <= 9)) {
            this.id = "View_" + Math.floor((Math.random() * 100) + 1);
            document.getElementById(CustomType + '_ID').value = this.id;
            return;
        }

        for (var i = 0 ; i < NameID.length ; i++) {

            if (NameID[i] == ' ') {
                this.id = "View_" + Math.floor((Math.random() * 100) + 1);
                document.getElementById(CustomType + '_ID').value = this.id;
                return;
            }

            
            if (NameID[i] == '_' || (NameID[i] >= 'A' && NameID[i] <= 'Z') || (NameID[i] >= 'a' && NameID[i] <= 'z') || (NameID[i] >= 0 && NameID[i] <= 9))
                continue;
            else {
                this.id = "View_" + Math.floor((Math.random() * 100) + 1);
                document.getElementById(CustomType + '_ID').value = this.id;
                return;
            }
        }
        this.id = NameID;
    }

    // end Tab Basic methods 



    // start Tab Text methods  
    setTextSize(Value) {

        this.text_size = Value;
        TextViewTextSize.value = this.text_size;
        ViewShow.style.fontSize = ConvertDpToPx(this.text_size) + "px";
    }


    setTextColor(Value) {
        this.text_color = Value;
        ViewShow.style.color = this.text_color;
    }


    setBold() {

        if (this.bold) {
            this.bold = false;
            ViewShow.style.fontWeight = "normal";
        } else {
            this.bold = true;
            ViewShow.style.fontWeight = "Bold";
        }
    }

    setItalic() {

        if (this.italic) {
            this.italic = false;
            ViewShow.style.fontStyle = "normal";
        } else {
            this.italic = true;
            ViewShow.style.fontStyle = "italic";
        }
    }


    setTextALLcaps() {

        if (this.text_all_caps) {
            this.text_all_caps = false;
            ViewShow.style.textTransform = "none";
        } else {
            this.text_all_caps = true;
            ViewShow.style.textTransform = "uppercase";
        }
    }

    /*
    setFontCursive() {
        ViewShow.style.font_family = "cursive";
        this.font_family = "cursive";
    }
*/
    setFontSerif() {
        ViewShow.style.fontFamily = "serif";
        this.font_family = "serif";
    }

    setFontMonoSpace() {
        ViewShow.style.fontFamily = "monospace";
        this.font_family = "serif-monospace";
    }

    setFontDefault() {
        ViewShow.style.fontFamily = "sans-serif";
        this.font_family = "sans-serif-condensed";
    }

    setFontCasual() {
        ViewShow.style.fontFamily = "Comic Sans MS";
        this.font_family = "casual";
    }

    SetFontType(select) {

        switch (select) {
            case "1": this.setFontDefault(); break;
        //  case "2": this.setFontCursive(); break;
            case "3": this.setFontSerif(); break;
            case "4": this.setFontMonoSpace(); break;
            case "5": this.setFontCasual(); break;
        }
    }


    setAlignTextLeft() {
        ViewShow.style.textAlign = "left";
        ViewShow.style.padding_left = "3%"
        this.text_gravity = "left|center_vertical";
    }

    setAlignTextRight() {
        ViewShow.style.textAlign = "right";
        this.text_gravity = "right|center_vertical";
    }

    setAlignTextCenter() {
        ViewShow.style.textAlign = "center";
        this.text_gravity = "center";
    }


    SetTextGravity(select) {

        switch (select) {

            case "1": this.setAlignTextCenter(); break;
            case "2": this.setAlignTextLeft(); break;
            case "3": this.setAlignTextRight(); break;

        }

    }


    // start Shadow 
    setShadow(CustomType) {

        this.shadow_center_x = document.getElementById(CustomType + '_Slider_ShadowCenterX').value;
        this.shadow_center_y = document.getElementById(CustomType + '_Slider_ShadowCenterY').value;
        this.shadow_radius = document.getElementById(CustomType + '_Slider_ShadowRaduis').value;
        this.shadow_color = document.getElementById(CustomType + '_ShadowColor').value;


        
        TextViewShadowCenterX.value = this.shadow_center_x;
        TextViewShadowCenterY.value = this.shadow_center_y;
        TextViewShadowRadius.value = this.shadow_radius;

        ViewShow.style.textShadow = this.shadow_center_x + "px " + this.shadow_center_y + "px " + this.shadow_radius + "px " + this.shadow_color;
    } 
    // end Shadow 

    // end Tab Text methods 

    // start Tab Padding

    setPaddingTop(Value) {

        if (Value < 5) {
            ViewShow.style.paddingTop = ConvertDpToPx(4) + "px";
            TextViewPaddingTop.value = Value;
            this.padding_top = Value;
        }
        else {
            ViewShow.style.paddingTop = ConvertDpToPx(Value) + "px";
            TextViewPaddingTop.value = Value;
            this.padding_top = Value;
        }
        
    }


    setPaddingBottom(Value) {
        ViewShow.style.paddingBottom = ConvertDpToPx(Value) + "px";
        TextViewPaddingBottom.value = Value;
        this.padding_bottom = Value;
    }


    setPaddingLeft(Value) {

        if (Value > 3)
            ViewShow.style.paddingLeft = ConvertDpToPx(Value) + "px";
        else
            ViewShow.style.paddingLeft = ConvertDpToPx(3) + "px";


        TextViewPaddingLeft.value = Value;
        this.padding_left = Value;
    }


    setPaddingRight(Value) {
        ViewShow.style.paddingRight = ConvertDpToPx(Value) + "px";
        TextViewPaddingRight.value = Value;
        this.padding_right = Value;
    }

    // end Tab Padding

}


