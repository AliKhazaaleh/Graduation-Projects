﻿class EditText extends View {

    constructor(CustomView) {
        super(CustomView);
        this.hint = "hint";
        this.lines = 5;
        this.color_hint = "#867D7D";
        this.type_input = "text";
        this.max_length = 10;
        this.select_all_focus = false;
    }
    
    setHint(Value) {
        this.hint = Value;
        ViewShow.placeholder = Value;
        ViewShow.value = "";
    }
    

    SetInputType(select) {
        switch (select) {
            case "1": this.setTypePassWord(); break;
            case "2": this.setTypeNumber(); break;
            case "3": this.setTypeEmailAddress(); break;
        }
    }

    setTypePassWord() {
        this.type_input = "textpassword";
        ViewShow.setAttribute("type", "password");
        ViewShow.value = "";   
    }

    setTypeNumber() {
        this.type_input = "number";
        ViewShow.setAttribute("type", "number");
        ViewShow.value = "";
    }

    setTypeText() {
        this.type_input = "text";
        ViewShow.setAttribute("type", "text");
        ViewShow.value = "";
    }

    setMaxLength(Value) {
        this.max_length = Value;
        TextViewMaxLength.value = Value;
        ViewShow.value = "";
    }

    setSlectAllOnFocus(Value) {
        this.select_all_focus = Value;

        if (Value == "true")
            EditText_RadioSelectAllOnFocusFalse.checked = false ;
        else
            EditText_RadioSelectAllOnFocusTrue.checked = false;
    }

    CheckOnMaxlen() {

        if ( ViewShow.value.length > this.max_length)
            ViewShow.value = "";

    }

    // Functions For Generate Code EditText  
    GenerateCodeEditText() {

        var CodeEditText = "<EditText\n android:layout_width=\"wrap_content\"\nandroid:layout_height=\"wrap_content\"\n" + "";

        CodeEditText += "android:id=\"@+id/" + this.id + "\"\n";

        CodeEditText += "android:textSize=\"" + this.text_size + "sp\"\n";

        // check on Syntax
        CodeEditText += "android:hint=\"" + this.hint + "\"\n";
        CodeEditText += "android:textColor=\"" + this.text_color + "\"\n";
        CodeEditText += "android:inputType=\"" + this.type_input + "\"\n";
        CodeEditText += "android:selectAllOnFocus=\"" + this.select_all_focus + "\"\n";
        CodeEditText += "android:maxLength=\"" + this.max_length + "\"\n";        
        // 


        if (this.bold && this.italic)
            CodeEditText += "android:textStyle=\"bold|italic\"\n";
        else if (this.bold)
            CodeEditText += "android:textStyle=\"bold\"\n";
        else if (this.italic)
            CodeEditText += "android:textStyle=\"italic\"\n";

        CodeEditText += "android:fontFamily=\"" + this.font_family + "\"\n";

        if (this.text_all_caps)
            CodeEditText += "android:textAllCaps=\"true\"\n";
        else
            CodeEditText += "android:textAllCaps=\"false\"\n";

        CodeEditText += "android:gravity=\"" + this.text_gravity + "\"\n";
        CodeEditText += "android:alpha=\"" + (0.1 * this.alpha).toFixed(1) + "\"\n";
        CodeEditText += "android:enabled=\"" + this.enable + "\"\n";

        CodeEditText += "android:shadowColor=" + "\"" + this.shadow_color + "\"\n";
        CodeEditText += "android:shadowDx=\"" + this.shadow_center_x + "\"\n";
        CodeEditText += "android:shadowDy=\"" + this.shadow_center_y + "\"\n";
        CodeEditText += "android:shadowRadius=\"" + this.shadow_radius + "\"\n";

        CodeEditText += "android:paddingLeft=\"" + this.padding_left + "dp\"\n" + "";
        CodeEditText += "android:paddingRight=\"" + this.padding_right + "dp\"\n";
        CodeEditText += "android:paddingTop=\"" + this.padding_top + "dp\"\n";
        CodeEditText += "android:paddingBottom=\"" + this.padding_bottom + "dp\"\n";

        CodeEditText += "android:background=\"@drawable/Write Name File ???\"\n";

        CodeEditText += "/>\n";

        return CodeEditText;
    }
    // end Function Generate Code EditText

}

var myEditText = new EditText("EditText");

