﻿class TextView extends View {

    constructor(CustomView) {
        super(CustomView);
        this.text = "TextView";
        this.lines = 5;
    }

    // Add Methods For Text of TextView
    setText(Value) {
        this.text = Value;
        ViewShow.value =  Value;
    }

    setLines(Value) {
        TextViewLines.value = Value;
    }

    // End Methods For Text of TextView



    // Functions For Generate Code TextView  
    GenerateCodeTextView() {

        var CodeTextView = "<TextView\n android:layout_width=\"wrap_content\"\nandroid:layout_height=\"wrap_content\"\n" + "";

        CodeTextView += "android:id=\"@+id/" + this.id + "\"\n";
        CodeTextView += "android:text=\"" + this.text + "\"\n";
        CodeTextView += "android:textColor=\"" + this.text_color + "\"\n";
        CodeTextView += "android:textSize=\"" + this.text_size + "sp\"\n";


        if (this.bold && this.italic)
            CodeTextView += "android:textStyle=\"bold|italic\"\n";
        else if (this.bold)
            CodeTextView += "android:textStyle=\"bold\"\n";
        else if (this.italic)
            CodeTextView += "android:textStyle=\"italic\"\n";

        CodeTextView += "android:fontFamily=\"" + this.font_family + "\"\n";

        if (this.text_all_caps)
            CodeTextView += "android:textAllCaps=\"true\"\n";
        else
            CodeTextView += "android:textAllCaps=\"false\"\n";

        CodeTextView += "android:gravity=\"" + this.text_gravity + "\"\n";
        CodeTextView += "android:alpha=\"" + (0.1 * this.alpha).toFixed(1) + "\"\n";
        CodeTextView += "android:enabled=\"" + this.enable + "\"\n";

        CodeTextView += "android:shadowColor=" + "\"" + this.shadow_color + "\"\n";
        CodeTextView += "android:shadowDx=\"" + this.shadow_center_x + "\"\n";
        CodeTextView += "android:shadowDy=\"" + this.shadow_center_y + "\"\n";
        CodeTextView += "android:shadowRadius=\"" + this.shadow_radius + "\"\n";

        CodeTextView += "android:paddingLeft=\"" + this.padding_left + "dp\"\n" + "";
        CodeTextView += "android:paddingRight=\"" + this.padding_right + "dp\"\n";
        CodeTextView += "android:paddingTop=\"" + this.padding_top + "dp\"\n";
        CodeTextView += "android:paddingBottom=\"" + this.padding_bottom + "dp\"\n";

        CodeTextView += "android:background=\"@drawable/Write Name File ???\"\n";

        CodeTextView += "/>\n";

        return CodeTextView;
    }
    // end Function Generate Code TextView

}

var myTextView = new TextView("TextView");

