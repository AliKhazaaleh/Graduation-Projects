﻿class CheckBox extends View {

    constructor(CustomView) {
        super(CustomView);
        this.text = "CheckBox";
        this.checked = false;
        this.text_gravity = "left|center_vertical";
    }

    // Add Methods For Text of RadioButton
    setText(Value) {
        this.text = Value;
        document.getElementById('CheckBox_Text').textContent = Value;
    }


    setEnablesTrue(CustomType) {


        document.getElementById(CustomType + '_RadioEnableTrue').checked = true;
        document.getElementById(CustomType + '_RadioEnableFalse').checked = false;

        this.enable = true;
        ViewShow.disabled = false;
        RadioPartCheck.disabled = false;
    }

    setEnablesFalse(CustomType) {

        document.getElementById(CustomType + '_RadioEnableTrue').checked = false;
        document.getElementById(CustomType + '_RadioEnableFalse').checked = true;

        this.enable = false;
        ViewShow.disabled = true;
        RadioPartCheck.disabled = true;
    }

    setCheckedTrue(CustomType) {
        document.getElementById(CustomType + '_RadioCheckedTrue').checked = true;
        document.getElementById(CustomType + '_RadioCheckedFalse').checked = false;

        this.Checked = true;
        RadioPartCheck.checked = true;
    }

    setCheckedFalse(CustomType) {

        document.getElementById(CustomType + '_RadioCheckedTrue').checked = false;
        document.getElementById(CustomType + '_RadioCheckedFalse').checked = true;

        this.checked = false;
        RadioPartCheck.checked = false;
    }

    setTextSize(Value) {

        this.text_size = Value;
        TextViewTextSize.value = this.text_size;
        CheckBox_Text.style.fontSize = ConvertDpToPx(this.text_size) + "px";
    }



    setBold() {

        if (this.bold) {
            this.bold = false;
            CheckBox_Text.style.fontWeight = "normal";
        } else {
            this.bold = true;
            CheckBox_Text.style.fontWeight = "Bold";
        }
    }

    setItalic() {

        if (this.italic) {
            this.italic = false;
            CheckBox_Text.style.fontStyle = "normal";
        } else {
            this.italic = true;
            CheckBox_Text.style.fontStyle = "italic";
        }
    }

    // End Methods For Text of RadioButton



    // Functions For Generate Code RadioButton  
    GenerateCodeCheckBox() {

        var CodeCheckBox = "<CheckBox\n android:layout_width=\"wrap_content\"\nandroid:layout_height=\"wrap_content\"\n" + "";

        CodeCheckBox += "android:id=\"@+id/" + this.id + "\"\n";
        CodeCheckBox += "android:text=\"" + this.text + "\"\n";
        CodeCheckBox += "android:textColor=\"" + this.text_color + "\"\n";
        CodeCheckBox += "android:textSize=\"" + this.text_size + "sp\"\n";


        if (this.bold && this.italic)
            CodeCheckBox += "android:textStyle=\"bold|italic\"\n";
        else if (this.bold)
            CodeCheckBox += "android:textStyle=\"bold\"\n";
        else if (this.italic)
            CodeCheckBox += "android:textStyle=\"italic\"\n";

        CodeCheckBox += "android:fontFamily=\"" + this.font_family + "\"\n";

        if (this.text_all_caps)
            CodeCheckBox += "android:textAllCaps=\"true\"\n";
        else
            CodeCheckBox += "android:textAllCaps=\"false\"\n";

        CodeCheckBox += "android:gravity=\"" + this.text_gravity + "\"\n";
        CodeCheckBox += "android:alpha=\"" + (0.1 * this.alpha).toFixed(1) + "\"\n";
        CodeCheckBox += "android:enabled=\"" + this.enable + "\"\n";
        CodeCheckBox += "android:checked=\"" + this.checked + "\"\n";
        CodeCheckBox += "android:shadowColor=" + "\"" + this.shadow_color + "\"\n";
        CodeCheckBox += "android:shadowDx=\"" + this.shadow_center_x + "\"\n";
        CodeCheckBox += "android:shadowDy=\"" + this.shadow_center_y + "\"\n";
        CodeCheckBox += "android:shadowRadius=\"" + this.shadow_radius + "\"\n";

        CodeCheckBox += "android:paddingLeft=\"" + this.padding_left + "dp\"\n" + "";
        CodeCheckBox += "android:paddingRight=\"" + this.padding_right + "dp\"\n";
        CodeCheckBox += "android:paddingTop=\"" + this.padding_top + "dp\"\n";
        CodeCheckBox += "android:paddingBottom=\"" + this.padding_bottom + "dp\"\n";

        CodeCheckBox += "android:background=\"@drawable/Write Name File ???\"\n";

        CodeCheckBox += "/>\n";

        return CodeCheckBox;
    }
    // end Function Generate Code RadioButton

}

var myCheckBox = new CheckBox("CheckBox");

