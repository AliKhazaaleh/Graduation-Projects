﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebTestShape
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        
        }

        protected void Button_To_Page_CustomButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("Custom_Button.aspx");
            // Page.ClientScript.RegisterStartupScript(this.GetType(), "OpenWindow", "window.open('Custom_Button.aspx','_blank');", true);
            //Response.Write("< script > window.open( ‘Custom_Button.aspx’, '_blank'); </ script >");
            // Server.Transfer("YourPage.aspx");
        }

        protected void Button_To_Page_CustomTextView_Click(object sender, EventArgs e)
        {
            Response.Redirect("Custom_TextView.aspx");
            // Page.ClientScript.RegisterStartupScript(this.GetType(), "OpenWindow", "window.open('Custom_TextView.aspx','_newtab');", true);
            // Server.Transfer("YourPage.aspx");

        }

        protected void Button_To_Page_CustomEditText_Click(object sender, EventArgs e)
        {
            Response.Redirect("Custom_EditText.aspx");
          //  Page.ClientScript.RegisterStartupScript(this.GetType(), "OpenWindow", "window.open('Custom_EditText.aspx','_newtab');", true);
            // Server.Transfer("Custom_Button.aspx");

        }

        protected void Button_To_Page_CustomRadioButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("Custom_RadioButton.aspx");
            // Page.ClientScript.RegisterStartupScript(this.GetType(), "OpenWindow", "window.open('Custom_RadioButton.aspx','_newtab');", true);

            // Server.Transfer("Custom_Button.aspx");

        }


        protected void Button_To_Page_CustomCheckBox_Click(object sender, EventArgs e)
        {
           Response.Redirect("Custom_CheckBox.aspx");
           //   Page.ClientScript.RegisterStartupScript(this.GetType(), "OpenWindow", "window.open('Custom_CheckBox.aspx','_newtab');", true);

            // Server.Transfer("Custom_Button.aspx");

        }

        protected void Button_To_Page_CustomShape_Click(object sender, EventArgs e)
        {
            Response.Redirect("Custom_Shape.aspx");
           //  Page.ClientScript.RegisterStartupScript(this.GetType(), "OpenWindow", "window.open('Custom_Shape.aspx','_newtab');", true);

           //  Server.Transfer("Custom_Button.aspx");

        }


        protected void Button_To_Page_ButtonBuzzer_Click(object sender, EventArgs e)
        {
            Response.Redirect("CustomJava_ButtonBuzzer.aspx");
        }

        protected void Button_To_Page_ButtonHeart_Click(object sender, EventArgs e)
        {
            Response.Redirect("CustomJava_ButtonHeart.aspx");
        }

        ///feedback
        protected void Button_contact_submit_Click(object sender, EventArgs e)
        {
            string ObNameSender = name.Value;
            string ObSubject = subject.Value;
            string ObMessage = message.Value;

            for (int i=0; i<ObNameSender.Length ;i++)
            if (ObNameSender[i] - '0' >= 0 && ObNameSender[i] -'0' <=9) {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Not valid Name')", true);
                    return;
            }

            if (ObNameSender == "" || ObSubject == "" ){
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Fill Name or Subject ')", true);
                return;
            }

            if (ObMessage == "" || ObMessage.Length <= 5) {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Message is Empty or Very Shorter')", true);
                return;
            }

           
            string MSG = "Name: " + name.Value +"\n";
            MSG += "Email: " + email.Value + "\n";
            MSG += "Browser: " + Request.Browser.Browser+"\n";
            MSG += "Subject: " + subject.Value + "\n";
            MSG += "MSG: " + message.Value + "\n";

            MailMessage msg = new MailMessage();

            msg.From = new MailAddress("XMLCustomViewSend@gmail.com");
            msg.To.Add("alikhazal.95@gmail.com");
            msg.Subject = subject.Value + DateTime.Now.ToString();
            msg.Body = MSG.ToString();
            SmtpClient client = new SmtpClient();
            client.UseDefaultCredentials = true;
            client.Host = "smtp.gmail.com";
            client.Port = 587;
            client.EnableSsl = true;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.Credentials = new NetworkCredential("XMLCustomViewSend@gmail.com", "testXML@61");
            client.Timeout = 20000;

            try
            {
                client.Send(msg);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Successfully')", true);
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Not Successfully')", true);
            }
            finally
            {
                msg.Dispose();
            }
        }
      
       //// MODEL
        protected void Button_contact_submit_xmlcode_Click(object sender, EventArgs e)
        {
            string MSG = "Code Custom Shape \n ------------------------- \n";
            MSG += TextCodeCustomTemp.Value;
            MSG += "\n------------------------- \n\n\n";

                MSG += "Code View \n ------------------------- \n";
                MSG += TextCodeViewTemp.Value;
                MSG += "\n------------------------- \n\n\n";


            MailMessage msg = new MailMessage();

            msg.From = new MailAddress("XMLCustomViewSend@gmail.com");
            msg.To.Add(emailCodeUser.Value.ToString());


            msg.Subject = subjectCodeUser.Value + DateTime.Now.ToString();
            msg.Body = MSG.ToString();
            SmtpClient client = new SmtpClient();
            client.UseDefaultCredentials = true;
            client.Host = "smtp.gmail.com";
            client.Port = 587;
            client.EnableSsl = true;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.Credentials = new NetworkCredential("XMLCustomViewSend@gmail.com", "testXML@61");
            client.Timeout = 20000;

            try
            {
                client.Send(msg);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Successfully')", true);
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Not Successfully')", true);
            }
            finally
            {
                msg.Dispose();
            }
        }


    }
}