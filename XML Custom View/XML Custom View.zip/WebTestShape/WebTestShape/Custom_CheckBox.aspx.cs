﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace WebTestShape
{
    public partial class Custom_CheckBox : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //// MODEL
        protected void Button_contact_submit_xmlcode_Click(object sender, EventArgs e)
        {
            string MSG = "Code Custom Shape \n ------------------------- \n";
            MSG += TextCodeCustom.Value;
            MSG += "\n------------------------- \n\n\n";

            MSG += "Code View \n ------------------------- \n";
            MSG += TextCodeView.Value;
            MSG += "\n------------------------- \n\n\n";


            MailMessage msg = new MailMessage();

            msg.From = new MailAddress("XMLCustomViewSend@gmail.com");
            msg.To.Add(emailCodeUser.Value.ToString());


            msg.Subject = subjectCodeUser.Value + DateTime.Now.ToString();
            msg.Body = MSG.ToString();
            SmtpClient client = new SmtpClient();
            client.UseDefaultCredentials = true;
            client.Host = "smtp.gmail.com";
            client.Port = 587;
            client.EnableSsl = true;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.Credentials = new NetworkCredential("XMLCustomViewSend@gmail.com", "testXML@1");
            client.Timeout = 20000;

            try
            {
                client.Send(msg);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Successfully')", true);
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Not Successfully')", true);
            }
            finally
            {
                msg.Dispose();
            }
        }


    }
}